sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/m/MessageToast",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/BusyIndicator"
], function(Controller, JSONModel, Fragment, MessageBox, Filter, MessageToast, FilterOperator, BusyIndicator) {
	"use strict";
	// 5000010413
	// 5000010293
	return Controller.extend("dewa.crmportal.ui.ZCRM_NEWADMINRG_S1.controller.Main", {
		onEmailOTPLiveChange: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			if (sValue) {
				var sId = oEvent.getSource().getId();
				if (sId.includes("idEmailOTPInput1")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idEmailOTPInput2").focus();
					});
				} else if (sId.includes("idEmailOTPInput2")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idEmailOTPInput3").focus();
					});
				} else if (sId.includes("idEmailOTPInput3")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idEmailOTPInput4").focus();
					});
				} else if (sId.includes("idEmailOTPInput4")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idEmailOTPInput5").focus();
					});
				} else if (sId.includes("idEmailOTPInput5")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idEmailOTPInput6").focus();
					});
				}
			}
		},
		onResubOTPLiveChange: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			if (sValue) {
				var sId = oEvent.getSource().getId();
				if (sId.includes("idResubOTPInput1")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idResubOTPInput2").focus();
					});
				} else if (sId.includes("idResubOTPInput2")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idResubOTPInput3").focus();
					});
				} else if (sId.includes("idResubOTPInput3")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idResubOTPInput4").focus();
					});
				} else if (sId.includes("idResubOTPInput4")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idResubOTPInput5").focus();
					});
				} else if (sId.includes("idResubOTPInput5")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idResubOTPInput6").focus();
					});
				}
			}
		},
		onMobOTPLiveChange: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			if (sValue) {
				var sId = oEvent.getSource().getId();
				if (sId.includes("idMobOTPInput1")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idMobOTPInput2").focus();
					});
				} else if (sId.includes("idMobOTPInput2")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idMobOTPInput3").focus();
					});
				} else if (sId.includes("idMobOTPInput3")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idMobOTPInput4").focus();
					});
				} else if (sId.includes("idMobOTPInput4")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idMobOTPInput5").focus();
					});
				} else if (sId.includes("idMobOTPInput5")) {
					jQuery.sap.delayedCall(100, this, function() {
						this.byId("idMobOTPInput6").focus();
					});
				}
			}
		},
		validateCaptcha: function() {
			var bProceed = false;
			if (grecaptcha) {
				if (grecaptcha.getResponse().length > 0) {
					bProceed = true;
				} else {
					bProceed = false;
				}
			} else {
				bProceed = true;
			}
			return bProceed;
		},
		onInit: function() {
			
			var selection = new JSONModel();
			selection.setData({
				bpValue: 'Yes',
				step: '1'
			});

			this.getView().setModel(selection, 'selection');
			var Details = new JSONModel();
			Details.setProperty("/CompanyDetails", {
				'BpNumber': '',
				'IdentNumber': ''
			});
			Details.setProperty("/AdminDetails", {
				"IdentiRespNo": ""
			});
			var viewModel = new JSONModel();
			viewModel.setDefaultBindingMode("OneWay");
			viewModel.setProperty("/ViewSetting", true);
			this.getView().setModel(viewModel, 'viewModel');
			this.getView().setModel(Details, 'Details');
			var oDDModel = new JSONModel(),
				oModel = this.getOwnerComponent().getModel("Anonymous");
			var aFilter = [];
			aFilter.push(new Filter("Fieldname", FilterOperator.EQ, "DESIGNATION"));
			oModel.read("/DropDownSet", {
				filters: aFilter,
				success: function(oData) {
					oDDModel.setProperty('/designation', oData.results);
				}.bind(this),
				error: function(oErr) {
					oDDModel.setProperty('/designation', []);
				}.bind(this)
			});
			aFilter = [];
			aFilter.push(new Filter("Fieldname", FilterOperator.EQ, "TELEPHONE_EXT"));
			oModel.read("/DropDownSet", {
				filters: aFilter,
				success: function(oData) {
					oDDModel.setProperty('/extension', oData.results);
				}.bind(this),
				error: function(oErr) {
					oDDModel.setProperty('/extension', []);
				}.bind(this)
			});
			aFilter = [];
			aFilter.push(new Filter("Fieldname", FilterOperator.EQ, "NATION"));
			oModel.read("/DropDownSet", {
				filters: aFilter,
				success: function(oData) {
					oDDModel.setProperty('/nation', oData.results);
				}.bind(this),
				error: function(oErr) {
					oDDModel.setProperty('/nation', []);
				}.bind(this)
			});
			this.getView().setModel(oDDModel, 'DDModel');
			this.sMode = "newReq";
			this.BpFlag = "";
			var sDynamicParam = jQuery.sap.getUriParameters().get("registrationId");
			if (sDynamicParam) {
				var aUrlParam = sDynamicParam.split(",");
				this.sRegistrationId = aUrlParam[0];
				this.sMode = aUrlParam[1];

				if (this.sRegistrationId && this.sMode) {
					if (this.sMode === "display") {
						this.verifyResubmitOTP(this.sRegistrationId);
						// this.GetDetails(this.sRegistrationId, this.sMode);
					} else if (this.sMode === "resubmit") {
						this.verifyResubmitOTP(this.sRegistrationId);
					}
				}
			}

		},
		onAfterRendering: function() {
			this.getTermsCondition();
			ResetHeight(this);
		},
		GetDetails: function(RequestNo, sMode) {
			// 0017000796

			var oModel = this.getOwnerComponent().getModel('Anonymous');
			var details = this.getView().getModel('Details');
			var viewModel = this.getView().getModel('viewModel');
			var url = "/ResubmitApplicationSet(RequestNo='" + RequestNo + "')";
			if (sMode === "display") {
				viewModel.setProperty("/ViewSetting", false);
				this.getView().byId("id_next").setEnabled(true);
			} else if (sMode === "resubmit") {

				viewModel.setProperty("/ViewSetting", true);
			}
			this.getView().setBusy(true);
			oModel.read(url, {
				success: function(oData) {
					this.getView().setBusy(false);
					details.setProperty("/CompanyDetails", oData);
					details.setProperty("/AdminDetails", oData);
					this.verId = true;

				}.bind(this),
				error: function(oErr) {
					this.getView().setBusy(false);
					this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
					details.setProperty("/CompanyDetails", []);

					//	MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
				}.bind(this)
			});
		},
		onRadioButtonSelect: function(oEvent) {

			var selected = oEvent.getSource().getSelectedIndex(),
				selection = this.getView().getModel('selection');
			if (selected === 0) {
				selection.setData({
					bpValue: 'Yes',
					step: '1'
				});

			} else if (selected === 1) {
				selection.setData({
					bpValue: 'No',
					step: '1'
				});
			}

		},
		onPressGetBPDetails: function() {
			// 0017000796
			var bpNum = this.getView().byId('id_BPNum').getValue(),
				oModel = this.getView().getModel('Anonymous'),
				details = this.getView().getModel('Details');
			if (bpNum === "" || bpNum === null || bpNum === undefined) {
				this.getView().byId('id_BPNum').setValueState("Error");
				this.getView().byId('id_BPNum').setValueStateText("Please enter a BP Number");
				return;
			} else {
				this.getView().byId('id_BPNum').setValueState("None");
				this.getView().byId('id_BPNum').setValueStateText("");
			}
			if (this.sMode === "display") {
				var resFlag = "V";
			} else if (this.sMode === "resubmit") {
				var resFlag = "ES";
			} else if (this.sMode === "newReq") {
				var resFlag = "";
			}
			var url = "/NewRegSet(BpFlag='X',IdentNumber='',IdentiRespNo='',BpNumber='" + bpNum + "',Zcheck='G',IdRespTodate='',ResubmitFlag='" +
				resFlag + "')";
			this.BpFlag = "X";

			this.getView().setBusy(true);
			oModel.read(url, {
				success: function(oData) {
					this.getView().byId('id_next').setEnabled(true);
					this.getView().setBusy(false);
					details.setProperty("/CompanyDetails", oData);
					MessageToast.show("Data Retrieved from Busines Partner Number " + bpNum);
				}.bind(this),
				error: function(oErr) {
					this.getView().byId('id_next').setEnabled(false);
					// MessageBox.information("No Data Retrieved from Busines Partner Number ");
					details.setProperty("/CompanyDetails", []);
					this.getView().setBusy(false);
					this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
				}.bind(this)
			});
		},
		onComboboxChange: function() {
			this.byId("admMobilebtn").setText("Verify");
			this.byId("admMobilebtn").setShowValueHelp(false);
			this.verMob = false;
		},
		onEmiratesIDchange: function() {
			this.verId = false;
			this.verEmail = false;
			this.verMob = false;
			this.getView().byId("idISOCodesApp").setEnabled(true);
			this.getView().byId("admMobile").setEnabled(true);
			this.getView().byId("admMobilebtn").setEnabled(true);
			this.getView().byId("id_admEmail").setEnabled(true);
			this.getView().byId("btnVerifyEmail").setEnabled(true);
			this.byId("admMobilebtn").setText("Verify");
			this.byId("admMobile").setShowValueHelp(false);
			this.byId("btnVerifyEmail").setText("Verify");
			this.byId("id_admEmail").setShowValueHelp(false);
		},
		liveChangeEmiratesID: function() {
			this.verId = false;
			// this.byId("admMobilebtn").setText("Verify");
			// this.byId("btnVerifyEmail").setText("Verify");
		},
		onPressEmiratesId: function() {
			var emNum = this.getView().byId('id_emIdNum').getValue(),
				oModel = this.getView().getModel('Anonymous'),
				details = this.getView().getModel('Details'),
				oExpDate = this.getView().byId("expDate_value").getValue(),
				oExpDate = oExpDate.replaceAll("/", ""),
				id_LicNum = this.getView().byId("id_LicNum").getValue();
			if (this.sMode === "display") {
				var resFlag = "V";
			} else if (this.sMode === "resubmit") {
				var resFlag = "ES";
			} else if (this.sMode === "newReq") {
				var resFlag = "";
			}
			var url = "/NewRegSet(ResubmitFlag='" + resFlag + "',BpFlag='',IdentNumber='" + id_LicNum + "',IdentiRespNo='" + emNum +
				"',BpNumber='',Zcheck='I',IdRespTodate='" +
				oExpDate +
				"')";

			this.getView().setBusy(true);
			oModel.read(url, {
				success: function(oData) {

					details.setProperty("/AdminDetails", oData);
					this.getView().setBusy(false);
					this.verEmail = false;
					this.verMob = false;
					this.verId = true;
					this.getView().byId("idISOCodesApp").setEnabled(true);
					this.getView().byId("admMobile").setEnabled(true);
					this.getView().byId("admMobilebtn").setEnabled(true);
					this.getView().byId("id_admEmail").setEnabled(true);
					this.getView().byId("btnVerifyEmail").setEnabled(true);

					MessageToast.show("Data Retrieved");
				}.bind(this),
				error: function(oErr) {
					this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
					this.getView().setBusy(false);
					details.setProperty("/AdminDetails", {
						"IdentiRespNo": "",
						"Idvalidtodate": ""
					});
					this.verEmail = false;
					this.verMob = false;
					this.verId = false;
					this.getView().byId("idISOCodesApp").setEnabled(true);
					this.getView().byId("admMobile").setEnabled(true);
					this.getView().byId("admMobilebtn").setEnabled(true);
					this.getView().byId("id_admEmail").setEnabled(true);
					this.getView().byId("btnVerifyEmail").setEnabled(true);

					//	MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
				}.bind(this)
			});
		},
		onPressGetLicNum: function() {
			var licNum = this.getView().byId('id_LicNum').getValue(),
				expDate = this.getView().byId('tradeExpiry').getValue(),
				oModel = this.getView().getModel('Anonymous'),
				details = this.getView().getModel('Details');
			var oBundle = this.getView().getModel("i18n").getResourceBundle();

			if (licNum === "" || expDate === "") {
				var msg = oBundle.getText("mantDetails");
				this.openMessageDialog("Error", msg);
				//	MessageBox.error("Please provide all the mandatory details");
				return;
			}
			if (this.sMode === "display") {
				var resFlag = "V";
			} else if (this.sMode === "resubmit") {
				var resFlag = "ES";
			} else if (this.sMode === "newReq") {
				var resFlag = "";
			}
			if (expDate.includes("/")) {
				expDate = expDate.replaceAll("/", "");
			}
			var url = "/NewRegSet(ResubmitFlag='" + resFlag + "',BpFlag='',IdentNumber='" + licNum +
				"',IdentiRespNo='',BpNumber='',Zcheck='G',IdRespTodate='" + expDate + "')";
			this.lcNumUrl = url;
			this.BpFlag = "";
			this.getView().setBusy(true);
			oModel.read(url, {
				success: function(oData) {
					this.getView().byId('id_next').setEnabled(true);
					details.setProperty("/CompanyDetails", oData);
					this.getView().setBusy(false);

					//	MessageToast.show("Data Retrieved from Licence Number  " + licNum);
				}.bind(this),
				error: function(oErr) {
					this.getView().byId('id_next').setEnabled(false);
					// MessageBox.information("No Data Retrieved from Licence Number");
					details.setProperty("/CompanyDetails", []);
					this.getView().setBusy(false);
					this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
				}.bind(this)
			});
		},
		onPressNext: function() {
			var sCurrentStep = this.byId("idCreateAccountWizard").getCurrentStep(),
				oCompanyDetail = this.byId("idCompanyDetailStep"),
				oApplicantDetail = this.byId("idApplicantDetailStep"),
				oDocumentUploadDetail = this.byId("idDocumentUploadStep"),
				oModel = this.getView().getModel('Anonymous'),
				bpNum = this.byId("id_BPNum").getValue(),
				LicNum = this.byId("id_LicNum").getValue(),
				licExpDate = this.byId("tradeExpiry").getValue(),
				resFlag = "";

			if (licExpDate.includes("/")) {
				licExpDate = licExpDate.replaceAll("/", "");
			}

			if (this.sMode === "display") {
				var resFlag = "V";
			} else if (this.sMode === "resubmit") {
				var resFlag = "E";
			} else if (this.sMode === "newReq") {
				var resFlag = "";
			}

			if (sCurrentStep === oCompanyDetail.getId()) {

				if (bpNum !== "" && LicNum !== "") {
					if (this.BpFlag === "X") {
						var url = "/NewRegSet(ResubmitFlag='" + resFlag + "',BpFlag='" + this.BpFlag + "',IdentNumber='',IdentiRespNo='',BpNumber='" +
							bpNum + "',Zcheck='G',IdRespTodate='')";
					} else {
						var url = "/NewRegSet(ResubmitFlag='" + resFlag + "',BpFlag='',IdentNumber='" + LicNum +
							"',IdentiRespNo='',BpNumber='',Zcheck='G',IdRespTodate='" + licExpDate + "')";
					}
					this.getView().setBusy(true);
					oModel.read(url, {
						success: function(oData) {
							this.getView().setBusy(false);
							oCompanyDetail.setIcon("sap-icon://accept");
							oCompanyDetail.setVisible(false);
							this.byId("idCreateAccountWizard").setCurrentStep(oApplicantDetail);
						}.bind(this),
						error: function(oErr) {
							this.getView().setBusy(false);
							this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
							//	MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
						}.bind(this)
					});
					grecaptcha.ready(function() {
						grecaptcha.render(document.getElementById("__xmlview0--recaptcha-container"), {
							'sitekey': '6LeizcQlAAAAAJWpW-Ns8YV1xTKXggiJqjsGdG81',
							'callback': function(token) {
								var sUrl = "https://api.qa.dewa.gov.ae/v1/captcha?token=" + token;
								$.ajax({
									url: sUrl,
									type: "GET",
									success: function(data) {},
									error: function(error) {}
								});
							}
						});
					});
					ResetHeight(this);
				} else {
					this.openMessageDialog("Error", this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errStep"));
					// MessageBox.error(this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("errStep"));
					//scrollToCenter(this);
				}

			} else if (sCurrentStep === oApplicantDetail.getId()) {

				if (this.sMode === "resubmit" || this.sMode === "newReq") {
					if (this.verEmail && this.verMob) {
						if (this.sMode === "resubmit") {
							this.getAttachmetns();
						}
						this.checkMandatoryDocsUpload();
						var emNum = this.getView().byId('id_emIdNum').getValue(),
							oExpDate = this.getView().byId("expDate_value").getValue(),
							oExpDate = oExpDate.replaceAll("/", "");
						var url = "/NewRegSet(ResubmitFlag='" + resFlag + "',BpFlag='',IdentNumber='" + LicNum + "',IdentiRespNo='" + emNum +
							"',BpNumber='',Zcheck='I',IdRespTodate='" +
							oExpDate +
							"')";

						this.getView().setBusy(true);
						oModel.read(url, {
							success: function(oData) {
								this.getView().setBusy(false);
								oApplicantDetail.setIcon("sap-icon://accept");
								oApplicantDetail.setVisible(false);
								this.byId("idCreateAccountWizard").setCurrentStep(oDocumentUploadDetail);
							}.bind(this),
							error: function(oErr) {
								this.getView().setBusy(false);
								this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
								// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
							}.bind(this)
						});
						// oApplicantDetail.setIcon("sap-icon://accept");
						// oApplicantDetail.setVisible(false);
						// this.byId("idCreateAccountWizard").setCurrentStep(oDocumentUploadDetail);
						ResetHeight(this);
					} else {
						var oBundle = this.getView().getModel("i18n").getResourceBundle();
						var msg = oBundle.getText("mobileError");
						this.openMessageDialog("Error", msg);
						//	MessageBox.error("Please Verify Mobile Number and Email");
					}
				} else if (this.sMode === "display") {
					this.getAttachmetns();
					this.checkMandatoryDocsUpload();
					var emNum = this.getView().byId('id_emIdNum').getValue(),
						oExpDate = this.getView().byId("expDate_value").getValue(),
						oExpDate = oExpDate.replaceAll("/", "");
					var url = "/NewRegSet(ResubmitFlag='" + resFlag + "',BpFlag='',IdentNumber='" + LicNum + "',IdentiRespNo='" + emNum +
						"',BpNumber='',Zcheck='I',IdRespTodate='" +
						oExpDate +
						"')";

					this.getView().setBusy(true);
					oModel.read(url, {
						success: function(oData) {
							this.getView().setBusy(false);
							oApplicantDetail.setIcon("sap-icon://accept");
							oApplicantDetail.setVisible(false);
							this.byId("idCreateAccountWizard").setCurrentStep(oDocumentUploadDetail);
						}.bind(this),
						error: function(oErr) {
							this.getView().setBusy(false);

							this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
							// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
						}.bind(this)
					});
					// oApplicantDetail.setIcon("sap-icon://accept");
					// oApplicantDetail.setVisible(false);
					// this.byId("idCreateAccountWizard").setCurrentStep(oDocumentUploadDetail);
					ResetHeight(this);
				}

			} else if (sCurrentStep === oDocumentUploadDetail.getId()) {

				if (this.verEmail && this.verMob) {
					var oModel = this.getView().getModel('Anonymous'),
						oEntry = this.getView().getModel('Details').getData().AdminDetails;

					this.getView().setBusy(true);
					oModel.create("/NewRegSet", oEntry, {
						success: function(oData) {
							this.getView().setBusy(false);
							var Details = new JSONModel(oData);
							this.getView().setModel(Details, 'Details');

						}.bind(this),
						error: function(oErr) {
							this.getView().setBusy(false);
							this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
							// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
						}.bind(this)
					});
				} else {
					var oBundle = this.getView().getModel("i18n").getResourceBundle();
					var msg = oBundle.getText("mobEmailError");

					this.openMessageDialog("Error", msg);
					// MessageBox.error("Please Verify Mobile Number and Email");
				}
			}
		},
		onPressBack: function() {
			var sCurrentStep = this.byId("idCreateAccountWizard").getCurrentStep(),
				oCompanyDetail = this.byId("idCompanyDetailStep"),
				oApplicantDetail = this.byId("idApplicantDetailStep"),
				oDocumentUploadDetail = this.byId("idDocumentUploadStep");

			if (sCurrentStep === oApplicantDetail.getId()) {
				this.getView().byId("idCreateAccountWizard").setCurrentStep(oCompanyDetail);
				oCompanyDetail.setIcon("sap-icon://circle-task");
				oCompanyDetail.setVisible(true);
				this.getView().byId("idCreateAccountWizard").setCurrentStep(oCompanyDetail);
				oCompanyDetail.setValidated(false);
				ResetHeight(this);
			}
			if (sCurrentStep === oDocumentUploadDetail.getId()) {
				this.getView().byId("idCreateAccountWizard").setCurrentStep(oCompanyDetail);
				oApplicantDetail.setIcon("sap-icon://circle-task");
				oApplicantDetail.setVisible(true);
				this.getView().byId("idCreateAccountWizard").setCurrentStep(oApplicantDetail);
				oApplicantDetail.setValidated(false);
				ResetHeight(this);
			}
		},
		onValidChange: function(value) {
			var oModel = this.getView().getModel('Anonymous');

			var url = "/EmailValidationSet(IvEmail='" + value + "')";
			oModel.read(url, {
				success: function(oData) {
					if (oData.EsReturn.Type === 'S') {
						this.validCompany = true;
						return true;
					} else {
						this.validCompany = false;
					}

				}.bind(this),
				error: function(oError) {
					return false;
				}.bind(this)
			});
		},
		changeDate: function(oVal) {

			if (oVal === undefined) {
				return "";
			} else {
				var dateString = oVal,
					formatted = dateString.substr(0, 2) + '/' + dateString.substr(2, 2) + '/' + dateString.substr(4);
				return formatted;
			}

		},
		checkMandatoryDocsUpload: function(oApplicantDetail, oDocumentUploadDetail) {

			var oModel = this.getView().getModel('Anonymous'),
				details = this.getView().getModel('Details'),
				aFilter = [];

			aFilter.push(new Filter("ProcessType", FilterOperator.EQ, "ANN"));
			aFilter.push(new Filter("BuildCat", FilterOperator.EQ, ""));
			aFilter.push(new Filter("BuildType", FilterOperator.EQ, ""));
			aFilter.push(new Filter("Constant", FilterOperator.EQ, details.getProperty('/CompanyDetails/BpNumber')));

			oModel.read("/DynamicAttachmentSet", {
				filters: aFilter,
				success: function(oData, response) {
					//	details.setProperty("/Attachments", oData.results);
					var data = {};
					for (var i = 0; i < oData.results.length; i++) {
						if (oData.results[i].OptionalFlag === 'M') {
							// var path = "/Mandatory/" + oData.results[i].DocumentId;
							// details.setProperty(path,true);
							data[oData.results[i].DocumentId] = true;

						}
					}
					details.setProperty("/Mandatory", data);

				}.bind(this),
				error: function() {}.bind(this)

			});

		},
		checkMandatoryDocsUploaded: function() {
			var details = this.getView().getModel("Details");
			var isDocsUploaded = [];
			this.docsUploaded = [];

			var id_QualDegree = details.getProperty("/Mandatory/Z0003");
			var id_EXPDOC = details.getProperty("/Mandatory/Z0002");
			var id_AuthDoc = details.getProperty("/Mandatory/Z0011");
			var id_DECForm = details.getProperty("/Mandatory/Z0004");
			var id_EXPDoc4 = details.getProperty("/Mandatory/Z0005");
			if (id_QualDegree) {
				var file1 = this.byId("id_QualDegree").getValue();
				if (!file1) {
					isDocsUploaded.push(false);
				} else {
					isDocsUploaded.push(true);
					this.docsUploaded.push("id_QualDegree");
				}
			} else {
				isDocsUploaded.push(true);
			}

			if (id_EXPDOC) {
				var file2 = this.byId("id_EXPDOC").getValue();
				if (!file2) {
					isDocsUploaded.push(false);
				} else {
					isDocsUploaded.push(true);
					this.docsUploaded.push("id_EXPDOC");
				}
			} else {
				isDocsUploaded.push(true);
			}

			if (id_AuthDoc) {
				var file3 = this.byId("id_AuthDoc").getValue();
				if (!file3) {
					isDocsUploaded.push(false);
				} else {
					isDocsUploaded.push(true);
					this.docsUploaded.push("id_AuthDoc");
				}
			} else {
				isDocsUploaded.push(true);
			}

			if (id_DECForm) {
				var file4 = this.byId("id_DECForm").getValue();
				if (!file4) {
					isDocsUploaded.push(false);
				} else {
					isDocsUploaded.push(true);
					this.docsUploaded.push("id_DECForm");
				}
			} else {
				isDocsUploaded.push(true);
			}

			if (id_EXPDoc4) {
				var file5 = this.byId("id_EXPDoc4").getValue();
				if (!file5) {
					isDocsUploaded.push(false);
				} else {
					isDocsUploaded.push(true);
					this.docsUploaded.push("id_EXPDoc4");
				}
			} else {
				isDocsUploaded.push(true);
			}

			if (isDocsUploaded.includes(false)) {
				var oBundle = this.getView().getModel("i18n").getResourceBundle();
				var msg = oBundle.getText("documentErrorMan");

				this.openMessageDialog("Error", msg);
				// MessageBox.error("Please upload all Mandatory Documents");
				return false;
			} else {
				return true;
			}

		},
		hanldeMobileLiveChange: function(event) {
			this.byId("admMobilebtn").setText("Verify");
			event.getSource().setShowValueHelp(false);
			this.verMob = false;
			var inputValue = event.getParameter("value");
			var inputField = event.getSource();
			var regex = /^5\d{8}$/;

			if (inputValue.length !== 9 || !regex.test(inputValue)) {
				// Display an error message or perform other actions
				inputField.setValueState(sap.ui.core.ValueState.Error);
				inputField.setValueStateText("Please enter a 9-digit number starting with '5'");
			} else {
				// Clear the error state and message
				inputField.setValueState(sap.ui.core.ValueState.None);
				inputField.setValueStateText("");
			}

		},
		onPressMobVerify: function(oEvent, resend) {
			var inputField = this.getView().byId("admMobile"),
				mobile = inputField.getValue(),
				payload = {
					"Zprtype": "CMM",
					"InputId": " ",
					"IdType": " ",
					"Zreference": " ",
					"Guid": " ",
					"Zvkont": " ",
					"Zgpart": " ",
					"Zmobile": mobile,
					"Zemail": "",
					"ZsmsSent": " ",
					"ZemailSent": " ",
					"Zotp": " ",
					"ZotpStat": " ",
					"ZotpExpirySms": " ",
					"ZotpExpiryEmail": " ",
					"Maxattempt": " ",
					"Zmessage": " ",
					"VendorBp": " ",
					"Otpmode": "S",
					"Servmode": "O",
					"Newpaswrd": " ",
					"Confirmnewpaswrd": " ",
					"PwdChangeStat": " "
				},
				validated = inputField.getValueState();
			if (this.verId) {
				if (mobile.includes("*")) {
					//In case of Mask Input Send Emirates Id in inputId field of payload
					payload.InputId = this.getView().byId("id_emIdNum").getValue();
					payload.IdType = "E";
					validated = "None";
				}
				if (validated === "None" && mobile !== "") {
					var oModel = this.getOwnerComponent().getModel("ForgotPassword");
					oModel.setHeaders({
						"X-REQUESTED-WITH": "XMLHttpRequest"
					});
					oModel.create("/ZCVI_FRGT_PWD_ENTITYSet", payload, {

						success: function(oData) {
							if (oData.ZotpStat === "S") {
								if (!resend || resend === 'undefined') {
									this.openMobileDialog();
								}
								if (resend) {
									this.timerForEmail("emailOtpTimer", "mobileOtpTimer");
								}
								this.ReferenceMob = oData.Zreference;

							}

						}.bind(this),
						error: function(oErr) {
							this.getView().setBusy(false);
							if (JSON.parse(oErr.responseText).error.message.value !== undefined) {
								this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
								//MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

							} else {
								this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
								//MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

							}
						}.bind(this)
					});
				} else {
					var oBundle = this.getView().getModel("i18n").getResourceBundle();
					var msg = oBundle.getText("mobileInformation");

					this.openMessageDialog("Error", msg);
					//	MessageBox.information("Provide valid mobile number");

				}
			} else {
				var oBundle = this.getView().getModel("i18n").getResourceBundle();
				var msg = oBundle.getText("invalidEmiratesDet");

				this.openMessageDialog("Error", msg);
				// MessageBox.error("Emirates Id or Exipiry Date not valid");
			}

		},
		onPressResendmobielOTP: function() {
			this.onPressMobVerify('', true);
		},
		handleEmailChange: function(event) {
			this.verEmail = false;
			this.byId("btnVerifyEmail").setText("Verify");
			event.getSource().setShowValueHelp(false);
			var emailValue = event.getParameter("value");
			var emailField = event.getSource();
			var emailRegex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

			if (!emailRegex.test(emailValue)) {
				// Display an error message or perform other actions
				emailField.setValueState(sap.ui.core.ValueState.Error);
				emailField.setValueStateText("Please enter a valid email address");
			} else {
				// Clear the error state and message
				emailField.setValueState(sap.ui.core.ValueState.None);
				emailField.setValueStateText("");
			}
		},
		onPressEmailVerify: function(oEvent, resend) {
			var validated = this.getView().byId('id_admEmail').getValueState();
			this.email = this.getView().byId('id_admEmail').getValue();
			var payload = {
				"Zprtype": "CMM",
				"InputId": " ",
				"IdType": " ",
				"Zreference": " ",
				"Guid": " ",
				"Zvkont": " ",
				"Zgpart": " ",
				"Zmobile": " ",
				"Zemail": this.email,
				"ZsmsSent": " ",
				"ZemailSent": " ",
				"Zotp": " ",
				"ZotpStat": " ",
				"ZotpExpirySms": " ",
				"ZotpExpiryEmail": " ",
				"Maxattempt": " ",
				"Zmessage": " ",
				"VendorBp": " ",
				"Otpmode": "S",
				"Servmode": "O",
				"Newpaswrd": " ",
				"Confirmnewpaswrd": " ",
				"PwdChangeStat": " "
			};
			if (this.verId) {
				if (this.email.includes("*")) {
					//In case of Mask Input Send Emirates Id in inputId field of payload
					payload.InputId = this.getView().byId("id_emIdNum").getValue();
					payload.IdType = "E";
					validated = "None";
				}
				if (validated === "None" && this.email !== "") {

					if (this.email.includes("*")) {

						var oModel = this.getOwnerComponent().getModel("ForgotPassword");
						oModel.setHeaders({
							"X-REQUESTED-WITH": "XMLHttpRequest"
						});
						oModel.create("/ZCVI_FRGT_PWD_ENTITYSet", payload, {

							success: function(oData) {
								if (oData.ZotpStat === "S") {
									if (!resend || resend === 'undefined') {
										this.openEmailDialog();
									}
									if (resend) {
										this.timerForEmail("emailOtpTimer", "emailOtpTimer");
									}
									this.Reference = oData.Zreference;
								}

							}.bind(this),
							error: function(oErr) {
								this.getView().setBusy(false);
								if (JSON.parse(oErr.responseText).error.message.value !== undefined) {
									this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
									// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

								} else {
									this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
									// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

								}
							}.bind(this)
						});
					} else {
						var oAnony = this.getView().getModel('Anonymous');

						var url = "/EmailValidationSet(IvEmail='" + this.email + "')";
						oAnony.read(url, {
							success: function(oData) {
								if (oData.EsReturn.Type === 'S') {
									var oModel = this.getOwnerComponent().getModel("ForgotPassword");
									oModel.setHeaders({
										"X-REQUESTED-WITH": "XMLHttpRequest"
									});
									oModel.create("/ZCVI_FRGT_PWD_ENTITYSet", payload, {

										success: function(oData) {
											if (oData.ZotpStat === "S") {
												if (!resend || resend === 'undefined') {
													this.openEmailDialog();
												}
												if (resend) {
													this.timerForEmail("emailOtpTimer", "emailOtpTimer");
												}
												this.Reference = oData.Zreference;
											}

										}.bind(this),
										error: function(oErr) {
											this.getView().setBusy(false);
											if (JSON.parse(oErr.responseText).error.message.value !== undefined) {
												this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
												// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

											} else {
												this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
												// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

											}
										}.bind(this)
									});
								} else {
									var oBundle = this.getView().getModel("i18n").getResourceBundle();
									var msg = oBundle.getText("invalidEmailError");
									this.openMessageDialog("Error", msg);
									// MessageBox.error("Provide valid company e-mail address");
								}

							}.bind(this),
							error: function(oError) {
								var oBundle = this.getView().getModel("i18n").getResourceBundle();
								var msg = oBundle.getText("invalidEmailError");
								this.openMessageDialog("Error", msg);
								// MessageBox.error("Provide valid company e-mail address");
							}.bind(this)
						});
					}

				} else {
					var oBundle = this.getView().getModel("i18n").getResourceBundle();
					var msg = oBundle.getText("invalidEmailError");
					this.openMessageDialog("Information", msg);
					// MessageBox.information("Provide valid company e-mail address");

				}
			} else {
				var oBundle = this.getView().getModel("i18n").getResourceBundle();
				var msg = oBundle.getText("invalidEmiratesDet");
				this.openMessageDialog("Error", msg);
				// MessageBox.error("Emirates Id or Exipiry Date not valid");

			}
		},
		onPressResendEmailOTP: function() {
			this.onPressEmailVerify('', true);
		},
		onVerifyEmail: function(sReference) {
			this.email = this.getView().byId('id_admEmail').getValue();
			var items = this.byId("otpHbox").getItems();
			// new Date().getDate() + (new Date().getMonth() + 1) + new Date().getFullYear()

			var payload = {
				"Zprtype": "CMM",
				"InputId": " ",
				"IdType": " ",
				"Zreference": this.Reference,
				"Guid": " ",
				"Zvkont": " ",
				"Zgpart": " ",
				"Zmobile": " ",
				"Zemail": this.email,
				"ZsmsSent": " ",
				"ZemailSent": " ",
				"Zotp": items[0].getValue() + items[1].getValue() + items[2].getValue() + items[3].getValue() + items[4].getValue() + items[5].getValue(),
				"ZotpStat": " ",
				"ZotpExpirySms": " ",
				"ZotpExpiryEmail": " ",
				"Maxattempt": " ",
				"Zmessage": " ",
				"VendorBp": " ",
				"Otpmode": "V",
				"Servmode": "O",
				"Newpaswrd": " ",
				"Confirmnewpaswrd": " ",
				"PwdChangeStat": " "
			};
			if (this.email.includes("*")) {
				//In case of Mask Input Send Emirates Id in inputId field of payload
				payload.InputId = this.getView().byId("id_emIdNum").getValue();
				payload.IdType = "E";
			}
			var that = this;
			this.getOwnerComponent().getModel("ForgotPassword").create("/ZCVI_FRGT_PWD_ENTITYSet", payload, {
				success: function(oData) {
					if (oData.ZotpStat === "V") {
						this.verEmail = true;
						this.getView().byId("id_admEmail").setShowValueHelp(true);
						this.getView().byId("btnVerifyEmail").setText("Verified");
						this.byId("idEmailVerifyDialog").close();
						var items = this.byId("otpHbox").getItems();
						items.forEach(function(item) {
							item.setValue("");
						});

						var oView = this.getView();
						if (!this.otpSuccessDialog) {
							this.otpSuccessDialog = Fragment.load({
								id: oView.getId(),
								name: "dewa.crmportal.ui.ZCRM_NEWADMINRG_S1.fragments.OtpSuccess",
								controller: this
							}).then(function(oDialog) {
								oView.addDependent(oDialog);
								return oDialog;
							});
						}
						this.otpSuccessDialog.then(function(oDialog) {
							scrollToCenter(that);
							oDialog.open();
							oView.byId("displayText").setText(oView.getModel("i18n").getResourceBundle().getText("emailverf"));
						});

					}

				}.bind(this),
				error: function(oErr) {
					this.getView().setBusy(false);
					this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

				}.bind(this)
			});
		},
		onVerifyMobile: function(sReference) {
			var mobile = this.getView().byId("admMobile").getValue();
			var items = this.byId("otpHboxMobile").getItems();
			// new Date().getDate() + (new Date().getMonth() + 1) + new Date().getFullYear()

			var payload = {
				"Zprtype": "CMM",
				"InputId": " ",
				"IdType": " ",
				"Zreference": this.ReferenceMob,
				"Guid": " ",
				"Zvkont": " ",
				"Zgpart": " ",
				"Zmobile": mobile,
				"Zemail": "",
				"ZsmsSent": " ",
				"ZemailSent": " ",
				"Zotp": items[0].getValue() + items[1].getValue() + items[2].getValue() + items[3].getValue() + items[4].getValue() + items[5].getValue(),
				"ZotpStat": " ",
				"ZotpExpirySms": " ",
				"ZotpExpiryEmail": " ",
				"Maxattempt": " ",
				"Zmessage": " ",
				"VendorBp": " ",
				"Otpmode": "V",
				"Servmode": "O",
				"Newpaswrd": " ",
				"Confirmnewpaswrd": " ",
				"PwdChangeStat": " "
			};
			if (mobile.includes("*")) {
				//In case of Mask Input Send Emirates Id in inputId field of payload
				payload.InputId = this.getView().byId("id_emIdNum").getValue();
				payload.IdType = "E";

			}
			var that = this;
			this.getOwnerComponent().getModel("ForgotPassword").create("/ZCVI_FRGT_PWD_ENTITYSet", payload, {
				success: function(oData) {
					if (oData.ZotpStat === "V") {
						var oView = this.getView();
						this.verMob = true;
						// this.getView().byId("idISOCodesApp").setEnabled(false);
						this.getView().byId("admMobilebtn").setText("Verified");
						this.getView().byId("admMobile").setShowValueHelp(true);
						this.byId("idMobileVerifyDialog").close();
						var items = this.byId("otpHboxMobile").getItems();
						items.forEach(function(item) {
							item.setValue("");
						});

						if (!this.otpSuccessDialog) {
							this.otpSuccessDialog = Fragment.load({
								id: oView.getId(),
								name: "dewa.crmportal.ui.ZCRM_NEWADMINRG_S1.fragments.OtpSuccess",
								controller: this
							}).then(function(oDialog) {
								oView.addDependent(oDialog);
								return oDialog;
							});
						}
						this.otpSuccessDialog.then(function(oDialog) {
							scrollToCenter(that);
							oDialog.open();
							oView.byId("displayText").setText(oView.getModel("i18n").getResourceBundle().getText("mobverf"));
						});

					}

				}.bind(this),
				error: function(oErr) {
					this.getView().setBusy(false);
					this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

				}.bind(this)
			});
		},
		onCloseOtpSuccess: function(oEvent) {
			this.byId("otpSuccessDialog").close();
			ResetHeight(this);
		},
		openEmailDialog: function(sReference) {
			var oView = this.getView();
			var that = this;
			if (!this._pDialogForEmail) {
				this._pDialogForEmail = sap.ui.core.Fragment.load({
					id: oView.getId(),
					name: "dewa.crmportal.ui.ZCRM_NEWADMINRG_S1.fragments.EmailVerificationDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this._pDialogForEmail.then(function(oDialog) {
				scrollToCenter(that);
				oDialog.open();
				that.timerForEmail("emailOtpTimer", "emailOtpTimer");
			}.bind(this));
		},
		openMobileDialog: function(sReference) {
			var oView = this.getView();
			var that = this;
			if (!this._pDialogForMobile) {
				this._pDialogForMobile = sap.ui.core.Fragment.load({
					id: oView.getId(),
					name: "dewa.crmportal.ui.ZCRM_NEWADMINRG_S1.fragments.MobileVerificationDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this._pDialogForMobile.then(function(oDialog) {
				scrollToCenter(that);
				oDialog.open();
				that.timerForEmail("emailOtpTimer", "mobileOtpTimer");
			}.bind(this));
		},
		encodeEmail: function(email) {
			return email.substring(0, 2) + email.substring(2, email.indexOf("@") + 1).replaceAll(/.(?=.)/g, "*") + email.substring(email.indexOf(
				"@") + 1, email.length);
		},
		timerForEmail: function(timerd, id) {

			var fiveMinutesLater = new Date();
			var scs = fiveMinutesLater.setMinutes(fiveMinutesLater.getMinutes() + 3);
			var countdowntime = scs;
			var that = this;
			clearInterval(this.x2);
			this.x2 = setInterval(function() {
				var now = new Date().getTime();
				var cTime = countdowntime - now;
				var minutes = Math.floor((cTime % (1000 * 60 * 60)) / (1000 * 60));
				var second = Math.floor((cTime % (1000 * 60)) / 1000);
				that.byId(id).setText(that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("enterOTPToEmail", that
					.encodeEmail(
						that.byId("id_admEmail").getValue())));
				that.byId(id).setText(that.getOwnerComponent().getModel("i18n").getResourceBundle().getText("sessionExpires") + " " + minutes +
					":" + second);
				if (cTime < 0) {
					clearInterval(that.x2);
					that.byId("idEmailVerifyDialog").close();
				}
			});
		},
		onPressSubmit: function() {
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			var msg = oBundle.getText("termsError");
			if(!this.byId("termsCheck").getSelected()){
				this.openMessageDialog("Error", msg);
				return;
			}
			var checkDocsUploaded = this.checkMandatoryDocsUploaded();
			if (checkDocsUploaded) {
				var oModel = this.getView().getModel('Anonymous'),
					CompanyDetails = this.getView().getModel('Details').getData().CompanyDetails,
					oEntry = this.getView().getModel('Details').getData().AdminDetails;
				oEntry.ActvDesc = CompanyDetails.ActvDesc;
				oEntry.BpNumber = CompanyDetails.BpNumber;
				oEntry.Department = CompanyDetails.Department;
				oEntry.City = CompanyDetails.City;
				oEntry.Nationality = this.getView().byId('idNationality').getSelectedKey();
				oEntry.Designation = this.getView().byId('idDesignationDD').getSelectedKey();
				oEntry.IdRespTodate = this.getView().byId('expDate_value').getValue();
				oEntry.EMail = CompanyDetails.EMail;
				oEntry.EMail2 = this.email;
				oEntry.Extension = CompanyDetails.Extension;
				oEntry.FExtension = CompanyDetails.FExtension;
				oEntry.Fax = CompanyDetails.Fax;
				oEntry.IdentNumber = CompanyDetails.IdentNumber;
				oEntry.Name1 = CompanyDetails.Name1;
				oEntry.OfficeLocation = CompanyDetails.OfficeLocation;
				oEntry.PoBox = CompanyDetails.PoBox;
				oEntry.Street = CompanyDetails.Street;
				oEntry.Telephone = CompanyDetails.Telephone;
				oEntry.VatNo = CompanyDetails.VatNo;
				delete oEntry.__metadata;
				if (this.sMode === "resubmit") {
					delete oEntry.CityDesc;
					delete oEntry.OfficeLocDesc;
					delete oEntry.IssuedByDesc;
					delete oEntry.ReqStsDes;
					delete oEntry.IssuedBy;
					delete oEntry.IssuedByDesc;
					// delete oEntry.RequestNo;
					oEntry.RequestNo = this.sRegistrationId;
				}
				this.getView().setBusy(true);
				oModel.create("/NewRegSet", oEntry, {
					success: function(oData, response) {
						this.getView().setBusy(false);

						BusyIndicator.hide();
						var that = this;
						that.docsActualUpload = [];
						that.countOfUpdate = 0;
						var oPromise;
						that.promise = [];
						var i = 0;
						// if (that.docsUploaded.length > 0) {

						// 		that.docsUploaded.forEach(function(value, index) {
						// 			i++;

						// 			oPromise = new Promise(function(resolve, reject) {
						// 				if (i === that.docsUploaded.length) {
						// 				that.fileUpload(oData.RequestNo, resolve, reject, value,"/X");
						// 				}else {
						//                                     that.fileUpload(oData.RequestNo, resolve, reject, value,"");
						//                                  }
						// 			});
						// 			that.promise.push(oPromise);
						// 		});
						// 		Promise.all(that.promise).then(function() {
						// 			that.setOpModel(oData);
						// 			that.byId("idCreateAccountWizard").setVisible(false);
						// 			that.getView().getModel("Details").setProperty("/Response", oData);
						// 			that.byId("submissionView").setVisible(true);
						// 			that.byId("idCreateConContPg").setShowHeader(false);
						// 			that.byId("idCreateConContPg").setShowSubHeader(false);
						// 			that.byId("idTitleWizard").setVisible(false);
						// 			that.byId("idSubTitleWizard").setVisible(false);

						// 		}, function() {
						// 			MessageBox.error("Document could not be uploaded");
						// 		});

						// }
						// if (that.docsUploaded.length > 0) {
						// 	var lastIndex = that.docsUploaded.length - 1;
						// 	var successCount = 0;
						// 	var promiseCount = 0;

						// 	that.docsUploaded.forEach(function(value, index) {
						// 		i++;
						// 		promiseCount++;

						// 		oPromise = new Promise(function(resolve, reject) {
						// 			if (index === lastIndex && successCount === (promiseCount - 1)) {
						// 				that.fileUpload(oData.RequestNo, resolve, reject, value, "/X");
						// 			} else {
						// 				that.fileUpload(oData.RequestNo, resolve, reject, value, "");
						// 			}
						// 		});

						// 		oPromise.then(function() {
						// 			successCount++;

						// 			if (successCount === promiseCount) {
						// 				that.setOpModel(oData);
						// 				that.byId("idCreateAccountWizard").setVisible(false);
						// 				that.getView().getModel("Details").setProperty("/Response", oData);
						// 				that.byId("submissionView").setVisible(true);
						// 				that.byId("idCreateConContPg").setShowHeader(false);
						// 				that.byId("idCreateConContPg").setShowSubHeader(false);
						// 				that.byId("idTitleWizard").setVisible(false);
						// 				that.byId("idSubTitleWizard").setVisible(false);
						// 			}
						// 		}).catch(function() {
						// 			MessageBox.error("Document could not be uploaded");
						// 		});

						// 		that.promise.push(oPromise);
						// 	});
						// }
						// if (that.docsUploaded.length > 0) {
						// 	var lastIndex = that.docsUploaded.length - 1;
						// 	var flag = true;

						// 	var promises = that.docsUploaded.map(function(value, index) {
						// 		return new Promise(function(resolve, reject) {
						// 			if (index === lastIndex && flag) {
						// 				that.fileUpload(oData.RequestNo, resolve, reject, value, "/X");
						// 			} else {
						// 				that.fileUpload(oData.RequestNo, resolve, reject, value, "");
						// 			}
						// 		});
						// 	});

						// 	Promise.all(promises).then(function() {
						// 		var allPromisesSuccessful = promises.every(function(promise) {
						// 			return promise.isResolved();
						// 		});

						// 		if (allPromisesSuccessful) {
						// 			that.setOpModel(oData);
						// 			that.byId("idCreateAccountWizard").setVisible(false);
						// 			that.getView().getModel("Details").setProperty("/Response", oData);
						// 			that.byId("submissionView").setVisible(true);
						// 			that.byId("idCreateConContPg").setShowHeader(false);
						// 			that.byId("idCreateConContPg").setShowSubHeader(false);
						// 			that.byId("idTitleWizard").setVisible(false);
						// 			that.byId("idSubTitleWizard").setVisible(false);
						// 		} else {
						// 			MessageBox.error("Document could not be uploaded");
						// 		}
						// 	});
						// }
						if (that.docsUploaded.length > 0) {
							var lastIndex = that.docsUploaded.length - 1;
							var resolvedCount = 0;

							var promises = that.docsUploaded.map(function(value, index) {
								return new Promise(function(resolve, reject) {
									if (index === lastIndex) {
										that.fileUpload(oData.RequestNo, resolve, reject, value, "/X");
									} else {
										that.fileUpload(oData.RequestNo, resolve, reject, value, "");
									}
								});
							});

							promises.forEach(function(promise) {
								promise.then(function() {
									resolvedCount++;

									if (resolvedCount === promises.length) {
										that.setOpModel(oData);
										that.byId("idCreateAccountWizard").setVisible(false);
										that.getView().getModel("Details").setProperty("/Response", oData);
										that.byId("submissionView").setVisible(true);
										that.byId("idCreateConContPg").setShowHeader(false);
										that.byId("idCreateConContPg").setShowSubHeader(false);
										that.byId("idTitleWizard").setVisible(false);
										that.byId("idSubTitleWizard").setVisible(false);
										ResetHeight(this);
									}
								}).catch(function() {
									//	MessageBox.error("Document could not be uploaded");
								});
							});
						}

					}.bind(this),
					error: function(oErr) {
						this.getView().setBusy(false);
						this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
						//	MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

					}.bind(this)
				});
			}

		},
		setOpModel: function(oResp) {
			var oViewModel = this.getView().getModel("Details");

			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "dd MMM yyyy | hh:mm:ss"
			});
			oViewModel.setProperty("/opDetails/submittedDate", oDateFormat.format(new Date()));
			oViewModel.setProperty("/opDetails/tradeLicenNo", oResp.IdentNumber);
			oViewModel.setProperty("/opDetails/companyName", oResp.Name1);
			oViewModel.setProperty("/opDetails/selCat", oResp.BuildCat);
			oViewModel.setProperty("/opDetails/selType", oResp.BuildTyp);
			oViewModel.setProperty("/opDetails/applicantName", oResp.Fullname);
			oViewModel.setProperty("/opDetails/enrollID", oResp.RequestNo);
			// this.byId("idRequestSubmittedText").setText(this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(
			// 	"requestSubmitted", oResp.RequestNo));

		},
		setFileIcon: function(oIcon, sType) {

			if (sType === 'application/pdf') {
				oIcon.setSrc("./img/PDF_Icon.png");
			} else if (sType === "image/png") {
				oIcon.setSrc("./img/PNG_Icon.png");
			} else if (sType === "image/jpeg") {
				oIcon.setSrc("./img/JPG_Icon.png");
			}
		},
		fileChange: function(oEvent) {
			var iconSrc, name;
			if (oEvent.getParameter("files").length > 0) {
				if (oEvent.getParameter("id").indexOf("id_QualDegree") > -1) {
					iconSrc = sap.ui.core.IconPool.getIconForMimeType(oEvent.getParameter("files")[0].type);
					name = oEvent.getParameter("files")[0].name;
					var sType = oEvent.getParameter("files")[0].type;
					this.setFileIcon(this.byId("idQualDegreeImg"), sType);
					//this.byId("idQualDegreeCopy").setIcon(iconSrc);
					this.byId("idQualDegreeCopy").setText(name);
					this.byId("oHBoxForQualDegree").setVisible(true);
				} else if (oEvent.getParameter("id").indexOf("id_EXPDOC") > -1) {
					iconSrc = sap.ui.core.IconPool.getIconForMimeType(oEvent.getParameter("files")[0].type);
					name = oEvent.getParameter("files")[0].name;
					var sType = oEvent.getParameter("files")[0].type;
					this.setFileIcon(this.byId("idEXPDOCImg"), sType);
					// this.byId("idEXPDOCCopy").setIcon(iconSrc);
					this.byId("idEXPDOCCopy").setText(name);
					this.byId("oHBoxForEXPDOC").setVisible(true);
				} else if (oEvent.getParameter("id").indexOf("id_AuthDoc") > -1) {
					iconSrc = sap.ui.core.IconPool.getIconForMimeType(oEvent.getParameter("files")[0].type);
					name = oEvent.getParameter("files")[0].name;
					var sType = oEvent.getParameter("files")[0].type;
					this.setFileIcon(this.byId("idAuthDocImg"), sType);
					//this.byId("idAuthDocCopy").setIcon(iconSrc);
					this.byId("idAuthDocCopy").setText(name);
					this.byId("oHBoxForAuthDoc").setVisible(true);
				} else if (oEvent.getParameter("id").indexOf("id_DECForm") > -1) {
					iconSrc = sap.ui.core.IconPool.getIconForMimeType(oEvent.getParameter("files")[0].type);
					name = oEvent.getParameter("files")[0].name;
					var sType = oEvent.getParameter("files")[0].type;
					this.setFileIcon(this.byId("idDECFormImg"), sType);
					// this.byId("idDECFormCopy").setIcon(iconSrc);
					this.byId("idDECFormCopy").setText(name);
					this.byId("oHBoxForDECForm").setVisible(true);
				} else if (oEvent.getParameter("id").indexOf("id_EXPDoc4") > -1) {
					iconSrc = sap.ui.core.IconPool.getIconForMimeType(oEvent.getParameter("files")[0].type);
					name = oEvent.getParameter("files")[0].name;
					var sType = oEvent.getParameter("files")[0].type;
					this.setFileIcon(this.byId("idEXPDoc4Img"), sType);
					// this.byId("idEXPDoc4Copy").setIcon(iconSrc);
					this.byId("idEXPDoc4Copy").setText(name);
					this.byId("oHBoxForEXPDoc4").setVisible(true);
				}

			}
		},
		onDeleteFile: function(oEvent) {
			var id = oEvent.getParameter("id");
			if (id.indexOf("idQualDegreeBtn") > -1) {
				this.byId("id_QualDegree").clear();
				this.byId("oHBoxForQualDegree").setVisible(false);
			} else if (id.indexOf("idEXPDOCBtn") > -1) {
				this.byId("id_EXPDOC").clear();
				this.byId("oHBoxForEXPDOC").setVisible(false);
			} else if (id.indexOf("idAuthDocBtn") > -1) {
				this.byId("id_AuthDoc").clear();
				this.byId("oHBoxForAuthDoc").setVisible(false);
			} else if (id.indexOf("idDECFormBtn") > -1) {
				this.byId("id_DECForm").clear();
				this.byId("oHBoxForDECForm").setVisible(false);
			} else if (id.indexOf("idEXPDoc4Btn") > -1) {
				this.byId("id_EXPDoc4").clear();
				this.byId("oHBoxForEXPDoc4").setVisible(false);
			}
		},
		fileSizeExceed: function() {
			this.openMessageDialog("Error", this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("fileSizeExceed"));
			// MessageBox.error(this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("fileSizeExceed"));

		},
		fileUpload: function(appNumber, resolve, reject, docType, xSlug) {

			BusyIndicator.show();
			var fileNameId = docType;

			var oFileUploader = this.byId(docType);

			var docId = oFileUploader.getProperty("name");
			var fileName = this.byId(fileNameId).getValue();
			this.csrfToken = this.getView().getModel("Anonymous").getSecurityToken();
			oFileUploader.setSendXHR(true);

			var header = new sap.ui.unified.FileUploaderParameter();
			header.setName('X-Requested-With');
			header.setValue('X');
			oFileUploader.addHeaderParameter(header);

			var headerParma = new sap.ui.unified.FileUploaderParameter();
			headerParma.setName('x-csrf-token');
			headerParma.setValue(this.csrfToken);
			oFileUploader.addHeaderParameter(headerParma);
			var headerParma2 = new sap.ui.unified.FileUploaderParameter();
			headerParma2.setName('slug');
			if (xSlug === "/X") {
				var slug = appNumber + "/" + docId + "/" + fileName + "/" + "ANN" + xSlug;
			} else {
				var slug = appNumber + "/" + docId + "/" + fileName + "/" + "ANN";
			}
			headerParma2.setValue(slug);
			oFileUploader.addHeaderParameter(headerParma2);
			oFileUploader.checkFileReadable().then(function() {
				try {
					oFileUploader.upload();
				} catch (err) {
					BusyIndicator.hide();
					oFileUploader.clear();
				}
				oFileUploader.destroyHeaderParameters();
			}, function(error) {
				BusyIndicator.hide();
				sap.m.MessageToast.show("The file cannot be read. It may have changed.");
				reject();
			}).then(function() {
				BusyIndicator.hide();
				oFileUploader.clear();
				resolve();
			}, function() {
				BusyIndicator.hide();
				oFileUploader.clear();
			});
		},
		changeTime: function(timeString) {
			if (timeString) {

				var hours = timeString.slice(0, 2);
				var minutes = timeString.slice(2, 4);
				var seconds = timeString.slice(4, 6);
				var time = hours + ':' + minutes + ':' + seconds;

				return time;
			} else {
				return "";
			}

		},
		verifyResubmitOTP: function(Requestid, resend) {
			var payload = {
				"Requestid": this.sRegistrationId,
				"Mobile": "",
				"Email": "",
				"ProcessType": "CMM",
				"Reference": "",
				"Otp": "",
				"Mode": "S",
				"SmsSent": "",
				"EmailSent": "",
				"OtpStat": "",
				"OtpExpirySms": "",
				"OtpExpiryEmail": "",
				"Maxattempt": ""
			};

			this.getOwnerComponent().getModel("Anonymous").create("/TrackAnnoyOtpVerificationSet", payload, {
				success: function(oData) {
					if (oData.OtpStat === "S") {
						if (!resend || resend === 'undefined') {
							this.openResubmitDialog(oData.Reference);
						}
						if (resend) {
							this.timerForEmail("emailOtpTimer", "resubmitOtpTimer");
						}
						var details = this.getView().getModel("Details");
						details.setProperty("/MaskedEmail", oData.Email);
						details.setProperty("/MaskedEmail", oData.Mobile);
						this.reSubReference = oData.Reference;
					}

				}.bind(this),
				error: function(oErr) {
					this.getView().setBusy(false);
					this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);
				}.bind(this)
			});
		},
		onPressResendResubmit: function() {
			this.verifyResubmitOTP(this.sRegistrationId, true);
		},
		openResubmitDialog: function() {
			var oView = this.getView();
			var that = this;
			if (!this._pDialogForResubmit) {
				this._pDialogForResubmit = sap.ui.core.Fragment.load({
					id: oView.getId(),
					name: "dewa.crmportal.ui.ZCRM_NEWADMINRG_S1.fragments.ResubmitVerificationDialog",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this._pDialogForResubmit.then(function(oDialog) {
				scrollToCenter(that);
				oDialog.open();
				oDialog.setEscapeHandler(function() {
					return;
				});

				that.timerForEmail("emailOtpTimer", "resubmitOtpTimer");
			}.bind(this));
		},
		onVerifyResubmit: function() {

			var items = this.byId("otpHboxResub").getItems();
			this.byId("idTxtRequestDisplay").setVisible(true);
			var payload = {
				"Requestid": this.sRegistrationId,
				"Mobile": "",
				"Email": "",
				"ProcessType": "CMM",
				"Reference": this.reSubReference,
				"Otp": items[0].getValue() + items[1].getValue() + items[2].getValue() + items[3].getValue() + items[4].getValue() +
					items[5].getValue(),
				"Mode": "V",
				"SmsSent": "",
				"EmailSent": "",
				"OtpStat": "",
				"OtpExpirySms": "",
				"OtpExpiryEmail": "",
				"Maxattempt": ""
			};

			this.getOwnerComponent().getModel("Anonymous").create("/TrackAnnoyOtpVerificationSet", payload, {
				success: function(oData) {

					if (oData.OtpStat === "V") {

						this.GetDetails(this.sRegistrationId, this.sMode);
						this.getView().byId("id_next").setEnabled(true);
						this.byId("idResubmitVerifyDialog").close();

					} else if (oData.OtpStat === "E") {

						var oBundle = this.getView().getModel("i18n").getResourceBundle();
						var msg = oBundle.getText("otpError");

						this.openMessageDialog("Error", msg);

						// MessageBox.error("OTP Not Verifed");

						this.byId("idResubmitVerifyDialog").close();

					}

				}.bind(this),
				error: function(oErr) {
					this.getView().setBusy(false);
					this.openMessageDialog("Error", JSON.parse(oErr.responseText).error.message.value);
					// MessageBox.error(JSON.parse(oErr.responseText).error.message.value);

				}.bind(this)
			});
		},
		escapeHandler: function() {
			return;
		},
		getAttachmetns: function() {
			var Requestid = this.getView().getModel("Details").getProperty("/CompanyDetails/RequestNo"),
				oModel = this.getView().getModel('Anonymous'),
				details = this.getView().getModel('Details'),
				aFilter = [];

			aFilter.push(new Filter("Requestid", FilterOperator.EQ, this.sRegistrationId));
			aFilter.push(new Filter("DocName", FilterOperator.EQ, ""));
			aFilter.push(new Filter("Element", FilterOperator.EQ, ""));
			var that = this;
			oModel.read("/ResubmitGetAttchmentsSet", {
				filters: aFilter,
				success: function(oData, response) {

					// oData.results[0].url = this.createDownlaodUrl(oData.results[0].Element, oData.results[0].DocName);
					details.setProperty("/Attachments", oData.results);

					oData.results.forEach(function(item) {
						if (item.Description === "Z0003") {
							item.url = that.createDownlaodUrl(item.Element, item.DocName);
							details.setProperty("/Attachments/Z0003", item);
							that.setFileIcon(that.byId("idQualDegreeImgDisplay"), item.ContentType);
							that.byId("idQualDegreeCopyDisplay").setVisible(true);
						} else if (item.Description === "Z0002") {
							item.url = that.createDownlaodUrl(item.Element, item.DocName);
							details.setProperty("/Attachments/Z0002", item);
							that.setFileIcon(that.byId("idEXPDOCImgDisplay"), item.ContentType);
							that.byId("oHBoxForEXPDOCDisplay").setVisible(true);
						} else if (item.Description === "Z0011") {
							item.url = that.createDownlaodUrl(item.Element, item.DocName);
							details.setProperty("/Attachments/Z0011", item);
							that.setFileIcon(that.byId("idAuthDocImgDisplay"), item.ContentType);
							that.byId("oHBoxForAuthDocDisplay").setVisible(true);
						} else if (item.Description === "Z0004") {
							item.url = that.createDownlaodUrl(item.Element, item.DocName);
							details.setProperty("/Attachments/Z0004", item);
							that.setFileIcon(that.byId("idDECFormImgDisplay"), item.ContentType);
							that.byId("oHBoxForDECFormDisplay").setVisible(true);
						} else if (item.Description === "Z0005") {
							item.url = that.createDownlaodUrl(item.Element, item.DocName);
							details.setProperty("/Attachments/Z0005", item);
							that.setFileIcon(that.byId("idEXPDoc4ImgDisplay"), item.ContentType);
							that.byId("oHBoxForEXPDoc4Display").setVisible(true);
						}
					});

				}.bind(this),
				error: function() {}.bind(this)

			});
		},
		createDownlaodUrl: function(Element, DocName) {
			var url = "";
			url = window.location.origin + this.getOwnerComponent().getModel("Anonymous").sServiceUrl +
				"/ResubmitGetAttchmentsSet(Requestid='',Element='" + Element + "',DocName='" + DocName + "')/$value";
			return url;

		},
		onDownload: function(oEvent) {
			var oStatus = oEvent.getSource(),
				oBinding = oStatus.getBinding("text").getPath(),
				path = oBinding.replace("/Filename", ""),
				data = this.getView().getModel('Details').getProperty(path);

			window.open(data.url, '_blank');

		},
		onPressTrackApplication: function() {
			var details = this.getView().getModel("Details"),
				requestId = details.getProperty("/Response").RequestNo;
			var sUrl = window.location.origin + "/irj/portal/anonymous/testatus?DynamicParameter=registrationId=" + requestId;
			window.open(sUrl, '_blank');
		},
		openMessageDialog: function(sSuccessMsg1, sSuccessMsg2, sSuccessMsg3) {
			var oView = this.getView();
			// create dialog lazily
			var that = this;
			if (!this._successDialog) {
				this._successDialog = sap.ui.core.Fragment.load({
					id: oView.getId(),
					name: "dewa.crmportal.ui.ZCRM_NEWADMINRG_S1.fragments.Message",
					controller: this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					return oDialog;
				});
			}
			this._successDialog.then(function(oDialog) {
				this.byId("idSuccessMsg1").setText(sSuccessMsg1);
				this.byId("idSuccessMsg2").setText(sSuccessMsg2);
				/*this.byId("idSuccessMsg3").setText(sSuccessMsg3);*/
				if (sSuccessMsg1 === "Success") {
					this.byId("idResponseImage").setSrc("./img/Success.png");
				} else if (sSuccessMsg1 === "Error") {
					this.byId("idResponseImage").setSrc("./img/Error.png");
				} else if (sSuccessMsg1 === "Information") {
					this.byId("idResponseImage").setSrc("./img/Information.png");
				} else if (sSuccessMsg1 === "Warning") {
					this.byId("idResponseImage").setSrc("./img/Warning.png");
				} else if (sSuccessMsg1 === "Confirm") {
					this.byId("idResponseImage").setSrc("./img/Confirm.png");
				}
				scrollToCenter(that);
				oDialog.open();
			}.bind(this));
		},
		onCloseMessageDialog: function(oEvent) {
			this.byId("idMessageDialog").close();

		},
		getTermsCondition: function(oEvent) {
			var oModel = this.getOwnerComponent().getModel("Anonymous");
			var hrefUrl = window.location.origin + oModel.sServiceUrl + "/TermsAndConditionsSet(ProcessType='ANN',DocId='T01')/$value";
			var text = "<p>I have read and understood the <a href=\"//"+hrefUrl+"\">Terms and Conditions</a> of Use</p>";
			this.getView().byId("termsText").setHtmlText(text);
		}

	});
});