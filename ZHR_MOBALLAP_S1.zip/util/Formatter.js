sap.ui.define([], function() {
	"use strict";
	return {

		previousCommentType: "XXX",
		formatAttachmentIcon: function(mime) {
			if (mime !== null || mime !== "") {
				return sap.ui.core.IconPool.getIconForMimeType(mime);
			}
		},
		visibilityTrigger: function(sValue) {

			//console.log("visibilityTrigger" + sValue);

			if (sValue === 'X') {

				return true;

			} else {

				return false;

			}

		},
		formatWorkHistory: function(sValue) {

			if (sValue === "OUT")

			{

				return "Outside";

			} else if (sValue === "OFF")

			{

				return "In Office";

			} else if (sValue === "IOO")

			{

				return "In and Outside Office";

			} else return sValue;

		},
		visibiltyZero: function(sValue) {

			if (sValue === 'YES') {

				return true;

			} else {

				return false;

			}

		},
		checkVisibility: function(sValue) {

			if (sValue && sValue.length > 0) {

				return true;

			} else {

				return false;

			}

		},

		checkBoxIsChecked: function(sValue) {

			if (sValue === 'X') {

				return true;

			} else {

				return false;

			}

		},
		escapeRegex: function(string) {

			return string.replace(/[\[\](){}?*+\^$\\.|\-]/g, "\\$&");

		},

		toTrim: function(str, characters, flags) {

			flags = flags || "g";

			if (typeof str !== "string" || typeof characters !== "string" || typeof flags !== "string") {

				throw new TypeError("argument must be string");

			}

			if (!/^[gi]*$/.test(flags)) {

				throw new TypeError("Invalid flags supplied '" + flags.match(new RegExp("[^gi]*")) + "'");

			}

			characters = cross.fnd.fiori.inbox.Upgrade.ZHR_MOBALLAP_S1.util.Formatter.escapeRegex(characters);

			return str.replace(new RegExp("^[" + characters + "]+|[" + characters + "]+$", flags), '');

		},

		visibilityText: function(sValue) {

			if (sValue == null || cross.fnd.fiori.inbox.Upgrade.ZHR_MOBALLAP_S1.util.Formatter.toTrim(sValue, "+*-_ ", undefined) == '') {

				return false;

			} else {

				return true;

			}

		},

		headerStatusFormat: function(sValue) {
			if (sValue !== undefined && sValue !== null) {
				//	console.log("headerStatusFormat:" + sValue + ":" + cross.fnd.fiori.inbox.Upgrade.ZHR_MOBALLAP_S1.util.Formatter.previousCommentType);

				if (sValue.trim() == cross.fnd.fiori.inbox.Upgrade.ZHR_MOBALLAP_S1.util.Formatter.previousCommentType) {

					return false;

				} else {

					cross.fnd.fiori.inbox.Upgrade.ZHR_MOBALLAP_S1.util.Formatter.previousCommentType = sValue;

					return true;

				}
			}
		},

		formatHeaderText: function(stype, svalue1, svalue2) {
			if (stype !== undefined) {

				//	console.log("formatHeaderText Type:" + stype + " value1:" + svalue1 + " value2:" + svalue2 + " previousT:" + 
				//	cross.fnd.fiori.inbox.Upgrade.ZHR_MOBALLAP_S1.util.Formatter.previousCommentType);

				if (stype.trim() == cross.fnd.fiori.inbox.Upgrade.ZHR_MOBALLAP_S1.util.Formatter.previousCommentType) {

					return svalue2;

				} else {

					return svalue1;

				}
			}
		},
		removeZero: function(num) {

			if (num == '' || num == null) {

				return num;

			} else

			{

				var rnum = parseInt(num, 10);

				return rnum;

			}

		},
		isValue: function(sValue) {

			if (sValue == 'X') {

				return "Yes";

			} else {

				return "No";

			}

		},
		toLower: function(str) {
			//	console.log("lower:" + str);
			if (str !== null && str !== '') {
				return str.toLowerCase();
			} else {
				return '';
			}

		},

		visibleCTEXT: function(str) {
			if (str === '1000' || str === '0400') {
				//	console.log("type" + str);
				return true;
			} else {

				return false;
			}
		},

		formatTimeValue: function(sValue) {

			if (sValue)

			{

				return sValue.replace(/:/g, " : ");

			} else return "";

		},

		dotFormatted: function(strVal) {

			if (strVal) {

				strVal = strVal.replace(/:/g, " : ");

				return strVal.replace(/\./g, " . ");

			}

			return;

		},
		visibilityRetDate: function(sValue) {

			if (sValue == 'PAEN_A') {

				return true;

			} else {

				return false;

			}

		},

		formatedDate: function(oDate) {

			if (oDate == null || oDate == "") {

				return "";

			} else {

				var formatter = sap.ui.core.format.DateFormat.getDateInstance({
					style: "medium"
				}, sap.ui.getCore().getConfiguration().getLocale());

				var oFormatDate = formatter.format(oDate, true);

				return oFormatDate;

			}

		}

	};
});