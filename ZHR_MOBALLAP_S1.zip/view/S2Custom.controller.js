/*
    Start of code change : The dependency on CDataManager has been removed and the standard DataManager is being used in all calls
*/
sap.ui.define([
	"sap/ui/thirdparty/jquery",
	"cross/fnd/fiori/inbox/util/Substitution",
	"cross/fnd/fiori/inbox/util/DataManager",
	"cross/fnd/fiori/inbox/controller/BaseController",
	"cross/fnd/fiori/inbox/util/MultiSelect",
	"cross/fnd/fiori/inbox/util/Forward",
	"cross/fnd/fiori/inbox/util/ForwardSimple",
	"cross/fnd/fiori/inbox/util/SupportInfo",
	"cross/fnd/fiori/inbox/util/Resubmit",
	"cross/fnd/fiori/inbox/util/TaskStatusFilterProvider",
	"cross/fnd/fiori/inbox/util/InboxFilterContributor",
	"cross/fnd/fiori/inbox/util/OutboxFilterContributor",
	"cross/fnd/fiori/inbox/util/ConfirmationDialogManager",
	"cross/fnd/fiori/inbox/util/ODataExtension",
	"cross/fnd/fiori/inbox/util/CommonFunctions",
	"cross/fnd/fiori/inbox/util/oDataReadExtension",
	"cross/fnd/fiori/inbox/util/Conversions",
	"cross/fnd/fiori/inbox/util/tools/Application",
	"cross/fnd/fiori/inbox/util/tools/CommonHeaderFooterHelper",
	"cross/fnd/fiori/inbox/util/Utils",
	"cross/fnd/fiori/inbox/Main.controller",
	"sap/base/Log",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Sorter",
	"sap/ui/model/Context",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/Device",
	"sap/ui/layout/VerticalLayout",
	"sap/ui/model/odata/OperationMode",
	"sap/ui/model/odata/CountMode",
	"sap/ui/core/CustomData",
	"sap/ui/core/Fragment",
	"sap/ui/core/format/DateFormat",
	"sap/m/ObjectListItem",
	"sap/m/ViewSettingsFilterItem",
	"sap/m/library",
	"sap/m/ViewSettingsItem",
	"sap/m/ViewSettingsCustomItem",
	"sap/m/List",
	"sap/m/StandardListItem",
	"sap/m/ViewSettingsDialog",
	"sap/m/Toolbar",
	"sap/m/Label",
	"sap/m/CheckBox",
	"sap/m/GroupHeaderListItem",
	"sap/m/MessageToast",
	/*    Start of code change
    Formatter.js being fetched on loading of the controller
    */
	"cross/fnd/fiori/inbox/ZHR_MOBALLAP_S1/util/Formatter"
	/*    End of code change
    Formatter.js being fetched on loading of the controller
    */
], function(q, S, D, B, M, F, c, d, R, T, I, O, C, e, f, o, g, A, l, U, m, L, J, n, p, r, s, t, V, u, v, w, x, y, z, E, G, H, K, N, P, Q,
	W, X, Y, Z, $, formatter) {
	"use strict";
	var _ = G.ButtonType;
	var a1 = G.ListMode;
	var b1 = G.ToolbarDesign;
	return sap.ui.controller("cross.fnd.fiori.inbox.ZHR_MOBALLAP_S1.view.S2Custom", {
		/*    Start of code change
        Formatter being instantiated
        */
		formatter: formatter,
		/*    End of code change
		Formatter being instantiated
		*/

		//    extHookChangeFilterItems: null,
		//    extHookChangeSortConfig: null,
		//    extHookChangeGroupConfig: null,
		//    extHookGetCustomFilter: null,
		//    extHookChangeMassApprovalButtons: null,
		//    extHookGetPropertiesToSelect: null,
		//    _FILTER_CATEGORY_PRIORITY: "Priority",
		//    _FILTER_PRIORITY_VERY_HIGH: "VERY_HIGH",
		//    _FILTER_PRIORITY_HIGH: "HIGH",
		//    _FILTER_PRIORITY_MEDIUM: "MEDIUM",
		//    _FILTER_PRIORITY_LOW: "LOW",
		//    _FILTER_CATEGORY_COMPLETION_DEADLINE: "CompletionDeadLine",
		//    _FILTER_EXPIRY_DATE_OVERDUE: "Overdue",
		//    _FILTER_EXPIRY_DATE_DUE_IN_7_DAYS: "DueIn7days",
		//    _FILTER_EXPIRY_DATE_DUE_IN_30_DAYS: "DueIn30days",
		//    _FILTER_EXPIRY_DATE_ALL: "All",
		//    _FILTER_CATEGORY_STATUS: "Status",
		//    _FILTER_CATEGORY_CREATION_DATE: "CreatedOn",
		//    _FILTER_CATEGORY_COMPLETED: "Completed",
		//    _FILTER_CATEGORY_SNOOZED: "ResumeIn",
		//    _FILTER_CATEGORY_TASK_DEFINITION_ID: "TaskDefinitionID",
		//    _FILTER_CATEGORY_SUBSTITUTED_USER: "SubstitutedUser",
		//    _SORT_CREATEDON: "CreatedOn",
		//    _SORT_CREATEDONREVERSE: "CreatedOnReverse",
		//    _SORT_CREATEDBYNAME: "CreatedByName",
		//    _SORT_PRIORITY: "Priority",
		//    _SORT_PRIORITY_NUMBER: "PriorityNumber",
		//    _SORT_TASKTITLE: "TaskTitle",
		//    _SORT_COMPLETIONDEADLINE: "CompletionDeadLine",
		//    _SORT_COMPLETEDON: "CompletedOn",
		//    _SORT_SAPORIGIN: "SAP__Origin",
		//    _SORT_INSTANCEID: "InstanceID",
		//    _SORT_TASKDEFINITIONID: "TaskDefinitionID",
		//    _SORT_TASKDEFINITIONNAME: "TaskDefinitionName",
		//    _SORT_STATUS: "Status",
		//    _SORT_CREATEDBY: "CreatedBy",
		//    _SORT_PROCESSOR: "Processor",
		//    _SORT_STARTDEADLINE: "StartDeadLine",
		//    _SORT_EXPIRYDATE: "ExpiryDate",
		//    _SORT_ISESCALATED: "IsEscalated",
		//    _SORT_HASCOMMENTS: "HasComments",
		//    _SORT_HASATTACHMENTS: "HasAttachments",
		//    _SORT_HASPOTENTIALOWNERS: "HasPotentialOwners",
		//    _SORT_CONTEXTSERVICEURL: "ContextServiceURL",
		//    _CUSTOM_NUMBER_LABEL: "CustomNumberLabel",
		//    _CUSTOM_NUMBER_VALUE: "CustomNumberValue",
		//    _CUSTOM_NUMBER_UNIT_LABEL: "CustomNumberUnitLabel",
		//    _CUSTOM_NUMBER_UNIT_VALUE: "CustomNumberUnitValue",
		//    _CUSTOM_OBJECT_ATTRIBUTE_LABEL: "CustomObjectAttributeLabel",
		//    _CUSTOM_OBJECT_ATTRIBUTE_VALUE: "CustomObjectAttributeValue",
		//    _GUI_LINK_SELECT_PROPERTY: "GUI_Link",
		//    _FUNCTION_IMPORT_DECISION: "Decision",
		//    _GROUP_SUPPORTSRELEASE: "SupportsRelease",
		//    _GROUP_STATUS_ORDER: [
		//        {
		//            Status: "READY",
		//            TextKey: "group.status.ready"
		//        },
		//        {
		//            Status: "IN_PROGRESS",
		//            TextKey: "group.status.in_progress"
		//        },
		//        {
		//            Status: "RESERVED",
		//            TextKey: "group.status.reserved"
		//        },
		//        {
		//            Status: "EXECUTED",
		//            TextKey: "group.status.executed"
		//        },
		//        {
		//            Status: "FOR_RESUBMISSION",
		//            TextKey: "group.status.suspended"
		//        },
		//        {
		//            Status: "COMPLETED",
		//            TextKey: "group.status.completed"
		//        }
		//    ],
		//    aItemContextPathsToSelect: [],
		//    complexFilter: {
		//        Priority: [],
		//        CompletionDeadLine: [],
		//        TaskDefinitionID: [],
		//        SubstitutedUser: [],
		//        Status: [],
		//        CreatedOn: [],
		//        CustomNumberValue: [],
		//        CustomNumberUnitValue: [],
		//        CustomObjectAttributeValue: []
		//    },
		//    sSearchPattern_Support: "",
		//    sFilterKey_Support: "",
		//    sSortKey_Support: "",
		//    sGroupkey_Support: "",
		//    oConfirmationDialogManager: C,
		//    oDataExtension: new e(),
		//    bHideHeaderFooterOptions: null,
		//    bEnteringMultiSelectMode: null,
		/*    Start of code change
        The additional fields for the Task Entity is being added to the $select properties
        */
		aSelectProperties: [
			"SAP__Origin",
			"InstanceID",
			"TaskDefinitionID",
			"TaskDefinitionName",
			"TaskTitle",
			"CreatedByName",
			"CreatedBy",
			"CompletionDeadLine",
			"SubstitutedUserName",
			"Status",
			"Priority",
			"PriorityNumber",
			"HasComments",
			"HasAttachments",
			"HasPotentialOwners",
			"CreatedOn",
			"TaskSupports",
			"SupportsClaim",
			"SupportsRelease",
			"SupportsForward",
			"SupportsComments",
			"SupportsAttachments",
			"EmployeeID",
			"EmployeeName",
			"Designation",
			"Grade",
			"JoiningDate",
			"AllowanceNumber",
			"ApplicationStatus",
			"AllowanceRequested",
			"PhoneNumber",
			"IncomingCalls",
			"OutgoingCalls",
			"WorkingHistory",
			"ZeroFacility",
			"LandlineFacility",
			"LandlineNumber",
			"PreviousAllowance",
			"EmployeeRemarks",
			"AllowanceApproved",
			"StartDate",
			"EndDate",
			"ManagerRemarks",
			"Message"

		],
		/*    End of code change
        The additional fields for the Task Entity is being added to the $select properties
        */
		//    aSelectPropertiesOutbox: [
		//        "CompletedOn",
		//        "ResumeOn"
		//    ],
		//    sCustomObjectAttributeValue: "CustomObjectAttributeValue",
		//    sCustomAttributeDataProperty: "CustomAttributeData",
		//    onInit: function () {
		//        if (this.getList().getItems().length > 0) {
		//            this.getList().removeItem(0);
		//        }
		//        this.bInitList = true;
		//        this.bEnteringMultiSelectMode = false;
		//        var a = this.getOwnerComponent();
		//        a.setModel(new J([]), "taskDefinitionsModel");
		//        var b = a.getEventBus();
		//        b.subscribe("cross.fnd.fiori.inbox", "multiselect", this.onMultiSelectEvent, this);
		//        b.subscribe("cross.fnd.fiori.inbox", "open_supportinfo", this.onSupportInfoOpenEvent, this);
		//        b.subscribe("cross.fnd.fiori.inbox.dataManager", "multiSelectFilterCompleted", q.proxy(this.onMultiSelectFilterCompleted, this));
		//        b.subscribe("cross.fnd.fiori.inbox.dataManager", "multiSelectFilterFailed", q.proxy(this.onMultiSelectFilterFailed, this));
		//        b.subscribe("cross.fnd.fiori.inbox.dataManager", "taskCollectionFailed", q.proxy(this.onTaskCollectionFailed, this));
		//        b.subscribe("cross.fnd.fiori.inbox.dataManager", "showReleaseLoader", q.proxy(this.onShowReleaseLoader, this));
		//        b.subscribe("cross.fnd.fiori.inbox.dataManager", "refreshOnError", q.proxy(this.onRefreshOnError, this));
		//        b.subscribe("cross.fnd.fiori.inbox", "refreshListInternal", q.proxy(this.onRefreshListInternal, this));
		//        b.subscribe("cross.fnd.fiori.inbox", "storeNextItemsToSelect", q.proxy(this.findNextVisibleItem, this));
		//        this.iTotalFilteredItems = 0;
		//        this.sResubmitUniqueId = this.createId() + "DLG_RESUBMIT";
		//        this.oDataManager = a.getDataManager();
		//        var h = this.getView().getModel();
		//        if (!this.oDataManager) {
		//            this.oDataManager = new D(this);
		//            this.oDataManager.setModel(h);
		//            a.setDataManager(this.oDataManager);
		//        }
		//        if (this.oDataManager.getShowAdditionalAttributes() === true) {
		//            a.setModel(new J({}), "customAttributeDefinitionsModel");
		//        }
		//        var j = this.getOwnerComponent().getModel();
		//        o.overrideRead(j);
		//        this.oDataExtension.overrideBindList(j).overrideProcessSuccess(j).overrideImportData(j);
		//        this.overrideMHFHelperSetMasterTitle();
		//        this.overrideMHFHelperFooterHandling();
		//        this.getView().setModel(j);
		//        this.getView().getModel().attachRequestFailed(q.proxy(this.handleRequestFailed, this));
		//        this.getView().getModel().attachRequestCompleted(q.proxy(this.handleRequestCompleted, this));
		//        this.getView().getModel().attachMetadataFailed(q.proxy(this.handleMetadataFailed, this));
		//        this.getView().getModel().setSizeLimit(this.oDataManager.getListSize());
		//        this.getView().byId("list").addEventDelegate({
		//            onsapselect: function (i) {
		//                if (!this.getView().getController().isMultiSelectActive() && i.srcControl instanceof z) {
		//                    var c1 = this.getView().getModel("i18n").getResourceBundle().getText("XACT_INFO_on_TASK_SELECT");
		//                    var d1 = document.createElement("span");
		//                    var id = "__InvisibleText_Details_View" + Date.now();
		//                    d1.setAttribute("id", id);
		//                    d1.setAttribute("aria-live", "assertive");
		//                    document.body.appendChild(d1);
		//                    window.setTimeout(function () {
		//                        document.getElementById(id).innerHTML = c1;
		//                    }, 50);
		//                    window.setTimeout(function () {
		//                        document.body.removeChild(document.getElementById(id));
		//                    }, 500);
		//                }
		//            }
		//        }, this);
		//        if (this.oDataManager.getPagingEnabled()) {
		//            this.getList().setGrowing(true).setGrowingScrollToLoad(true).setGrowingThreshold(this.oDataManager.getPageSize());
		//        }
		//        this.oRouter = this.getOwnerComponent().getRouter();
		//        this.oRouter.attachRouteMatched(function (c1) {
		//            if (c1.getParameter("name") === "master" || (c1.getParameter("name") === "detail" || c1.getParameter("name") === "empty") && !this.bIsMasterInited) {
		//                if (this.bIsMasterInited) {
		//                    if (t.system.phone) {
		//                        var d1 = this.getList();
		//                        d1.removeSelections(true);
		//                        this.sBindingContextPath = null;
		//                    }
		//                    return;
		//                }
		//                var e1 = this;
		//                this.oDataManager.attachItemRemoved(q.proxy(this._handleItemRemoved, this));
		//                this.oDataManager.attachActionPerformed(q.proxy(this.fnHandleActionPerformed, this));
		//                this.sInfoHeaderGroupString = null;
		//                this.sInfoHeaderFilterString = null;
		//                this.bDisplaySortOption = false;
		//                this.sDefaultSortKey = this.oDataManager.bOutbox ? this._SORT_COMPLETEDON : this._SORT_CREATEDON;
		//                this.sSortKey = null;
		//                this.aVisibleSortItems = [];
		//                var f1 = function (i) {
		//                    return function () {
		//                        return e1.sBackendDefaultSortKey === i;
		//                    };
		//                };
		//                this.oSortConfig = {};
		//                this.oSortConfig[this._SORT_CREATEDONREVERSE] = {
		//                    text: "{i18n>sort.createdOnReverse}",
		//                    getVisible: f1(this._SORT_CREATEDONREVERSE)
		//                };
		//                this.oSortConfig[this._SORT_CREATEDBYNAME] = { text: "{i18n>sort.createdByName}" };
		//                this.oSortConfig[this._SORT_PRIORITY] = {
		//                    text: "{i18n>sort.priority}",
		//                    descending: true
		//                };
		//                this.oSortConfig[this._SORT_TASKTITLE] = { text: "{i18n>sort.taskTitle}" };
		//                this.oSortConfig[this._SORT_SAPORIGIN] = {
		//                    text: "{i18n>sort.sapOrigin}",
		//                    getVisible: f1(this._SORT_SAPORIGIN)
		//                };
		//                this.oSortConfig[this._SORT_INSTANCEID] = {
		//                    text: "{i18n>sort.instanceID}",
		//                    getVisible: f1(this._SORT_INSTANCEID)
		//                };
		//                this.oSortConfig[this._SORT_TASKDEFINITIONID] = {
		//                    text: "{i18n>sort.taskDefinitionID}",
		//                    getVisible: f1(this._SORT_TASKDEFINITIONID)
		//                };
		//                this.oSortConfig[this._SORT_TASKDEFINITIONNAME] = {
		//                    text: "{i18n>sort.taskDefinitionName}",
		//                    getVisible: f1(this._SORT_TASKDEFINITIONNAME)
		//                };
		//                this.oSortConfig[this._SORT_STATUS] = {
		//                    text: "{i18n>sort.status}",
		//                    getVisible: f1(this._SORT_STATUS)
		//                };
		//                this.oSortConfig[this._SORT_CREATEDBY] = {
		//                    text: "{i18n>sort.createdBy}",
		//                    getVisible: f1(this._SORT_CREATEDBY)
		//                };
		//                this.oSortConfig[this._SORT_PROCESSOR] = {
		//                    text: "{i18n>sort.processor}",
		//                    getVisible: f1(this._SORT_PROCESSOR)
		//                };
		//                this.oSortConfig[this._SORT_STARTDEADLINE] = {
		//                    text: "{i18n>sort.startDeadLine}",
		//                    getVisible: f1(this._SORT_STARTDEADLINE)
		//                };
		//                this.oSortConfig[this._SORT_EXPIRYDATE] = {
		//                    text: "{i18n>sort.expiryDate}",
		//                    getVisible: f1(this._SORT_EXPIRYDATE)
		//                };
		//                this.oSortConfig[this._SORT_ISESCALATED] = {
		//                    text: "{i18n>sort.isEscalated}",
		//                    descending: true,
		//                    getVisible: f1(this._SORT_ISESCALATED)
		//                };
		//                this.oSortConfig[this._SORT_HASCOMMENTS] = {
		//                    text: "{i18n>sort.hasComments}",
		//                    descending: true,
		//                    getVisible: f1(this._SORT_HASCOMMENTS)
		//                };
		//                this.oSortConfig[this._SORT_HASATTACHMENTS] = {
		//                    text: "{i18n>sort.hasAttachments}",
		//                    descending: true,
		//                    getVisible: f1(this._SORT_HASATTACHMENTS)
		//                };
		//                this.oSortConfig[this._SORT_HASPOTENTIALOWNERS] = {
		//                    text: "{i18n>sort.hasPotentialOwners}",
		//                    getVisible: f1(this._SORT_HASPOTENTIALOWNERS)
		//                };
		//                this.oSortConfig[this._SORT_CONTEXTSERVICEURL] = {
		//                    text: "{i18n>sort.contextServiceURL}",
		//                    getVisible: f1(this._SORT_CONTEXTSERVICEURL)
		//                };
		//                if (!this.oDataManager.bOutbox) {
		//                    this.oSortConfig[this._SORT_CREATEDON] = {
		//                        text: "{i18n>sort.createdOn}",
		//                        descending: true,
		//                        getVisible: f1(this._SORT_CREATEDON)
		//                    };
		//                    this.oSortConfig[this._SORT_COMPLETIONDEADLINE] = { text: "{i18n>sort.completionDeadLine}" };
		//                } else {
		//                    this.oSortConfig[this._SORT_COMPLETEDON] = {
		//                        text: "{i18n>sort.completedOn}",
		//                        descending: true
		//                    };
		//                }
		//                if (this.extHookChangeSortConfig) {
		//                    this.extHookChangeSortConfig(this.oSortConfig);
		//                }
		//                this.oGroupConfigItem = null;
		//                this.bGroupDescending = false;
		//                this.aGroupConfig = [];
		//                this.aGroupConfig.push({
		//                    key: this._SORT_PRIORITY,
		//                    textKey: "group.priority",
		//                    formatter: function (i) {
		//                        var g1 = i.getProperty(e1._SORT_SAPORIGIN);
		//                        var h1 = i.getProperty(e1._SORT_PRIORITY);
		//                        return g.formatterPriority.call(e1.getView(), g1, h1);
		//                    }
		//                });
		//                this.aGroupConfig.push({
		//                    key: this._SORT_TASKDEFINITIONNAME,
		//                    textKey: "group.taskType",
		//                    formatter: function (i) {
		//                        var g1 = i.getProperty(e1._SORT_TASKDEFINITIONNAME);
		//                        return g1;
		//                    }
		//                });
		//                this.aGroupConfig.push({
		//                    key: this._SORT_STATUS,
		//                    textKey: "group.status",
		//                    formatter: function (g1) {
		//                        var h1 = e1.getView().getModel("i18n").getResourceBundle();
		//                        var i1 = g1.getProperty(e1._SORT_STATUS);
		//                        var j1;
		//                        for (var i = 0; i < e1._GROUP_STATUS_ORDER.length; i++) {
		//                            var k1 = e1._GROUP_STATUS_ORDER[i];
		//                            if (k1.Status == i1) {
		//                                j1 = k1.TextKey;
		//                                break;
		//                            }
		//                        }
		//                        return h1.getText(j1);
		//                    }
		//                });
		//                if (!this.oDataManager.bOutbox) {
		//                    this.aGroupConfig.push({
		//                        key: this._GROUP_SUPPORTSRELEASE,
		//                        textKey: "group.reservation",
		//                        formatter: function (i) {
		//                            var g1 = e1.getView().getModel("i18n").getResourceBundle();
		//                            var h1 = i.getProperty(e1._GROUP_SUPPORTSRELEASE) ? "group.reservation.reserved" : "group.reservation.notReserved";
		//                            return g1.getText(h1);
		//                        }
		//                    });
		//                }
		//                if (this.extHookChangeGroupConfig) {
		//                    this.extHookChangeGroupConfig(this.aGroupConfig);
		//                }
		//                this.bDisplayMultiSelectButton = false;
		//                this.clearDecisionButtons();
		//                this.oSubHeader = this.getPage().getSubHeader();
		//                var h = this.getView().getModel();
		//                if (h) {
		//                    if (!this.oDataManager.oModel.getServiceMetadata()) {
		//                        this.oDataManager.oModel.attachMetadataLoaded(q.proxy(function () {
		//                            this.loadInitialAppData();
		//                        }, this));
		//                    } else {
		//                        this.loadInitialAppData();
		//                    }
		//                }
		//                this.bIsMasterInited = true;
		//                if (c1.getParameter("name") === "detail") {
		//                    this.sBindingContextPath = "/" + c1.getParameter("arguments").contextPath;
		//                }
		//            } else if (c1.getParameter("name") === "detail") {
		//                this.sBindingContextPath = "/" + c1.getParameter("arguments").contextPath;
		//            }
		//            if (c1.getParameter("name") === "detail" || c1.getParameter("name") === "empty") {
		//                if (this.oDataManager.bOutbox) {
		//                    g.setShellTitleToOutbox(this.getOwnerComponent(), "cross.fnd.fiori.inbox.view.S2");
		//                } else {
		//                    g.setShellTitleToInbox(this.getOwnerComponent(), "cross.fnd.fiori.inbox.view.S2");
		//                }
		//            }
		//        }, this);
		//        this.iRequestCountStart++;
		//        this.aTaskTypeFilterItemsOrigins = [];
		//        this.bGUILinkSelectPropertySupported = false;
		//        this.getAppImp().oMHFHelper.defineMasterHeaderFooter(this);
		//        var k = q.proxy(function () {
		//            if (this.emptyList()) {
		//                var i = this.getPage();
		//                if (i) {
		//                    i.removeContent(this.emptyList());
		//                }
		//                this.emptyList().destroy();
		//                if (this._oControlStore && this._oControlStore.oMasterSearchField) {
		//                    this._oControlStore.oMasterSearchField.destroy();
		//                    delete this._oControlStore.oMasterSearchField;
		//                }
		//            }
		//        }, this);
		//        cross.fnd.fiori.inbox.util.tools.Application.getImpl().registerExitModule(k);
		//        b.subscribe("cross.fnd.fiori.inbox", "clearSelection", this._clearSelection, this);
		//    },
		//    _clearSelection: function () {
		//        var a = this.getList(), k = this.getAppImp().oConfiguration.keepMultiSelection();
		//        if (a && (a.getMode() !== a1.MultiSelect || !k)) {
		//            a.removeSelections(true);
		//        }
		//    },
		//    noItemFoundForContext: function () {
		//        if (t.system.phone) {
		//            var a = this.getSplitContainer();
		//            a.to(this.getView(), "show");
		//        } else {
		//            this.oRouter.navTo("empty", null, true);
		//        }
		//    },
		//    _areItemsUniqueByTaskType: function () {
		//        var a = this.getList().getItems();
		//        if (!a || a.length === 0) {
		//            return false;
		//        }
		//        var b = 0;
		//        var h = a[b].getBindingContext();
		//        if (!h) {
		//            if (a.length === 1) {
		//                return false;
		//            }
		//            b += 1;
		//            h = a[b].getBindingContext();
		//        }
		//        var j;
		//        var i, k;
		//        for (i = b + 1, k = a.length; i < k; i++) {
		//            j = a[i].getBindingContext();
		//            if (j && j.getProperty("TaskDefinitionID") != h.getProperty("TaskDefinitionID")) {
		//                return false;
		//            }
		//        }
		//        return true;
		//    },
		//    _handleItemRemoved: function (a) {
		//        if (!t.system.phone) {
		//            var b = this.getList().getSelectedItem();
		//            var h = this.getDetailNavigationParameters(b);
		//            h.InstanceID += ":";
		//            this.oRouter.navTo(this.getDetailRouteName(), h, true);
		//        }
		//    },
		//    handleRequestFailed: function (a) {
		//        var b = this.getList();
		//        var h = this.getView().getModel("i18n").getResourceBundle().getText("view.Workflow.noItemsAvailable");
		//        b.setNoDataText(h);
		//    },
		//    getTotalTaskCount: function (a) {
		//        if (this.oDataManager.getPagingEnabled()) {
		//            var b = new RegExp("TaskCollection[?]");
		//            if (b.test(a.getParameter("url"))) {
		//                var h = JSON.parse([a.getParameter("response").responseText]);
		//                if (h && h.d) {
		//                    this.iTaskCount = parseInt(h.d.__count, 10);
		//                    this.bTaskCountFromTaskCollectionCall = true;
		//                }
		//            }
		//        }
		//    },
		//    handleRequestCompleted: function (a) {
		//        this.getTotalTaskCount(a);
		//    },
		//    fnHandleActionPerformed: function (a) {
		//        this.isActionPerformed = true;
		//    },
		//    _handleItemPress: function (a) {
		//        this.setListItem(a.getSource());
		//    },
		//    getList: function () {
		//        return this.byId("list");
		//    },
		//    emptyList: function () {
		//        return this.byId("emptyList");
		//    },
		//    setListItem: function (i) {
		//        var a = this.getList();
		//        a.removeSelections();
		//        i.setSelected(true);
		//        a.setSelectedItem(i, true);
		//        this.oRouter.navTo("detail", {
		//            SAP__Origin: i.getBindingContext().getProperty("SAP__Origin"),
		//            InstanceID: i.getBindingContext().getProperty("InstanceID"),
		//            contextPath: i.getBindingContext().getPath().substr(1)
		//        }, !t.system.phone);
		//    },
		//    fnFindAndSelectNextTaskAfterAction: function (a) {
		//        if (this.isMultiSelectActive()) {
		//            this._handleMultiSelectProcessing();
		//            return;
		//        }
		//        this.iTotalFilteredItems = this.getList().getItems().length;
		//        if (this.iTotalFilteredItems === 0) {
		//            var b = this.getView().getModel("i18n").getResourceBundle().getText("view.Workflow.noItemsAvailable");
		//            this.emptyList().setNoDataText(b);
		//            var h = false;
		//            this.setListsVisibility(h);
		//            if (!t.system.phone) {
		//                this.oRouter.navTo("empty", null, true);
		//                if (!t.system.phone && this.oDataManager && this.oDataManager.bOutbox) {
		//                    g.setShellTitleToOutbox(this.getOwnerComponent(), "cross.fnd.fiori.inbox.view.S2");
		//                }
		//            }
		//            return;
		//        }
		//        var i = this.getList().getItems();
		//        var j = this.getList().getSelectedItem();
		//        if (this.aItemContextPathsToSelect.length !== 0 && i.length > 0 && !t.system.phone) {
		//            var k = false;
		//            for (var c1 = 0; c1 < this.aItemContextPathsToSelect.length; c1++) {
		//                var d1 = this.aItemContextPathsToSelect[c1];
		//                if (k) {
		//                    break;
		//                }
		//                for (var e1 = 0; e1 < i.length; e1++) {
		//                    var f1 = i[e1].getBindingContext();
		//                    if (f1 && f1 == d1) {
		//                        k = true;
		//                        if (j !== null) {
		//                            var g1 = j.getBindingContext();
		//                            if (d1 == g1) {
		//                                if (!this.bInitList) {
		//                                    var h1 = {}, i1;
		//                                    i1 = this.oDataManager.getTableView() && (!t.system.phone || this.oDataManager.getTableViewOnPhone());
		//                                    h1.bIsTableViewActive = i1;
		//                                    this.oDataManager.fireRefreshDetails(h1);
		//                                }
		//                            } else {
		//                                this.setListItem(i[e1]);
		//                            }
		//                        } else {
		//                            this.setListItem(i[e1]);
		//                        }
		//                        break;
		//                    }
		//                }
		//            }
		//            if (!k) {
		//                if (this.aItemContextPathsToSelect.length === 2 && this.aItemContextPathsToSelect[0] === this.aItemContextPathsToSelect[1]) {
		//                    if (this.iTotalFilteredItems == 0) {
		//                        this.noItemFoundForContext();
		//                    } else {
		//                        for (var j1 = 0; j1 < i.length; j1++) {
		//                            if (i[j1].getVisible()) {
		//                                this.setListItem(i[j1]);
		//                                break;
		//                            }
		//                        }
		//                    }
		//                } else {
		//                    this.selectIteminListforDeepLink();
		//                }
		//            }
		//        } else {
		//            if (i.length > 0) {
		//                this.selectIteminListforDeepLink();
		//            } else {
		//                if (!this.oDataManager.getCallFromDeepLinkURL()) {
		//                    this.oRouter.navTo("master", null, true);
		//                    this.oRouter.navTo("empty", null, true);
		//                    if (!t.system.phone && this.oDataManager && this.oDataManager.bOutbox) {
		//                        g.setShellTitleToOutbox(this.getOwnerComponent(), "cross.fnd.fiori.inbox.view.S2");
		//                    }
		//                } else {
		//                    this.oDataManager.setCallFromDeepLinkURL(false);
		//                }
		//            }
		//        }
		//        this.bInitList = false;
		//    },
		//    selectIteminListforDeepLink: function () {
		//        if (this.getList().getItems().length > 0) {
		//            this._selectItemByCtxtPath();
		//            return true;
		//        }
		//        return false;
		//    },
		//    _handleMultiSelectProcessing: function () {
		//        if (this.isMultiSelectActive()) {
		//            var a = this.getList().getItems();
		//            if (a.length !== 0) {
		//                var b = undefined;
		//                var i = 0;
		//                do {
		//                    b = a[i].getBindingContext();
		//                    i++;
		//                } while (!b);
		//                if (this.oDataManager.getShowAdditionalAttributes() === true) {
		//                    this.downloadCustomAttributeDefinition(b.getProperty("SAP__Origin"), b.getProperty("TaskDefinitionID"));
		//                }
		//                this.downloadDecisionOptions(b.getProperty("SAP__Origin"), b.getProperty("InstanceID"), b.getProperty("TaskDefinitionID"));
		//            } else {
		//                this.setMultiSelectButtonActive(true);
		//                if (!t.system.phone) {
		//                    this.oRouter.navTo("multi_select_summary", {}, true);
		//                }
		//                if (this.oDataManager.getShowAdditionalAttributes() === true) {
		//                    var h = this.getOwnerComponent().getModel("customAttributeDefinitionsModel");
		//                    h = {};
		//                    M.customAttributeDefinitionsLoaded = new q.Deferred();
		//                }
		//            }
		//            return;
		//        }
		//    },
		//    _selectItemByCtxtPath: function () {
		//        if (this.sBindingContextPath) {
		//            if (this._itemByContextPathSelected()) {
		//                return;
		//            }
		//            var i = this.findItemByContextPath(this.sBindingContextPath);
		//            var b = this.getView().getModel().getProperty(this.sBindingContextPath) ? true : false;
		//            if (i && q.isEmptyObject(i.getBindingContext())) {
		//                var a = new p(this.getView().getModel(), this.sBindingContextPath);
		//                i.setBindingContext(a);
		//            }
		//            if (i && b) {
		//                this.setListItem(i);
		//                this.oDataManager.setCallFromDeepLinkURL(false);
		//                return true;
		//            } else if (!this.oDataManager.getCallFromDeepLinkURL() && !t.system.phone) {
		//                this.fnSelectFirstItem();
		//            }
		//        } else if (!t.system.phone) {
		//            this.fnSelectFirstItem();
		//        }
		//        this.oDataManager.setCallFromDeepLinkURL(false);
		//    },
		//    _itemByContextPathSelected: function () {
		//        if (!this.sBindingContextPath) {
		//            return false;
		//        } else {
		//            var a = this.getList().getSelectedItem();
		//            if (!a) {
		//                return false;
		//            } else {
		//                return a.getBindingContextPath() === this.sBindingContextPath;
		//            }
		//        }
		//    },
		//    fnSelectFirstItem: function () {
		//        var a = this.getList().getItems();
		//        if (a.length > 0) {
		//            var b = undefined;
		//            var i = 0;
		//            do {
		//                b = a[i];
		//                i++;
		//            } while (!b.getBindingContext());
		//            this.setListItem(b);
		//        }
		//    },
		//    findNextVisibleItem: function (a, b, i) {
		//        var h = this.getList();
		//        var j = -1;
		//        var k = -1;
		//        this.aItemContextPathsToSelect = [];
		//        for (var c1 = 0; c1 < h.getItems().length; c1++) {
		//            var d1 = h.getItems()[c1].getBindingContextPath();
		//            if (d1) {
		//                var e1 = h.getItems()[c1].getBindingContext().getProperty("SAP__Origin");
		//                var f1 = h.getItems()[c1].getBindingContext().getProperty("InstanceID");
		//                if (e1 === i.sOrigin && f1 === i.sInstanceID) {
		//                    j = c1;
		//                    this.aItemContextPathsToSelect.push(d1);
		//                }
		//            }
		//            if (h.getItems()[c1].getVisible() && (k <= j || j == -1)) {
		//                k = c1;
		//                if (j !== -1 && k !== j) {
		//                    break;
		//                }
		//            }
		//        }
		//        if (k == -1 && h.getItems().length > 0) {
		//            k = 0;
		//        }
		//        if (k >= 0) {
		//            this.aItemContextPathsToSelect.push(h.getItems()[k].getBindingContextPath());
		//        }
		//    },
		//    overrideMHFHelperSetMasterTitle: function () {
		//        var a = this;
		//        this.getAppImp().oMHFHelper.setMasterTitle = function (b, i) {
		//            if (!b._oControlStore.oMasterTitle) {
		//                return;
		//            }
		//            this.oDataManager = this.oApplicationImplementation.getComponent().getDataManager();
		//            if (!this.oDataManager) {
		//                return;
		//            }
		//            if (a._oControlStore.oMasterSearchField.getValue().length == 0) {
		//                var h = a.getList();
		//                if (h && h.getItems()) {
		//                    var j = h.getBinding("items");
		//                    if (j && j.aKeys) {
		//                        i = j.aKeys.length;
		//                    }
		//                    if (a._oControlStore.oMasterSearchField.getValue() == "" && a.oDataManager.getPagingEnabled()) {
		//                        a.bTaskCountFromTaskCollectionCall = true;
		//                    } else if (!a.oDataManager.getPagingEnabled()) {
		//                        a.bTaskCountFromTaskCollectionCall = false;
		//                    }
		//                }
		//            } else {
		//                a.bTaskCountFromTaskCollectionCall = false;
		//            }
		//            var k = a.iTaskCount && a.bTaskCountFromTaskCollectionCall ? a.iTaskCount : i;
		//            a.iTotalFilteredItems = k;
		//            if (!this.oDataManager.getScenarioConfig() || !this.oDataManager.getScenarioConfig().DisplayName) {
		//                var c1 = cross.fnd.fiori.inbox.util.tools.Application.getImpl().AppI18nModel.getResourceBundle();
		//                this.sTitle = c1.getText(b._oHeaderFooterOptions.sI18NMasterTitle, [k]);
		//            } else {
		//                this.sTitle = this.oDataManager.getScenarioConfig().DisplayName + " (" + k + ")";
		//            }
		//            b._oControlStore.oMasterTitle.setText(this.sTitle);
		//        };
		//    },
		//    overrideMHFHelperFooterHandling: function () {
		//        var a = this.getAppImp().oMHFHelper;
		//        var b = this;
		//        var h = a.defineFooterRight;
		//        a.defineFooterRight = function (j) {
		//            var k = this.getFooterRightCount(j);
		//            if (j._oHeaderFooterOptions.oPositiveAction) {
		//                var c1 = {};
		//                q.extend(c1, j._oHeaderFooterOptions.oPositiveAction);
		//                c1.style = _.Accept;
		//                j._oControlStore.oButtonListHelper.ensureButton(c1, "b", k);
		//            }
		//            if (j._oHeaderFooterOptions.oNegativeAction) {
		//                var c1 = {};
		//                q.extend(c1, j._oHeaderFooterOptions.oNegativeAction);
		//                c1.style = _.Reject;
		//                j._oControlStore.oButtonListHelper.ensureButton(c1, "b", k);
		//            }
		//            h.call(this, j);
		//        };
		//        var i = a.getFooterRightCount;
		//        a.getFooterRightCount = function (j) {
		//            var k;
		//            if (b.isMultiSelectActive()) {
		//                k = 2;
		//            } else {
		//                k = i.call(this, j);
		//            }
		//            return k;
		//        };
		//    },
		//    onRefreshListInternal: function () {
		//        this.getAppImp().oMHFHelper.refreshList(this, true);
		//    },
		//    applySearchPatternToListItem: function (i, a) {
		//        this.sSearchPattern_Support = a;
		//        if (i.getIntro() && i.getIntro().toLowerCase().indexOf(a) != -1 || i.getTitle() && i.getTitle().toLowerCase().indexOf(a) != -1 || i.getNumber() && i.getNumber().toLowerCase().indexOf(a) != -1 || i.getNumberUnit() && i.getNumberUnit().toLowerCase().indexOf(a) != -1 || i.getFirstStatus() && i.getFirstStatus().getText().toLowerCase().indexOf(a) != -1 || i.getSecondStatus() && i.getSecondStatus().getText().toLowerCase().indexOf(a) != -1) {
		//            if (this.searchListFlag === 0 || this.searchListFlag === undefined) {
		//                this.searchListFlag = 1;
		//                this.searchListFirstItem = this.getDetailNavigationParameters(i);
		//            }
		//            return true;
		//        }
		//        var b = i.getAttributes();
		//        for (var j = 0; j < b.length; j++) {
		//            if (b[j].getText().toLowerCase().indexOf(a) != -1) {
		//                if (this.searchListFlag === 0 || this.searchListFlag === undefined) {
		//                    this.searchListFlag = 1;
		//                    this.searchListFirstItem = this.getDetailNavigationParameters(i);
		//                }
		//                return true;
		//            }
		//        }
		//        return false;
		//    },
		//    createSubstitutesUserFilterOption: function () {
		//        if (this.oDataManager.getSubstitutionEnabled()) {
		//            var i = this.getView().getModel("i18n").getResourceBundle();
		//            var a = this.createSubstitutedUserFilterCategory(i);
		//            this.getSubstitutedUsers(a);
		//            if (this.oSubstitutedUserFilterKeys) {
		//                this.resetSubstitutedUserFilterCategoryCount(Object.keys(this.oSubstitutedUserFilterKeys).length);
		//            }
		//            this.aFilterItems.push(a);
		//        }
		//    },
		getHeaderFooterOptions: function() {
			var a = this;
			var h = {
				sI18NMasterTitle: "MASTER_TITLE"
			};
			if (this.bHideHeaderFooterOptions) {
				return {};
			}
			if (!this.isMultiSelectActive()) {
				//     h.oFilterOptions = {
				//         onFilterPressed: q.proxy(function () {
				//             if (!a.oDataManager.bOutbox) {
				//                 var i = this.getView().getModel("i18n").getResourceBundle();
				//                 this.aFilterItems = I.getAllFilters(i, this.complexFilter);
				//                 var b = this.oDataManager.checkEntitySetExistsInMetadata("SubstitutedUsersCollection");
				//                 if (b) {
				//                     a.createSubstitutesUserFilterOption();
				//                 }
				//             }
				//             a.onShowFilter();
				//         }, a)
				//     };
				//     if (this.bDisplaySortOption) {
				//         h.oSortOptions = {
				//             aSortItems: this.aVisibleSortItems,
				//             sSelectedItemKey: this.sSortKey,
				//             onSortSelected: q.proxy(a.handleSort, a)
				//         };
				//         h.oGroupOptions = { onGroupPressed: q.proxy(a.onShowGroup, a) };
				//     }
			}
			if (!this.oDataManager.bOutbox) {
				h.oEditBtn = {
					onBtnPressed: q.proxy(function() {
						if (!this.isMultiSelectActive()) {
							this.prepareMultiSelect();
						} else {
							this.dismissMultiSelect();
						}
					}, a),
					bDisabled: !this.bDisplayMultiSelectButton
				};
			}
			if (this.oMultiSelectActions) {
				h.oPositiveAction = this.oMultiSelectActions.positiveAction;
				h.oNegativeAction = this.oMultiSelectActions.negativeAction;
				h.buttonList = this.oMultiSelectActions.additionalActions;
			}

			return h;
		},
		//    _findFilterKey: function (a) {
		//        var b = Object.keys(this.complexFilter);
		//        for (var i = 0; i < b.length; i++) {
		//            var h = b[i];
		//            var k = this.complexFilter[h];
		//            for (var j = 0; j < k.length; j++) {
		//                if (k[j] === a) {
		//                    return true;
		//                }
		//            }
		//        }
		//        return false;
		//    },
		//    _resetFilterState: function () {
		//        this.complexFilterBackup = this.complexFilter;
		//        this.complexFilter = {
		//            Priority: [],
		//            CompletionDeadLine: [],
		//            TaskDefinitionID: [],
		//            Status: [],
		//            CreatedOn: [],
		//            CustomNumberValue: [],
		//            CustomNumberUnitValue: [],
		//            CustomObjectAttributeValue: [],
		//            SubstitutedUser: []
		//        };
		//    },
		//    _saveFilterState: function (a) {
		//        this._resetFilterState();
		//        var b = Object.keys(a);
		//        for (var i = 0; i < b.length; i++) {
		//            var k = b[i];
		//            var h = k.split(":");
		//            if (!this.complexFilter[h[0]]) {
		//                this.complexFilter[h[0]] = [];
		//            }
		//            this.complexFilter[h[0]].push(k);
		//        }
		//    },
		//    _createFilterCategory: function (a, b) {
		//        var i = true;
		//        if (arguments.length == 2) {
		//            i = b;
		//        }
		//        return new E({
		//            text: a,
		//            multiSelect: i
		//        });
		//    },
		//    _createFilterItem: function (k, a) {
		//        var b = new H({
		//            text: a,
		//            key: k
		//        });
		//        if (this._findFilterKey(k)) {
		//            b.setSelected(true);
		//        }
		//        return b;
		//    },
		//    fnCreateSubstitutedUserFilterKeys: function (a) {
		//        var b = this;
		//        var h = a.getSource().getSelectedItems();
		//        var j = {};
		//        b.sSelectedSubstitutesNameForFilterString = "";
		//        var k = null;
		//        for (var i = 0; i < h.length; i++) {
		//            k = h[i].data("key");
		//            j[k] = true;
		//            b.sSelectedSubstitutesNameForFilterString = h.length === 1 ? h[i].getTitle() : b.sSelectedSubstitutesNameForFilterString + h[i].getTitle() + ", ";
		//        }
		//        b.oSubstitutedUserFilterKeys = j;
		//        b.resetSubstitutedUserFilterCategoryCount(h.length);
		//    },
		//    createSubstitutedUserFilterCategory: function (i) {
		//        var a = new K({ text: i.getText("filter.substitutingUserList") });
		//        return a;
		//    },
		//    resetSubstitutesListSelection: function (a) {
		//        var b = a.getSource();
		//        var i = this.getView().getModel("i18n").getResourceBundle();
		//        var h = null;
		//        q.each(b.getAggregation("filterItems"), function (k, c1) {
		//            if (c1.getText() == i.getText("filter.substitutingUserList")) {
		//                h = c1;
		//                return;
		//            }
		//        });
		//        if (h) {
		//            var j = h.getCustomControl();
		//            j.removeSelections(true);
		//        }
		//        this.oSubstitutedUserFilterKeys = null;
		//    },
		//    storeSubstitutedUserKeysInListItem: function (a, b) {
		//        if (a) {
		//            for (var i = 0; i < a.length; i++) {
		//                a[i].data("key", b.oData.oItems[i].key);
		//            }
		//        }
		//    },
		//    createDynamicSubstiutedUserList: function (a, b) {
		//        var h = a;
		//        var j = this;
		//        var k = this.getView().getModel("i18n").getResourceBundle().getText("view.SubstitutedUserList.noRecipients");
		//        var c1 = sap.ui.getCore().byId("substituesUser");
		//        if (!c1) {
		//            c1 = new N({
		//                id: "substituesUser",
		//                mode: "MultiSelect"
		//            });
		//        }
		//        var d1 = new P({ title: "{substitutedUserModel>text}" });
		//        c1.attachSelectionChange(function (e1) {
		//            j.fnCreateSubstitutedUserFilterKeys(e1);
		//        });
		//        h.setCustomControl(c1);
		//        h.setModel(b, "substitutedUserModel");
		//        c1.setModel(b, "substitutedUserModel");
		//        c1.bindAggregation("items", "substitutedUserModel>/oItems", d1);
		//        j.storeSubstitutedUserKeysInListItem(c1.getAggregation("items"), b);
		//        c1.setNoDataText(k);
		//        if (j.oSubstitutedUserFilterKeys) {
		//            for (var i = 0; i < j.aSubstitutedUserFilterItemList.length; i++) {
		//                if (j.oSubstitutedUserFilterKeys[j.aSubstitutedUserFilterItemList[i].key]) {
		//                    c1.setSelectedItem(c1.getItems()[i]);
		//                }
		//            }
		//        }
		//        return h;
		//    },
		//    createSubstitutedUserFilterItems: function (a, b) {
		//        var h = {
		//            text: b,
		//            key: a,
		//            selected: false
		//        };
		//        if (this._findFilterKey(a)) {
		//            h.selected = true;
		//        }
		//        return h;
		//    },
		//    getSubstitutedUsers: function (a) {
		//        var b = new J({});
		//        b.setData({ oItems: [] });
		//        this.createDynamicSubstiutedUserList(a, b);
		//        this.aSubstitutedUserFilterItemList = [];
		//        this.oSubstitutedUserDynamicFilter = a;
		//        var h = function (j) {
		//            var k = j.results, c1 = this;
		//            var d1 = [];
		//            var e1;
		//            if (k && k.length && k.length > 0) {
		//                var f1 = this.getView().getModel("i18n").getResourceBundle();
		//                var g1 = f1.getText("filter.substitutingUserList.myTasks");
		//                var h1 = {
		//                    UniqueName: "",
		//                    DisplayName: g1
		//                };
		//                d1.push(S._processSubstitutedUsersCollection(h1));
		//            }
		//            q.each(k, function (k1, l1) {
		//                if (!q.isEmptyObject(k)) {
		//                    e1 = true;
		//                    q.each(d1, function (k1, m1) {
		//                        if (m1.UniqueName === l1.UniqueName) {
		//                            e1 = false;
		//                            return false;
		//                        }
		//                    });
		//                }
		//                if (e1) {
		//                    d1.push(S._processSubstitutedUsersCollection(l1));
		//                }
		//            });
		//            for (var i = 0; i < d1.length; i++) {
		//                var i1 = c1._FILTER_CATEGORY_SUBSTITUTED_USER + ":" + d1[i].UniqueName;
		//                var j1 = this.createSubstitutedUserFilterItems(i1, d1[i].DisplayName);
		//                c1.aSubstitutedUserFilterItemList.push(j1);
		//            }
		//            b.setData({ oItems: c1.aSubstitutedUserFilterItemList });
		//            b.checkUpdate(true);
		//            c1.createDynamicSubstiutedUserList(a, b);
		//        };
		//        this.oDataManager.readSubstitutedUserList(q.proxy(h, this));
		//    },
		//    resetSubstitutedUserFilterCategoryCount: function (a) {
		//        if (this.oSubstitutedUserDynamicFilter !== undefined) {
		//            this.oSubstitutedUserDynamicFilter.setFilterCount(a);
		//        }
		//        ;
		//        if (this.oFilterDialog) {
		//            var b = this.getView().getModel("i18n").getResourceBundle();
		//            var h = this.oFilterDialog.getAggregation("filterItems");
		//            for (var i = 0; i < h.length; i++) {
		//                if (h[i].getText() === b.getText("filter.substitutingUserList")) {
		//                    h[i].setFilterCount(a);
		//                    break;
		//                }
		//            }
		//            ;
		//        }
		//        ;
		//    },
		//    onShowFilter: function () {
		//        var a = this;
		//        a.aTaskTypeFilterItemsOrigins = [];
		//        var b = a.getView().getModel("i18n").getResourceBundle();
		//        var h = this._createFilterCategory(b.getText("filter.taskType"));
		//        this.aTaskTypeFilterItems = new Array();
		//        var c1 = function (e1) {
		//            var f1 = 0;
		//            var g1 = q.extend(true, {}, this.oSubstitutedUserFilterKeys);
		//            if (this.oSubstitutedUserDynamicFilter) {
		//                f1 = this.oSubstitutedUserDynamicFilter.getFilterCount();
		//            }
		//            if (!this.oDataManager.bAllItems) {
		//                var h1 = this.oDataManager.getScenarioConfig().ScenarioServiceInfos;
		//            }
		//            for (var i = 0; i < e1.length; i++) {
		//                var i1 = false;
		//                if (this.oDataManager.bAllItems) {
		//                    i1 = true;
		//                } else {
		//                    for (var j = 0; j < h1.length; j++) {
		//                        for (var k = 0; k < h1[j].TaskDefinitionIDs.length; k++) {
		//                            if (e1[i].TaskDefinitionID.toUpperCase().indexOf(h1[j].TaskDefinitionIDs[k].toUpperCase()) == 0 && (h1[j].Origin === e1[i].SAP__Origin || this.oDataManager.sClientScenario)) {
		//                                i1 = true;
		//                                break;
		//                            }
		//                        }
		//                    }
		//                }
		//                if (i1) {
		//                    var j1 = {
		//                        taskTitle: e1[i].TaskName,
		//                        taskDefinitionID: e1[i].TaskDefinitionID,
		//                        SAP__Origin: e1[i].SAP__Origin
		//                    };
		//                    this.aTaskTypeFilterItems.push(j1);
		//                }
		//            }
		//            this.aTaskTypeFilterItems.sort(function (o1, p1) {
		//                var q1 = U.isString(o1.taskTitle) ? o1.taskTitle : "";
		//                var r1 = U.isString(p1.taskTitle) ? p1.taskTitle : "";
		//                if (q1.toUpperCase() < r1.toUpperCase()) {
		//                    return -1;
		//                }
		//                if (q1.toUpperCase() > r1.toUpperCase()) {
		//                    return 1;
		//                }
		//                return 0;
		//            });
		//            for (var i = 0; i < this.aTaskTypeFilterItems.length; i++) {
		//                var k1 = this._FILTER_CATEGORY_TASK_DEFINITION_ID + ":" + this.aTaskTypeFilterItems[i].taskDefinitionID + ":" + this.aTaskTypeFilterItems[i].SAP__Origin;
		//                var l1 = this._createFilterItem(k1, this.aTaskTypeFilterItems[i].taskTitle);
		//                h.addItem(l1);
		//            }
		//            if (this.oDataManager.bOutbox) {
		//                this.aFilterItems = O.getAllFilters(b, this.complexFilter);
		//                this.aFilterItems.push(h);
		//            } else {
		//                this.aFilterItems.push(h);
		//            }
		//            if (this._areItemsUniqueByTaskType()) {
		//                var m1 = null;
		//                var n1 = this.getList().getItems();
		//                if (n1 && n1.length > 0) {
		//                    m1 = n1[0].getBindingContext();
		//                }
		//                if (!m1) {
		//                    m1 = n1[1].getBindingContext();
		//                }
		//            }
		//            if (this.extHookChangeFilterItems) {
		//                this.extHookChangeFilterItems(this.aFilterItems);
		//            }
		//            this.getFilterDialog(b, f1, g1).open();
		//        };
		//        if (this.getView().getModel("taskDefinitionsModel")) {
		//            var d1 = q.proxy(c1, this);
		//            d1(this.getView().getModel("taskDefinitionsModel").getData());
		//        } else {
		//            this.oDataManager.readTaskDefinitionCollection(q.proxy(c1, this), q.proxy(c1, this));
		//        }
		//    },
		//    getFilterDialog: function (i, a, b) {
		//        var h = this;
		//        h.resetInitiated = false;
		//        if (!this.oFilterDialog) {
		//            this.oFilterDialog = new sap.m.ViewSettingsDialog({
		//                title: i.getText("filter.dialog.title"),
		//                filterItems: this.aFilterItems,
		//                confirm: function (j) {
		//                    h.oFilterKeys = j.getParameter("filterKeys");
		//                    if (h.oSubstitutedUserFilterKeys) {
		//                        q.extend(h.oFilterKeys, h.oSubstitutedUserFilterKeys);
		//                    }
		//                    if (Object.keys(h.oFilterKeys).length === 0) {
		//                        h.sInfoHeaderFilterString = null;
		//                    } else {
		//                        var i = h.getView().getModel("i18n").getResourceBundle();
		//                        var k = null;
		//                        var c1 = j.getParameter("filterString");
		//                        if (h.oSubstitutedUserFilterKeys) {
		//                            k = h.addFilterTextForSubstitutionFilter(c1, i);
		//                        }
		//                        h.sInfoHeaderFilterString = k ? k : c1;
		//                    }
		//                    h.refreshInfoHeaderToolbar();
		//                    h._saveFilterState(h.oFilterKeys);
		//                    h.handleFilter(h.oFilterKeys);
		//                },
		//                cancel: function (j) {
		//                    if (h.resetInitiated) {
		//                        h.complexFilter = h.complexFilterBackup;
		//                        h.resetSubstitutedUserFilterCategoryCount(a);
		//                        h.oSubstitutedUserFilterKeys = b;
		//                        h.resetInitiated = false;
		//                    }
		//                },
		//                resetFilters: function (j) {
		//                    if (!h.resetInitiated) {
		//                        h.resetInitiated = true;
		//                        h._resetFilterState();
		//                    }
		//                    h.resetSubstitutedUserFilterCategoryCount(0);
		//                    h.resetSubstitutesListSelection(j);
		//                }
		//            });
		//        }
		//        return this.oFilterDialog;
		//    },
		//    addFilterTextForSubstitutionFilter: function (a, i) {
		//        var b;
		//        if (a) {
		//            b = a + ", " + i.getText("filter.substitutingUserList") + " (" + this.sSelectedSubstitutesNameForFilterString + ")";
		//        } else {
		//            b = i.getText("multi.header", i.getText("filter.substitutingUserList") + " (" + this.sSelectedSubstitutesNameForFilterString + ")");
		//        }
		//        return b;
		//    },
		//    _createGroupSettingItem: function (a, b) {
		//        var i = this.getView().getModel("i18n").getResourceBundle();
		//        if (!b) {
		//            b = i.getText(a.textKey);
		//        }
		//        var h = new H({
		//            key: a.key,
		//            text: b
		//        });
		//        return h;
		//    },
		//    onShowGroup: function () {
		//        var a = [];
		//        for (var i = 0; i < this.aGroupConfig.length; i++) {
		//            var b = this._createGroupSettingItem(this.aGroupConfig[i]);
		//            a.push(b);
		//        }
		//        this.getGroupDialog(a).open();
		//    },
		//    getGroupDialog: function (a) {
		//        var b = this;
		//        if (!this.oGroupDialog) {
		//            this.oGroupDialog = new sap.m.ViewSettingsDialog({
		//                title: "{i18n>group.dialog.title}",
		//                groupItems: a,
		//                groupDescending: this.bGroupDescending,
		//                selectedGroupItem: this.oGroupConfigItem ? this.oGroupConfigItem.key : null,
		//                confirm: function (h) {
		//                    var j = h.getParameter("groupItem");
		//                    if (j && j.getKey()) {
		//                        var k = j.getKey();
		//                        for (var i = 0; i < b.aGroupConfig.length; i++) {
		//                            var c1 = b.aGroupConfig[i];
		//                            if (c1.key == k) {
		//                                b.oGroupConfigItem = c1;
		//                                break;
		//                            }
		//                        }
		//                    } else {
		//                        b.oGroupConfigItem = null;
		//                    }
		//                    b.bGroupDescending = h.getParameter("groupDescending");
		//                    b.handleGroup();
		//                }
		//            });
		//        }
		//        return this.oGroupDialog;
		//    },
		//    _isListFilteredByTaskType: function (b, a) {
		//        var i, h;
		//        for (i = 2, h = a.length; i < h; i++) {
		//            var j = a[i].getBindingContext();
		//            if (j && j.getProperty("TaskDefinitionID") != b.getProperty("TaskDefinitionID")) {
		//                return false;
		//            }
		//        }
		//        return true;
		//    },
		//    prepareMultiSelect: function () {
		//        this.setMultiSelectButtonActive(false);
		//        var h = this.getList().getItems();
		//        if (h.length == 0) {
		//            return;
		//        }
		//        var c1 = function (m1, n1) {
		//            var o1 = [];
		//            if (n1 && this.getView().getModel("taskDefinitionsModel")) {
		//                this.getView().getModel("taskDefinitionsModel").setData(m1, false);
		//            }
		//            if (!this.oDataManager.bAllItems) {
		//                var p1 = this.oDataManager.getScenarioConfig().ScenarioServiceInfos;
		//            }
		//            var q1 = [];
		//            var e1 = Object.keys(this.oFilterKeys || {});
		//            for (var i = 0; i < e1.length; i++) {
		//                var f1 = e1[i];
		//                if (this.oFilterKeys.hasOwnProperty(f1) && f1) {
		//                    var g1 = f1.split(":");
		//                    if (g1[0] === this._FILTER_CATEGORY_TASK_DEFINITION_ID) {
		//                        q1.push(g1[1]);
		//                    }
		//                }
		//            }
		//            for (var i = 0; i < m1.length; i++) {
		//                var r1 = false;
		//                if (this.oDataManager.bAllItems) {
		//                    r1 = true;
		//                } else {
		//                    for (var j = 0; j < p1.length; j++) {
		//                        for (var k = 0; k < p1[j].TaskDefinitionIDs.length; k++) {
		//                            if (m1[i].TaskDefinitionID.toUpperCase().indexOf(p1[j].TaskDefinitionIDs[k].toUpperCase()) === 0 && (p1[j].Origin === m1[i].SAP__Origin || this.oDataManager.sClientScenario)) {
		//                                r1 = true;
		//                                break;
		//                            }
		//                        }
		//                    }
		//                }
		//                if (r1 && (q1.length === 0 || q1.indexOf(m1[i].TaskDefinitionID) !== -1)) {
		//                    var l1 = {
		//                        title: m1[i].TaskName,
		//                        id: m1[i].TaskDefinitionID,
		//                        origin: m1[i].SAP__Origin
		//                    };
		//                    o1.push(l1);
		//                }
		//            }
		//            if (o1.length > 1) {
		//                o1.sort(function (a, b) {
		//                    if (a.title.toUpperCase() < b.title.toUpperCase()) {
		//                        return -1;
		//                    }
		//                    if (a.title.toUpperCase() > b.title.toUpperCase()) {
		//                        return 1;
		//                    }
		//                    return 0;
		//                });
		//                M.openFilterDialog(o1, q.proxy(this.multiSelectFilterDialogOK, this), null, n1);
		//                return true;
		//            } else {
		//                var l1 = o1[0];
		//                this.multiSelectFilterDialogOK(l1);
		//                return false;
		//            }
		//        };
		//        var d1 = 0;
		//        var e1 = Object.keys(this.oFilterKeys || {});
		//        for (var i = 0; i < e1.length; i++) {
		//            var f1 = e1[i];
		//            if (this.oFilterKeys.hasOwnProperty(f1) && f1) {
		//                var g1 = f1.split(":");
		//                if (g1[0] === this._FILTER_CATEGORY_TASK_DEFINITION_ID) {
		//                    d1++;
		//                }
		//            }
		//        }
		//        if (d1 !== 1) {
		//            if (this.getView().getModel("taskDefinitionsModel")) {
		//                var h1 = q.proxy(c1, this);
		//                var i1 = h1(this.getView().getModel("taskDefinitionsModel").getData());
		//                if (i1) {
		//                    this.oDataManager.readTaskDefinitionCollection(q.proxy(c1, this), null, true);
		//                }
		//            } else {
		//                this.oDataManager.readTaskDefinitionCollection(q.proxy(c1, this));
		//            }
		//        } else {
		//            var j1 = this.getList();
		//            if (j1.getItems().length !== 0) {
		//                var k1 = {};
		//                for (var i = 0; i < j1.getItems().length; i++) {
		//                    k1 = j1.getItems()[i].getBindingContext();
		//                    if (k1) {
		//                        var l1 = {
		//                            title: k1.getProperty("TaskDefinitionName"),
		//                            id: k1.getProperty("TaskDefinitionID"),
		//                            origin: k1.getProperty("SAP__Origin")
		//                        };
		//                        this.multiSelectFilterDialogOK(l1);
		//                        break;
		//                    }
		//                }
		//            }
		//        }
		//        this.bEnteringMultiSelectMode = true;
		//    },
		//    dismissMultiSelect: function () {
		//        this.isActionPerformed = true;
		//        this.sBindingContextPath = undefined;
		//        this.setMultiSelectButtonActive(false);
		//        this.bEnteringMultiSelectMode = false;
		//        var a = this.getList();
		//        a.destroyHeaderToolbar();
		//        a.destroyInfoToolbar();
		//        this.getPage().setSubHeader(this.oSubHeader);
		//        if (this._oControlStore.oMasterPullToRefresh) {
		//            this._oControlStore.oMasterPullToRefresh.setVisible(true);
		//        }
		//        this.refreshInfoHeaderToolbar();
		//        a.setMode(this.getView().getModel("device").getProperty("/listMode"));
		//        a.removeSelections(true);
		//        this.filterItemsByTaskDefinitionID(null);
		//        this.clearDecisionButtons();
		//    },
		//    multiSelectFilterDialogOK: function (a) {
		//        this.isActionPerformed = true;
		//        this.setProcessingMultiSelect({
		//            bProcessing: true,
		//            oFilterItem: a
		//        });
		//        this.filterItemsByTaskDefinitionID(a.id, a.origin);
		//    },
		//    refreshInfoHeaderToolbar: function (a) {
		//        if (!a) {
		//            a = "";
		//        }
		//        if (this.sInfoHeaderGroupString) {
		//            if (a) {
		//                a += "; ";
		//            }
		//            a += this.sInfoHeaderGroupString;
		//        }
		//        if (this.sInfoHeaderFilterString) {
		//            if (a) {
		//                a += "; ";
		//            }
		//            a += this.sInfoHeaderFilterString;
		//        }
		//        this.refreshInfoHeaderToolbarForList(this.getList(), a);
		//        this.refreshInfoHeaderToolbarForList(this.emptyList(), a);
		//    },
		//    refreshInfoHeaderToolbarForList: function (a, b) {
		//        var h = a.getHeaderToolbar();
		//        if (b) {
		//            if (!h) {
		//                h = new W({ design: b1.Info });
		//                a.setHeaderToolbar(h);
		//                a.addAriaLabelledBy(h.getIdForLabel());
		//            }
		//            h.destroyContent();
		//            h.setHeight();
		//            var i = new V({ width: "100%" });
		//            i.addContent(new X({ text: b }));
		//            if (this.sSearchPattern_Support && this.bEnteringMultiSelectMode) {
		//                var j = this.getView().getModel("i18n").getResourceBundle().getText("multi.header.search", this.sSearchPattern_Support);
		//                i.addContent(new X({ text: j }));
		//                h.setTooltip(b + "\n" + j);
		//                if (!t.system.desktop) {
		//                    h.setHeight("100%");
		//                }
		//            } else {
		//                h.setTooltip(b);
		//            }
		//            h.addContent(i);
		//        } else {
		//            if (h) {
		//                a.destroyHeaderToolbar();
		//            }
		//        }
		//    },
		//    downloadDecisionOptions: function (a, i, b) {
		//        this.oDataManager.readDecisionOptions(a, i, b, q.proxy(this.downloadDecisionOptionsSuccess, this), null, true);
		//    },
		//    downloadCustomAttributeDefinition: function (a, b) {
		//        this.oDataManager.readCustomAttributeDefinitionData(a, b, q.proxy(this.downloadCustomAttributeDefinitionSuccess, this), null, true);
		//    },
		//    downloadCustomAttributeDefinitionSuccess: function (a) {
		//        var b = a.CustomAttributeDefinitionData;
		//        if (b) {
		//            var h = this.getOwnerComponent().getModel("customAttributeDefinitionsModel");
		//            if (h) {
		//                h.setData(b);
		//                cross.fnd.fiori.inbox.util.MultiSelect.customAttributeDefinitionsLoaded.resolve();
		//            }
		//        }
		//    },
		//    downloadDecisionOptionsSuccess: function (a) {
		//        this.setMultiSelectButtonActive(true);
		//        if (!t.system.phone) {
		//            this.oRouter.navTo("multi_select_summary", {}, true);
		//        }
		//        var b = this.getList();
		//        this.oSelectAllCheckBox = new Y({ select: q.proxy(this.handleSelectAllCheckBoxPress, this) });
		//        var i = new W({
		//            design: b1.Transparent,
		//            content: [this.oSelectAllCheckBox]
		//        });
		//        i.addStyleClass("crossFndFioriInboxInfoToolbarPadding");
		//        b.setInfoToolbar(i);
		//        this.getPage().setSubHeader(null);
		//        if (this._oControlStore.oMasterPullToRefresh) {
		//            this._oControlStore.oMasterPullToRefresh.setVisible(false);
		//        }
		//        b.removeSelections(true);
		//        this.aMultiSelectDecisionOptions = a;
		//        this.getAppImp().oMHFHelper.defineMasterHeaderFooter(this);
		//        this.updateSelectAllCheckBox();
		//    },
		//    _handleSelect: function (a) {
		//        if (!this.isMultiSelectActive()) {
		//            this.setListItem(a.getParameter("listItem"));
		//            if (!t.system.phone) {
		//                this.getSplitContainer().hideMaster();
		//            }
		//        } else {
		//            var b = a.getParameter("listItem");
		//            var i = b.getBindingContext();
		//            this.updateMultiSelectState();
		//            var h = [q.extend(true, {}, i.getProperty())];
		//            h[0].listItem = b;
		//            this.publishMultiSelectEvent(a.getParameter("selected"), h);
		//        }
		//    },
		//    updateMultiSelectState: function () {
		//        var i = this.getList().getSelectedItems().length;
		//        switch (i) {
		//        case 0:
		//            this.hideDecisionButtons();
		//            break;
		//        default:
		//            this.showDecisionButtons();
		//            break;
		//        }
		//        this.updateSelectAllCheckBox();
		//    },
		//    publishMultiSelectEvent: function (b, a, h, i) {
		//        var j = {};
		//        j.Source = i ? i : "S2";
		//        j.Selected = b;
		//        j.WorkItems = a;
		//        j.reInitialize = h;
		//        cross.fnd.fiori.inbox.util.tools.Application.getImpl().getComponent().getEventBus().publish("cross.fnd.fiori.inbox", "multiselect", j);
		//    },
		//    getActualListItems: function () {
		//        var a = [];
		//        var b = this.getList().getItems();
		//        var i = 0;
		//        if (b[0] instanceof Z) {
		//            for (i = 1; i < b.length; i++) {
		//                if (!(b[i] instanceof Z)) {
		//                    if (this.sSearchPattern_Support) {
		//                        if (b[i].getVisible()) {
		//                            a.push(b[i]);
		//                        }
		//                    } else {
		//                        a.push(b[i]);
		//                    }
		//                }
		//            }
		//        } else if (this.sSearchPattern_Support) {
		//            for (i = 0; i < b.length; i++) {
		//                if (b[i].getVisible()) {
		//                    a.push(b[i]);
		//                }
		//            }
		//        } else {
		//            a = this.getList().getItems();
		//        }
		//        return a;
		//    },
		//    updateSelectAllCheckBox: function () {
		//        var i = this.getView().getModel("i18n").getResourceBundle();
		//        var b = this.getList().getSelectedItems().length < this.getActualListItems().length;
		//        if (this.oSelectAllCheckBox) {
		//            this.oSelectAllCheckBox.setText(i.getText(b ? "multi.selectall" : "multi.deselectall"));
		//            this.oSelectAllCheckBox.setSelected(!b);
		//        }
		//    },
		//    handleSelectAllCheckBoxPress: function () {
		//        var a = this.getActualListItems();
		//        if (this.getList().getSelectedItems().length < a.length) {
		//            var b = [];
		//            for (var i = 0; i < a.length; i++) {
		//                var h = a[i];
		//                if (!h.getBindingContext()) {
		//                    continue;
		//                }
		//                if (h.getVisible()) {
		//                    h.setSelected(true);
		//                    var j = q.extend(true, {}, h.getBindingContext().getProperty());
		//                    j.listItem = h;
		//                    b.push(j);
		//                }
		//            }
		//            this.publishMultiSelectEvent(true, b);
		//        } else {
		//            this.getList().removeSelections(true);
		//            this.publishMultiSelectEvent(false, []);
		//        }
		//        this.updateMultiSelectState();
		//    },
		//    onMultiSelectEvent: function (a, b, h) {
		//        if (h.Source === "MultiSelectSummary" || h.Source === "action") {
		//            var k = this.getList();
		//            var c1 = k.getItems();
		//            for (var i = 0; i < h.WorkItems.length; i++) {
		//                for (var j = 0; j < c1.length; j++) {
		//                    var d1 = c1[j];
		//                    var e1 = d1.getBindingContext();
		//                    if (!e1) {
		//                        continue;
		//                    }
		//                    if (e1.getProperty("SAP__Origin") === h.WorkItems[i].SAP__Origin && e1.getProperty("InstanceID") === h.WorkItems[i].InstanceID) {
		//                        d1.setSelected(h.Selected);
		//                    }
		//                }
		//            }
		//            this.updateMultiSelectState();
		//        }
		//    },
		//    onSupportInfoOpenEvent: function (a, b, h) {
		//        if (h.source === "MAIN") {
		//            d.setSearchPattern(this.sSearchPattern_Support);
		//            d.setFilters(this.sFilterKey_Support);
		//            d.setSorters(this.sSortKey_Support);
		//            d.setGroup(this.sGroupkey_Support);
		//        }
		//    },
		//    filterItemsByTaskDefinitionID: function (a, b) {
		//        if (a) {
		//            this.oFilterKeysBeforeMultiSelect = q.extend(true, {}, this.oFilterKeys);
		//            var h = {};
		//            var j = b ? b : "";
		//            h["TaskDefinitionID:" + a + ":" + j] = true;
		//            var k = false;
		//            var c1 = Object.keys(this.oFilterKeys || {});
		//            for (var i = 0; i < c1.length; i++) {
		//                var d1 = c1[i];
		//                var e1 = d1.split(":");
		//                if (e1[0] !== this._FILTER_CATEGORY_TASK_DEFINITION_ID) {
		//                    if (e1[0] === this._FILTER_CATEGORY_STATUS && e1[1] !== I._FILTER_STATUS_AWAITING_CONFIRMATION) {
		//                        h[d1] = true;
		//                        k = true;
		//                    } else if (e1[0] !== this._FILTER_CATEGORY_STATUS) {
		//                        h[d1] = true;
		//                    }
		//                }
		//            }
		//            if (!k) {
		//                h[this._FILTER_CATEGORY_STATUS + ":" + I._FILTER_STATUS_NEW] = true;
		//                h[this._FILTER_CATEGORY_STATUS + ":" + I._FILTER_STATUS_IN_PROGRESS] = true;
		//                h[this._FILTER_CATEGORY_STATUS + ":" + I._FILTER_STATUS_RESERVED] = true;
		//            }
		//            this.oFilterKeys = h;
		//            return this.handleFilter(this.oFilterKeys);
		//        } else if (this.oFilterKeysBeforeMultiSelect) {
		//            this.oFilterKeys = q.extend(true, {}, this.oFilterKeysBeforeMultiSelect);
		//            return this.handleFilter(this.oFilterKeys);
		//        }
		//    },
		//    clearDecisionButtons: function () {
		//        this.oMultiSelectActions = {
		//            positiveAction: null,
		//            negativeAction: null,
		//            additionalActions: []
		//        };
		//    },
		//    hideDecisionButtons: function () {
		//        this.clearDecisionButtons();
		//        this.getAppImp().oMHFHelper.defineMasterHeaderFooter(this);
		//    },
		//    checkDecisionSupport: function (a) {
		//        var b;
		//        var h = {
		//            Claim: true,
		//            Release: true,
		//            Forward: true,
		//            Resubmit: true
		//        };
		//        for (var i = 0; i < a.length; i++) {
		//            b = a[i].getBindingContext();
		//            h.Claim = h.Claim && g.formatterSupportsProperty(b.getProperty("TaskSupports").Claim, b.getProperty("SupportsClaim"));
		//            h.Release = h.Release && g.formatterSupportsProperty(b.getProperty("TaskSupports").Release, b.getProperty("SupportsRelease"));
		//            h.Forward = h.Forward && g.formatterSupportsProperty(b.getProperty("TaskSupports").Forward, b.getProperty("SupportsForward"));
		//            h.Resubmit = h.Resubmit && g.formatterSupportsProperty(b.getProperty("TaskSupports").Resubmit, false);
		//            if (!h.Claim && !h.Release && !h.Forward && !h.Resubmit) {
		//                break;
		//            }
		//        }
		//        return h;
		//    },
		//    showDecisionButtons: function () {
		//        this.clearDecisionButtons();
		//        var a = this, b = this.aMultiSelectDecisionOptions ? this.aMultiSelectDecisionOptions.length : 0;
		//        var h = 1;
		//        var j = 0;
		//        if (b > 0) {
		//            var k = null;
		//            var c1 = this.getList().getSelectedItems();
		//            if (c1.length > 0) {
		//                k = c1[0].getBindingContext().getProperty("SAP__Origin");
		//            }
		//            for (var i = 0; i < b; i++) {
		//                var d1 = this.aMultiSelectDecisionOptions[i];
		//                var e1 = d1.DecisionText;
		//                d1.SAP__Origin = k;
		//                if (!d1.Nature) {
		//                    j = 400 + h;
		//                    h++;
		//                } else if (d1.Nature.toUpperCase() === "POSITIVE") {
		//                    j = h;
		//                    h++;
		//                } else if (d1.Nature.toUpperCase() === "NEGATIVE") {
		//                    j = 200 + h;
		//                    h++;
		//                } else {
		//                    j = 400 + h;
		//                    h++;
		//                }
		//                var f1 = {
		//                    iDisplayOrderPriority: j,
		//                    nature: d1.Nature,
		//                    sBtnTxt: e1,
		//                    onBtnPressed: function (d1) {
		//                        return function () {
		//                            a.showDecisionDialog(d1);
		//                        };
		//                    }(d1)
		//                };
		//                this.oMultiSelectActions.additionalActions.push(f1);
		//            }
		//        }
		//        var g1 = this.getList().getSelectedItems();
		//        var h1 = this.checkDecisionSupport(g1);
		//        if (h1.Claim === true) {
		//            j = 1500 + h;
		//            h++;
		//            var i1 = {
		//                iDisplayOrderPriority: j,
		//                sI18nBtnTxt: "XBUT_CLAIM",
		//                onBtnPressed: q.proxy(this.sendMultiClaimRelease, this, g1, this.oDataManager.sClaimAction)
		//            };
		//            this.oMultiSelectActions.additionalActions.push(i1);
		//        }
		//        if (h1.Release === true) {
		//            j = 1500 + h;
		//            h++;
		//            var j1 = {
		//                iDisplayOrderPriority: j,
		//                sI18nBtnTxt: "XBUT_RELEASE",
		//                onBtnPressed: q.proxy(this.sendMultiClaimRelease, this, g1, this.oDataManager.sReleaseAction)
		//            };
		//            this.oMultiSelectActions.additionalActions.push(j1);
		//        }
		//        if (h1.Forward === true) {
		//            j = 1500 + h;
		//            h++;
		//            var k1 = {
		//                iDisplayOrderPriority: j,
		//                sI18nBtnTxt: "XBUT_FORWARD",
		//                onBtnPressed: q.proxy(this.onForwardPopUp, this)
		//            };
		//            this.oMultiSelectActions.additionalActions.push(k1);
		//        }
		//        if (h1.Resubmit === true) {
		//            j = 1500 + h;
		//            h++;
		//            var l1 = {
		//                iDisplayOrderPriority: j,
		//                sI18nBtnTxt: "XBUT_RESUBMIT",
		//                onBtnPressed: q.proxy(this.showResubmitPopUp, this)
		//            };
		//            this.oMultiSelectActions.additionalActions.push(l1);
		//        }
		//        var m1 = {};
		//        m1.oPositiveAction = this.oMultiSelectActions.positiveAction;
		//        m1.oNegativeAction = this.oMultiSelectActions.negativeAction;
		//        m1.aButtonList = this.oMultiSelectActions.additionalActions;
		//        if (this.extHookChangeMassApprovalButtons) {
		//            this.extHookChangeMassApprovalButtons(m1);
		//            this.oMultiSelectActions.positiveAction = m1.oPositiveAction;
		//            this.oMultiSelectActions.negativeAction = m1.oNegativeAction;
		//            this.oMultiSelectActions.additionalActions = m1.aButtonList;
		//        }
		//        if (this.oMultiSelectActions && this.oMultiSelectActions.additionalActions) {
		//            this.oMultiSelectActions.additionalActions.sort(f.compareButtons);
		//        }
		//        this.getAppImp().oMHFHelper.defineMasterHeaderFooter(this);
		//    },
		//    showDecisionDialog: function (a) {
		//        var b = this.getList().getSelectedItems();
		//        var i = this.getView().getModel("i18n").getResourceBundle();
		//        var h = a && (a.ReasonRequired === "REQUIRED" || a.ReasonRequired === "OPTIONAL") ? this.oConfirmationDialogManager.loadReasonOptions(a, this.oDataManager) : null;
		//        var j = {
		//            question: i.getText(b.length > 1 ? "XMSG_MULTI_DECISION_QUESTION_PLURAL" : "XMSG_MULTI_DECISION_QUESTION", [
		//                a.DecisionText,
		//                b.length
		//            ]),
		//            textAreaLabel: i.getText("XFLD_TextArea_Decision"),
		//            showNote: true,
		//            title: i.getText("XTIT_SUBMIT_DECISION"),
		//            confirmButtonLabel: i.getText("XBUT_SUBMIT"),
		//            noteMandatory: a.CommentMandatory,
		//            confirmActionHandler: q.proxy(function (k, c1, d1) {
		//                this.sendMultiSelectAction(k, c1, d1);
		//            }, this, a)
		//        };
		//        if (h === null) {
		//            this.oConfirmationDialogManager.showDecisionDialog(j);
		//        } else {
		//            h.then(function (k) {
		//                j["reasonOptionsSettings"] = k;
		//                this.oConfirmationDialogManager.showDecisionDialog(j);
		//            }.bind(this)).catch(function (k) {
		//                L.error("Could not load the reason options properly");
		//            });
		//        }
		//    },
		//    sendMultiClaimRelease: function (i, a) {
		//        var b = this.getList().getBinding("items").getLength();
		//        var h = i.length === b ? true : false;
		//        this.oDataManager.doMassClaimRelease(i, a, q.proxy(this.sendMultiClaimReleaseSuccess, this, h, a), null);
		//    },
		//    sendMultiClaimReleaseSuccess: function (a, b, h, i) {
		//        if (i.length === 0) {
		//            var j, k;
		//            var c1 = this.getView().getModel("i18n").getResourceBundle();
		//            if (b === this.oDataManager.sClaimAction) {
		//                j = "dialog.success.multi_reserve";
		//                k = "dialog.success.multi_reserve_plural";
		//            } else {
		//                j = "dialog.success.multi_release";
		//                k = "dialog.success.multi_release_plural";
		//            }
		//            setTimeout(function () {
		//                $.show(c1.getText(h.length > 1 ? k : j, [h.length]));
		//            }.bind(this), 500);
		//            this.getList().removeSelections(true);
		//            this.sendMultiSelectActionEnd(a);
		//        } else {
		//            M.openMessageDialog(h, i, q.proxy(this.sendMultiSelectActionEnd, this, a, i));
		//        }
		//    },
		//    sendMultiSelectAction: function (a, b, h) {
		//        var j = this.getList().getSelectedItems();
		//        var k = [];
		//        for (var i = 0; i < j.length; i++) {
		//            var c1 = j[i].getBindingContext().getObject();
		//            k.push(c1);
		//        }
		//        var d1 = this.getList().getBinding("items").getLength();
		//        var e1 = k.length === d1 ? true : false;
		//        this.oDataManager.sendMultiAction(this._FUNCTION_IMPORT_DECISION, k, a, b, h, q.proxy(this.sendMultiSelectActionSuccess, this, e1), null, true);
		//    },
		//    sendMultiSelectActionSuccess: function (a, b, h) {
		//        if (h.length === 0) {
		//            var i = this.getView().getModel("i18n").getResourceBundle();
		//            setTimeout(function () {
		//                $.show(i.getText(b.length > 1 ? "dialog.success.multi_complete_plural" : "dialog.success.multi_complete", b.length));
		//            }.bind(this), 500);
		//            this.sendMultiSelectActionEnd(a);
		//        } else {
		//            M.openMessageDialog(b, h, q.proxy(this.sendMultiSelectActionEnd, this, a, h));
		//        }
		//    },
		//    sendMultiSelectActionEnd: function (a, b) {
		//        if (this.oDataManager.getPagingEnabled()) {
		//            this.oDataManager.oModel.refresh();
		//        }
		//        if (b) {
		//            this.publishMultiSelectEvent(true, b, true, "action");
		//        } else if (a) {
		//            this.dismissMultiSelect();
		//            this.getView().getModel().bFullRefreshNeeded = true;
		//            this.getView().getModel().refresh();
		//        } else {
		//            this.publishMultiSelectEvent(false, [], true, "action");
		//        }
		//    },
		//    sendMultiSelectForwardSuccess: function (a, b, h, i) {
		//        if (h.length === 0) {
		//            var j = this.getView().getModel("i18n").getResourceBundle();
		//            setTimeout(function () {
		//                $.show(j.getText(b.length > 1 ? "dialog.success.multi_forward_complete_plural" : "dialog.success.multi_forward_complete", [
		//                    b.length,
		//                    i.DisplayName
		//                ]));
		//            }.bind(this), 500);
		//            this.sendMultiSelectActionEnd(a);
		//        } else {
		//            M.openMessageDialog(b, h, q.proxy(this.sendMultiSelectActionEnd, this, a, h));
		//        }
		//    },
		//    isMultiSelectActive: function () {
		//        return this.getList().getMode() == a1.MultiSelect;
		//    },
		//    setProcessingMultiSelect: function (a) {
		//        this.getView().getModel().oProcessingMultiSelect = q.isEmptyObject(a) ? undefined : a;
		//    },
		//    setMultiSelectButtonActive: function (a) {
		//        this._oControlStore.bEditState = a;
		//        this._oControlStore.oEditBtn.setIcon(a ? "sap-icon://sys-cancel" : "sap-icon://multi-select");
		//        this._oControlStore.oEditBtn.setTooltip(this.getView().getModel("i18n").getResourceBundle().getText(a ? "XBUT_CANCEL" : "XBUT_MULTI_SELECT"));
		//    },
		loadInitialAppData: function() {
			// this.oDataManager.fetchTaskDefinitionsandCustomAttributeDefinitions(q.proxy(this.oDataManager.initTaskDefnandCustomAttrDefnnModel, this));
			if (this.oDataManager.sScenarioId || this.oDataManager.sClientScenario) {
				this.oDataManager.loadInitialAppData(q.proxy(function(b) {
					if (!b) {
						return;
					}
					this.getView().getModel().ScenarioServiceInfos = b.ScenarioServiceInfos;
					var a = this.oDataManager.getScenarioConfig();
					if (b.ScenarioServiceInfos.length === 1 || a.AllItems == true) {
						this.bDisplaySortOption = true;
					}
					this.bDisplayMultiSelectButton = a.IsMassActionEnabled;
					this.sBackendDefaultSortKey = a.SortBy;
					this.fnAddAditionalSelectPropertiesAndInitBinding();
					if (this.bDisplaySortOption) {
						this.setSortItemsToDisplay();
					}
				}, this));
			} else {
				var a = this.oDataManager.getScenarioConfig();
				if (a.AllItems === true) {
					this.bDisplayMultiSelectButton = a.IsMassActionEnabled ? true : false;
					this.bDisplaySortOption = true;
					this.sBackendDefaultSortKey = a.SortBy;
					this.fnAddAditionalSelectPropertiesAndInitBinding();
					if (this.bDisplaySortOption) {
						this.setSortItemsToDisplay();
					}
				}
			}
		},
		//    fnAddAditionalSelectPropertiesAndInitBinding: function () {
		//        var a = this;
		//        a.oDataManager.oModel.getMetaModel().loaded().then(function (b) {
		//            a.oDataManager.oServiceMetaModel = a.oDataManager.oModel.getMetaModel();
		//            if (a.oDataManager.checkPropertyExistsInMetadata("GUI_Link")) {
		//                a.bGUILinkSelectPropertySupported = true;
		//            }
		//            ;
		//            if (a.oDataManager.checkPropertyExistsInMetadata("ConfidenceLevel")) {
		//                a.aSelectProperties.push("ConfidenceLevel");
		//            }
		//            ;
		//            a.initListBinding(a.configureSorters(a.sBackendDefaultSortKey), a.getAllFilters());
		//        });
		//    },
		initListBinding: function(a, b) {
			var h = this.aSelectProperties.concat();
			if (this.extHookGetPropertiesToSelect) {
				var i = this.extHookGetPropertiesToSelect();
				h = h.concat(i);
			}
			if (this.oDataManager.bOutbox) {
				h = h.concat(this.aSelectPropertiesOutbox);
			}
			if (this.oDataManager.getShowAdditionalAttributes() === true) {
				h.push(this.sCustomAttributeDataProperty);
			}
			if (this.bGUILinkSelectPropertySupported) {
				h.push(this._GUI_LINK_SELECT_PROPERTY);
			}
			var j = "";
			var k;
			if (this.oDataManager.getOperationMode() === u.Client) {
				j = u.Client;
			} else {
				j = u.Server;
				if (this.oDataManager.getPagingEnabled() === false) {
					k = true;
				}
			}
			var c1 = {
				countMode: v.InlineRepeat,
				faultTolerant: true,
				operationMode: j,
				doNotLoadNewTasksfterAction: k,
				select: h.join(",")
			};
			if (this.oDataManager.getShowAdditionalAttributes() === true) {
				c1.expand = "CustomAttributeData";
			}
			this.getList().bindAggregation("items", {
				path: "/TaskCollection",
				template: this.getView().byId("MAIN_LIST_ITEM"),
				sorter: a,
				filters: b,
				templateShareable: true,
				parameters: c1
			});
			this.registerMasterListBind();
		},
		//    getAllFilters: function (a) {
		//        var b = [];
		//        var h = this.oDataManager.getScenarioConfig();
		//        var i = h.AllItems;
		//        var j = this.getView().getModel();
		//        if (i) {
		//            b = this.getFiltersWithoutScenario(j);
		//        } else {
		//            b = this.getFiltersWithScenario(j);
		//        }
		//        if (a) {
		//            b.push(a);
		//        }
		//        var k = j.aStatusFilterKeys;
		//        var c1 = T.getAllFilters(this.oDataManager.bOutbox, k, b);
		//        b.push(new r(c1, false));
		//        return [new r(b, true)];
		//    },
		//    getFiltersWithoutScenario: function (a) {
		//        var b = this;
		//        var h = [];
		//        var i = a.aTaskDefinitionIDFilterKeys || [];
		//        var k = a.aSubstitutedUserFilterKeys || [];
		//        var c1 = a.aStatusFilterKeys;
		//        if (!i) {
		//            i = [];
		//        }
		//        if (!k) {
		//            k = [];
		//        }
		//        if (!c1) {
		//            c1 = [];
		//        }
		//        var d1 = [];
		//        var e1 = [];
		//        var f1 = [];
		//        var g1 = [];
		//        for (var j = 0; j < i.length; j++) {
		//            var h1 = new r({
		//                path: "TaskDefinitionID",
		//                operator: s.EQ,
		//                value1: i[j]
		//            });
		//            d1.push(h1);
		//            if (g1.indexOf(b.aTaskTypeFilterItemsOrigins[j]) !== -1) {
		//                continue;
		//            }
		//            var i1 = new r({
		//                path: "SAP__Origin",
		//                operator: s.EQ,
		//                value1: b.aTaskTypeFilterItemsOrigins[j]
		//            });
		//            f1.push(i1);
		//            g1.push(b.aTaskTypeFilterItemsOrigins[j]);
		//        }
		//        e1 = S._getSubstitutedUserFilters(k);
		//        if (f1.length > 0) {
		//            h.push(new r(f1, false));
		//        }
		//        if (d1.length > 0) {
		//            h.push(new r(d1, false));
		//        }
		//        if (e1.length > 0) {
		//            h.push(new r(e1, false));
		//        }
		//        return h;
		//    },
		//    getFiltersWithScenario: function (a) {
		//        var b = [];
		//        var h = a.aTaskDefinitionIDFilterKeys;
		//        var c1 = a.aSubstitutedUserFilterKeys;
		//        var d1 = a.aStatusFilterKeys;
		//        var e1 = this.oDataManager.getScenarioConfig();
		//        var f1 = this;
		//        if (!h) {
		//            h = [];
		//        }
		//        if (!c1) {
		//            c1 = [];
		//        }
		//        if (!d1) {
		//            d1 = [];
		//        }
		//        var g1 = [];
		//        var h1 = [];
		//        var i1 = {};
		//        var j1 = h.length > 0 ? true : false;
		//        var k1 = [];
		//        var l1 = [];
		//        var m1 = [];
		//        for (var i = 0; i < e1.ScenarioServiceInfos.length; i++) {
		//            var n1 = e1.ScenarioServiceInfos[i];
		//            var o1 = false;
		//            var p1 = "";
		//            for (var j = 0; j < n1.TaskDefinitionIDs.length; j++) {
		//                o1 = false;
		//                p1 = "";
		//                for (var k = 0; k < h.length; k++) {
		//                    if (h[k].toUpperCase().indexOf(n1.TaskDefinitionIDs[j].toUpperCase()) == 0) {
		//                        o1 = true;
		//                        p1 = h[k];
		//                        if (!this.oDataManager.sClientScenario) {
		//                            if (h1.indexOf(f1.aTaskTypeFilterItemsOrigins[k]) == -1) {
		//                                i1 = new r({
		//                                    path: "SAP__Origin",
		//                                    operator: s.EQ,
		//                                    value1: f1.aTaskTypeFilterItemsOrigins[k]
		//                                });
		//                                g1.push(i1);
		//                                h1.push(f1.aTaskTypeFilterItemsOrigins[k]);
		//                            }
		//                        }
		//                        break;
		//                    }
		//                }
		//                if (h.length > 0 && !o1) {
		//                    continue;
		//                }
		//                if (!o1) {
		//                    p1 = n1.TaskDefinitionIDs[j];
		//                }
		//                if (k1.indexOf(p1) == -1) {
		//                    var q1 = new r({
		//                        path: "TaskDefinitionID",
		//                        operator: s.EQ,
		//                        value1: p1
		//                    });
		//                    l1.push(q1);
		//                }
		//            }
		//            if (!this.oDataManager.sClientScenario) {
		//                if (!j1 && h1.indexOf(n1.Origin) == -1) {
		//                    i1 = new r({
		//                        path: "SAP__Origin",
		//                        operator: s.EQ,
		//                        value1: n1.Origin
		//                    });
		//                    h1.push(n1.Origin);
		//                    g1.push(i1);
		//                }
		//            }
		//        }
		//        m1 = S._getSubstitutedUserFilters(c1);
		//        if (l1.length > 0) {
		//            b.push(new r(l1, false));
		//        }
		//        if (g1.length > 0) {
		//            b.push(new r(g1, false));
		//        }
		//        if (m1.length > 0) {
		//            b.push(new r(m1, false));
		//        }
		//        return b;
		//    },
		//    onForwardPopUp: function () {
		//        var a = this.getList().getSelectedItems()[0].getBindingContext();
		//        var b = a.getProperty("SAP__Origin");
		//        var i = a.getProperty("InstanceID");
		//        var h = this.getList().getSelectedItems().length;
		//        if (this.oDataManager.userSearch) {
		//            F.open(q.proxy(this.startForwardFilter, this), q.proxy(this.closeForwardPopUp, this), h);
		//            this.oDataManager.readPotentialOwners(b, i, q.proxy(this._PotentialOwnersSuccess, this));
		//        } else {
		//            c.open(q.proxy(this.closeForwardPopUp, this), h);
		//        }
		//    },
		//    showResubmitPopUp: function () {
		//        R.open(this.sResubmitUniqueId, this, this.getView());
		//    },
		//    sendMultiSelectResubmitSuccess: function (a, b, h) {
		//        if (h.length == 0) {
		//            var i = this.getView().getModel("i18n").getResourceBundle();
		//            setTimeout(function () {
		//                $.show(i.getText(b.length > 1 ? "dialog.success.multi_resubmit_multiple_tasks" : "dialog.success.multi_resubmit_single_task", [b.length]));
		//            }.bind(this), 500);
		//            this.sendMultiSelectActionEnd(a);
		//        } else {
		//            M.openMessageDialog(b, h, q.proxy(this.sendMultiSelectActionEnd, this, a, h));
		//        }
		//    },
		//    handleResubmitPopOverOk: function (a) {
		//        var b = this.getList().getSelectedItems();
		//        var h = [];
		//        for (var i = 0; i < b.length; i++) {
		//            var j = b[i].getBindingContext().getObject();
		//            h.push(j);
		//        }
		//        var k = this.getList().getBinding("items").getLength();
		//        var c1 = h.length === k ? true : false;
		//        var d1 = x.byId(this.sResubmitUniqueId, "DATE_RESUBMIT");
		//        var e1 = d1.getSelectedDates();
		//        if (e1.length > 0) {
		//            var f1 = e1[0].getStartDate();
		//            var g1 = y.getDateInstance({ pattern: "yyyy-MM-ddTHH:mm:ss" });
		//            this.oDataManager.doMassResubmit(h, "datetime'" + g1.format(f1) + "'", q.proxy(this.sendMultiSelectResubmitSuccess, this, c1), null);
		//            R.close();
		//        } else {
		//            this.sendMultiSelectActionEnd();
		//        }
		//    },
		//    _PotentialOwnersSuccess: function (a) {
		//        F.setAgents(a.results);
		//        F.setOrigin(this.getList().getSelectedItems()[0].getBindingContext().getProperty("SAP__Origin"));
		//    },
		//    startForwardFilter: function (a, b) {
		//        b = b.toLowerCase();
		//        var h = a.getBindingContext().getProperty("DisplayName").toLowerCase();
		//        var i = a.getBindingContext().getProperty("Department").toLowerCase();
		//        return h.indexOf(b) != -1 || i.indexOf(b) != -1;
		//    },
		//    closeForwardPopUp: function (a) {
		//        if (a && a.bConfirmed) {
		//            var b = this.getList().getSelectedItems();
		//            var h = [];
		//            for (var i = 0; i < b.length; i++) {
		//                var j = q.extend(true, {}, b[i].getBindingContext().getObject());
		//                j.listItem = b[i];
		//                h.push(j);
		//            }
		//            var k = this.getList().getBinding("items").getLength();
		//            var c1 = h.length === k ? true : false;
		//            this.oDataManager.doMassForward(h, a.oAgentToBeForwarded, a.sNote, q.proxy(this.sendMultiSelectForwardSuccess, this, c1), null);
		//        } else {
		//            this.sendMultiSelectActionEnd(c1);
		//        }
		//    },
		//    _handleListSwipe: function (a) {
		//        if (this.isMultiSelectActive()) {
		//            a.bPreventDefault = true;
		//            return;
		//        }
		//        if (!this.oDataManager.getScenarioConfig().IsQuickActionEnabled) {
		//            a.bPreventDefault = true;
		//            L.error("Quick Action is not enabled in Scenario Customizing");
		//        } else {
		//            var b = a.getParameter("listItem");
		//            var j = b.getBindingContext();
		//            var k = j.getProperty("SAP__Origin");
		//            var c1 = j.getProperty("InstanceID");
		//            var d1 = null;
		//            if (j.getProperty("Status") === "EXECUTED") {
		//                var e1 = {};
		//                e1.selectedListItem = b;
		//                e1.isMandatoryComment = false;
		//                e1.text = this.getView().getModel("i18n").getResourceBundle().getText("XBUT_CONFIRM");
		//                var f1 = a.getParameter("swipeContent");
		//                f1.setText(e1.text);
		//                var g1 = new w({
		//                    key: "APPROVE_DECISION",
		//                    value: e1
		//                });
		//                f1.removeAllCustomData();
		//                f1.addCustomData(g1);
		//            } else {
		//                this.oDataManager.readDecisionOptions(k, c1, j.getProperty("TaskDefinitionID"), function (j1) {
		//                    d1 = j1;
		//                }, null, true);
		//                var h1 = [];
		//                if (d1) {
		//                    for (var h = 0; h < d1.length; h++) {
		//                        var i1 = {};
		//                        i1.decisionKey = d1[h].DecisionKey;
		//                        i1.buttonText = d1[h].DecisionText;
		//                        i1.isApprove = d1[h].Nature === "POSITIVE" ? true : false;
		//                        i1.isReject = d1[h].Nature === "NEGATIVE" ? true : false;
		//                        i1.isNonNature = d1[h].Nature === "" ? true : false;
		//                        i1.isMandatoryComment = d1[h].CommentMandatory;
		//                        h1.push(i1);
		//                    }
		//                }
		//                for (var i = 0; i < h1.length; i++) {
		//                    if (h1[i].isApprove) {
		//                        var e1 = {};
		//                        e1.selectedListItem = b;
		//                        e1.DecisionKey = h1[i].decisionKey;
		//                        e1.isMandatoryComment = h1[i].isMandatoryComment;
		//                        e1.text = h1[i].buttonText;
		//                        var f1 = a.getParameter("swipeContent");
		//                        f1.setText(e1.text);
		//                        var g1 = new w({
		//                            key: "APPROVE_DECISION",
		//                            value: e1
		//                        });
		//                        f1.removeAllCustomData();
		//                        f1.addCustomData(g1);
		//                        return;
		//                    }
		//                }
		//                a.bPreventDefault = true;
		//                L.error("No decision option with nature POSITVE found, no swipe possible.");
		//            }
		//        }
		//    },
		//    _handleSwipeApproved: function (a) {
		//        var b = this.getList();
		//        var h = b.getSwipedItem();
		//        b.swipeOut();
		//        var i = a.getSource().getCustomData()[0].getValue();
		//        i.InstanceID = h.getBindingContext().getProperty("InstanceID");
		//        i.SAP__Origin = h.getBindingContext().getProperty("SAP__Origin");
		//        if (i.isMandatoryComment) {
		//            this.showDecisionDialogForQuickAction(this.oDataManager.FUNCTION_IMPORT_DECISION, i, true);
		//        } else {
		//            if (h.getBindingContext().getProperty("Status") === "EXECUTED") {
		//                var j = this.oDataManager.FUNCTION_IMPORT_CONFIRM;
		//            } else {
		//                var j = this.oDataManager.FUNCTION_IMPORT_DECISION;
		//            }
		//            this.oDataManager.sendAction(j, i, "", q.proxy(function (k) {
		//                setTimeout(function () {
		//                    $.show(this.getView().getModel("i18n").getResourceBundle().getText("dialog.success.complete"));
		//                }.bind(this), 500);
		//            }, this));
		//        }
		//    },
		//    showDecisionDialogForQuickAction: function (a, b, h) {
		//        var i = this.getView().getModel("i18n").getResourceBundle();
		//        this.oConfirmationDialogManager.showDecisionDialog({
		//            question: i.getText("XMSG_DECISION_QUESTION", b.text),
		//            textAreaLabel: this.i18nBundle.getText("XFLD_TextArea_Decision"),
		//            showNote: h,
		//            title: i.getText("XTIT_SUBMIT_DECISION"),
		//            confirmButtonLabel: i.getText("XBUT_SUBMIT"),
		//            noteMandatory: b.isMandatoryComment,
		//            confirmActionHandler: q.proxy(function (b, j) {
		//                this.oDataManager.sendAction(a, b, j);
		//            }, this, b)
		//        });
		//    },
		//    onUpdateStarted: function (a) {
		//        var b = a.getSource();
		//        var h = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText("XMSG_LOADING");
		//        b.setNoDataText(h);
		//        var i = this.getView().getModel();
		//        var j = a.getParameter("reason");
		//        if (j == "Refresh" && b.getSelectedItem()) {
		//            if (i.bFullRefreshNeeded) {
		//                i.bFullRefreshNeeded = false;
		//            } else if (!t.system.phone) {
		//                this.oDataManager.fireItemRemoved();
		//            }
		//        }
		//        if (j !== "Growing") {
		//            this._setListBusyIndicator(true);
		//        }
		//    },
		onUpdateFinished: function(a) {
			this._setListBusyIndicator(false);
			if (!(this.isMultiSelectActive() && a.getParameter("reason") == "Growing") && (this.isActionPerformed || this.oDataManager.getCallFromDeepLinkURL() &&
					a.getSource().getItems().length > 0 || a.getParameter("reason") == "Refresh")) {
				this.fnFindAndSelectNextTaskAfterAction(a);
				this.isActionPerformed = false;
			}
			if (this.isMultiSelectActive() && a.getParameter("reason") === "Growing") {
				this.updateMultiSelectState();
			}
			if (a.getParameter("actual") === a.getParameter("total")) {
				this.bTaskCountFromTaskCollectionCall = false;
			}
			var b = a.getSource();
			if (!t.system.phone && this.isMultiSelectActive() == false && a.getParameter("reason") !== "Growing") {
				if (b.getSelectedItem() && b.getSelectedItem().$().offset() && b.getItems()[0].$().offset()) {
					b.getParent().scrollTo(b.getSelectedItem().$().offset().top - b.getItems()[0].$().offset().top, 0);
				}
			}
			var h = this.getView().getModel("i18n").getResourceBundle().getText("view.Workflow.noItemsAvailable");
			b.setNoDataText(h);
			var i = a.getSource().getItems();
			if (i && i[0] && i[0] instanceof Z && this._oControlStore.oMasterSearchField.getValue() === "") {
				this.applySearchPatternBase("");
			}
			var searchBtn = this.byId("myInbox_SEARCH");
			if (searchBtn.hasStyleClass("sapMFocus")) {
				searchBtn.removeStyleClass("sapMFocus");
			}
		},
		//    onDataLoaded: function () {
		//    },
		//    getDetailNavigationParameters: function (a) {
		//        var b = this.getView().getModel().getProperty(a.getBindingContext().getPath());
		//        return {
		//            SAP__Origin: encodeURIComponent(b.SAP__Origin),
		//            InstanceID: encodeURIComponent(b.InstanceID),
		//            contextPath: a.getBindingContext().getPath().substr(1)
		//        };
		//    },
		//    applySearchPattern: function (a) {
		//        var i = this.applySearchPatternBase(a);
		//        var k = i > 0 || a == "" ? "view.Workflow.noItemsAvailable" : "view.Workflow.noMatchingItems";
		//        var b = this.getView().getModel("i18n").getResourceBundle().getText(k);
		//        this.getList().setNoDataText(b);
		//        this.searchListFlag = 0;
		//        if (this.isMultiSelectActive()) {
		//            return i;
		//        }
		//        if (!t.system.phone) {
		//            if (i === 0) {
		//                this.oRouter.navTo("empty", null, true);
		//                this.getList().removeSelections(true);
		//                if (this.oDataManager && this.oDataManager.bOutbox) {
		//                    g.setShellTitleToOutbox(this.getOwnerComponent(), "cross.fnd.fiori.inbox.view.S2");
		//                }
		//            } else if (!this._checkSelectedItemFirstInSearch()) {
		//                this.oRouter.navTo("detail", this.searchListFirstItem, true);
		//                var h = this.findItemByContextPath("/" + this.searchListFirstItem.contextPath);
		//                if (h) {
		//                    this._clearSelection();
		//                    h.setSelected(true);
		//                }
		//            }
		//        }
		//        return i;
		//    },
		//    _checkSelectedItemFirstInSearch: function () {
		//        var a = this.getList().getSelectedItem();
		//        if (!a) {
		//            return false;
		//        } else if (!this.searchListFirstItem) {
		//            return false;
		//        } else {
		//            return a.getBindingContextPath() === "/" + this.searchListFirstItem.contextPath;
		//        }
		//    },
		//    _getBindingContextOfFirstItem: function () {
		//        var a = this.getList().getItems();
		//        var b = null;
		//        if (a.length == 1) {
		//            b = a[0].getBindingContext();
		//        }
		//        if (!b) {
		//            b = a[1].getBindingContext();
		//        }
		//        return b;
		//    },
		//    setSortItemsToDisplay: function () {
		//        var a;
		//        var b;
		//        this.aVisibleSortItems = [];
		//        var h = Object.keys(this.oSortConfig);
		//        for (var i = 0; i < h.length; i++) {
		//            var j = h[i];
		//            a = this.oSortConfig[j];
		//            b = a.getVisible ? a.getVisible() : true;
		//            if (b) {
		//                this.aVisibleSortItems.push({
		//                    key: j,
		//                    text: a.text
		//                });
		//            }
		//        }
		//    },
		//    handleFilter: function (a) {
		//        this.aItemContextPathsToSelect = [];
		//        this.aTaskTypeFilterItemsOrigins = [];
		//        var b = this.getFilter(a);
		//        this.sFilterKey_Support = a;
		//        var h = this.getAllFilters(b);
		//        var i = this.getList().getBinding("items");
		//        i.aApplicationFilters = [];
		//        this.iTotalFilteredItems = i.filter(h).iLastEndIndex;
		//        this.isActionPerformed = true;
		//    },
		//    onMultiSelectFilterCompleted: function (a, b, h) {
		//        var i = this.getList();
		//        i.removeSelections(true);
		//        var j = this.getView().getModel("i18n").getResourceBundle();
		//        this.refreshInfoHeaderToolbar(j.getText("multi.header", j.getText("group.taskType") + " (" + h.oFilterItem.title + ")"));
		//        i.setMode(a1.MultiSelect);
		//        this.setProcessingMultiSelect({});
		//    },
		//    onMultiSelectFilterFailed: function () {
		//        this.setProcessingMultiSelect({});
		//    },
		//    onTaskCollectionFailed: function () {
		//        this.removeHeaderFooterOptions();
		//    },
		//    onShowReleaseLoader: function (a, b, h) {
		//        var i = this.getList();
		//        if (i) {
		//            i.setEnableBusyIndicator(h.bValue);
		//        }
		//        this.getView().setBusyIndicatorDelay(1000);
		//        this.getView().setBusy(h.bValue);
		//    },
		//    onRefreshOnError: function () {
		//        this.sBindingContextPath = undefined;
		//        this.oRouter.navTo("master", {}, true);
		//    },
		//    handleSort: function (a) {
		//        this.aItemContextPathsToSelect = [];
		//        this.sSortKey_Support = a;
		//        var b = this.configureSorters(a);
		//        this.getList().getBinding("items").sort(b);
		//    },
		//    handleGroup: function () {
		//        this.aItemContextPathsToSelect = [];
		//        var a = this.configureSorters(this.sSortKey);
		//        this.getList().getBinding("items").sort(a);
		//        this.isActionPerformed = true;
		//    },
		//    configureSorters: function (a) {
		//        var b;
		//        var h = [];
		//        var i = null;
		//        var j = null;
		//        var k = null;
		//        var c1 = this.getView().getModel("i18n").getResourceBundle();
		//        if (this.oGroupConfigItem) {
		//            k = this.oGroupConfigItem.key;
		//            var d1 = this.bGroupDescending;
		//            var e1 = this.oGroupConfigItem.formatter || true;
		//            switch (this.oGroupConfigItem.key) {
		//            case this._SORT_PRIORITY:
		//                k = this._SORT_PRIORITY_NUMBER;
		//                d1 = !d1;
		//                break;
		//            }
		//            b = new n(k, d1, e1);
		//            h.push(b);
		//            this.sInfoHeaderGroupString = c1.getText("group.header", c1.getText(this.oGroupConfigItem.textKey));
		//        } else {
		//            this.sInfoHeaderGroupString = null;
		//        }
		//        this.refreshInfoHeaderToolbar();
		//        if (!a) {
		//            a = this.sDefaultSortKey;
		//        }
		//        if (!this.oSortConfig[a]) {
		//            a = this.sDefaultSortKey;
		//        }
		//        var f1 = a;
		//        var g1 = this.oSortConfig[a].descending;
		//        switch (a) {
		//        case this._SORT_PRIORITY:
		//            f1 = this._SORT_PRIORITY_NUMBER;
		//            g1 = !g1;
		//            break;
		//        case this._SORT_CREATEDONREVERSE:
		//            f1 = this._SORT_CREATEDON;
		//            break;
		//        }
		//        if (k != f1) {
		//            b = new n(f1, g1);
		//            h.push(b);
		//        }
		//        var h1 = this.getView().getModel();
		//        h1.extFnCustomGrouper = j ? q.proxy(j, this) : null;
		//        h1.extFnCustomSorter = i ? q.proxy(i, this) : null;
		//        h1.extSGroupingProperty = k;
		//        this.sSortKey = a;
		//        this.sGroupkey_Support = k;
		//        return h;
		//    },
		//    isBackendDefaultSortKeyEqualsTo: function (a) {
		//        return this.sBackendDefaultSortKey === a;
		//    },
		//    completionDeadLineSorter: function (i, a) {
		//        if (!i[this._SORT_COMPLETIONDEADLINE]) {
		//            return 1;
		//        }
		//        if (!a[this._SORT_COMPLETIONDEADLINE]) {
		//            return -1;
		//        }
		//        return i[this._SORT_COMPLETIONDEADLINE] - a[this._SORT_COMPLETIONDEADLINE];
		//    },
		//    statusGrouper: function (a, b, h) {
		//        var j;
		//        var k;
		//        var c1 = h ? -1 : 1;
		//        for (var i = 0; i < this._GROUP_STATUS_ORDER.length; i++) {
		//            var d1 = this._GROUP_STATUS_ORDER[i];
		//            if (d1.Status == a.GroupingValue) {
		//                j = i;
		//            }
		//            if (d1.Status == b.GroupingValue) {
		//                k = i;
		//            }
		//        }
		//        return (j - k) * c1;
		//    },
		//    getFilter: function (a) {
		//        var b = [];
		//        var h = [];
		//        var j = null;
		//        var k = [];
		//        var c1 = [];
		//        var d1 = [];
		//        var e1 = [];
		//        var f1 = [];
		//        var g1 = null;
		//        var h1 = null;
		//        var i1 = null;
		//        var j1 = Object.keys(a);
		//        for (var i = 0; i < j1.length; i++) {
		//            var k1 = j1[i];
		//            if (a.hasOwnProperty(k1) && k1) {
		//                var l1 = k1.split(":");
		//                switch (l1[0]) {
		//                case this._FILTER_CATEGORY_PRIORITY:
		//                    var m1 = I.getFilterForPriorityBykey(l1);
		//                    if (m1 != null) {
		//                        h.push(m1);
		//                    }
		//                    break;
		//                case this._FILTER_CATEGORY_COMPLETION_DEADLINE:
		//                    j = I.getFilterForDueDateByKey(l1);
		//                    break;
		//                case this._FILTER_CATEGORY_STATUS:
		//                    var n1 = I.getFilterForStatusByKey(l1);
		//                    if (n1 != null) {
		//                        e1.push(n1);
		//                    }
		//                    break;
		//                case this._FILTER_CATEGORY_CREATION_DATE:
		//                    g1 = I.getFilterForCreationDateByKey(l1);
		//                    break;
		//                case this._FILTER_CATEGORY_COMPLETED:
		//                    h1 = O.getCompletedFilterByKey(l1);
		//                    break;
		//                case this._FILTER_CATEGORY_SNOOZED:
		//                    i1 = O.getResumeOnFilterByKey(l1);
		//                    break;
		//                case this._FILTER_CATEGORY_TASK_DEFINITION_ID:
		//                    k.push(new r(l1[0], s.EQ, l1[1]));
		//                    c1.push(l1[1]);
		//                    this.aTaskTypeFilterItemsOrigins.push(l1[2]);
		//                    break;
		//                case this._FILTER_CATEGORY_SUBSTITUTED_USER:
		//                    d1.push(l1[1]);
		//                    break;
		//                default:
		//                    if (l1[0] && l1[1] && l1[0] !== "undefined" && l1[1] !== "undefined") {
		//                        f1.push(new r(l1[0], s.EQ, l1[1]));
		//                    }
		//                }
		//            }
		//        }
		//        var o1 = {
		//            selectedFilterOptions: a,
		//            taskDefinitionFilter: c1,
		//            substitutedUserFilter: d1,
		//            statusFilter: e1,
		//            priorityFilter: h,
		//            dueDateFilter: j,
		//            creationDateFilter: g1,
		//            completedDateFilter: h1,
		//            resumeDateFilter: i1,
		//            additionalFilters: f1
		//        };
		//        if (this.extHookGetCustomFilter) {
		//            this.extHookGetCustomFilter(o1);
		//        }
		//        this.getView().getModel().aTaskDefinitionIDFilterKeys = o1.taskDefinitionFilter;
		//        this.getView().getModel().aSubstitutedUserFilterKeys = o1.substitutedUserFilter;
		//        this.getView().getModel().aStatusFilterKeys = o1.statusFilter;
		//        if (o1.priorityFilter.length > 1) {
		//            b.push(new r(o1.priorityFilter, false));
		//        } else if (o1.priorityFilter.length === 1) {
		//            b.push(o1.priorityFilter[0]);
		//        }
		//        if (o1.dueDateFilter) {
		//            b.push(o1.dueDateFilter);
		//        }
		//        if (o1.creationDateFilter) {
		//            b.push(o1.creationDateFilter);
		//        }
		//        if (o1.completedDateFilter) {
		//            b.push(o1.completedDateFilter);
		//        }
		//        if (o1.resumeDateFilter) {
		//            b.push(o1.resumeDateFilter);
		//        }
		//        if (o1.additionalFilters.length > 1) {
		//            b.push(new r(o1.additionalFilters, true));
		//        } else if (o1.additionalFilters.length === 1) {
		//            b.push(o1.additionalFilters[0]);
		//        }
		//        if (b.length > 1) {
		//            return new r(b, true);
		//        } else if (b.length === 1) {
		//            return b[0];
		//        }
		//        return null;
		//    },
		//    handleMetadataFailed: function (a) {
		//        this.removeHeaderFooterOptions();
		//        this.oDataManager.handleMetadataFailed(a);
		//    },
		//    removeHeaderFooterOptions: function () {
		//        this.bHideHeaderFooterOptions = true;
		//        this.getAppImp().oMHFHelper.defineMasterHeaderFooter(this);
		//    },
		//    _setListBusyIndicator: function (b) {
		//        if (b) {
		//            this.getList().setBusyIndicatorDelay(1000);
		//            this.getList().setBusy(true);
		//        } else {
		//            this.getList().setBusy(false);
		//        }
		//    },
		//    getNextItemsToSelect: function () {
		//        return this.aItemContextPathsToSelect;
		//    },
		//    applySearchPatternBase: function (a) {
		//        a = a.toLowerCase();
		//        var b = this.getList().getItems();
		//        var h;
		//        var j = 0;
		//        var k = null;
		//        var c1 = 0;
		//        for (var i = 0; i < b.length; i++) {
		//            if (b[i] instanceof Z) {
		//                if (k) {
		//                    if (c1 == 0) {
		//                        k.setVisible(false);
		//                    } else {
		//                        k.setVisible(true);
		//                        k.setCount(c1);
		//                        k.setTooltip(k.getTitle() + " (" + c1 + ")");
		//                    }
		//                }
		//                k = b[i];
		//                c1 = 0;
		//            } else {
		//                h = this.applySearchPatternToListItem(b[i], a);
		//                b[i].setVisible(h);
		//                if (h) {
		//                    j++;
		//                    c1++;
		//                }
		//            }
		//        }
		//        if (k) {
		//            if (c1 == 0) {
		//                k.setVisible(false);
		//            } else {
		//                k.setVisible(true);
		//                k.setCount(c1);
		//                k.setTooltip(k.getTitle() + " (" + c1 + ")");
		//            }
		//        }
		//        if (!a) {
		//            if (this._oMasterListBinding) {
		//                j = this._oMasterListBinding.getLength();
		//            }
		//        }
		//        return j;
		//    },
		//    getPage: function () {
		//        return l.getPageFromController(this);
		//    },
		//    findItemByContextPath: function (a) {
		//        var b;
		//        var h = this.getList();
		//        var i = h.getItems();
		//        var j = q.grep(i, function (k) {
		//            b = k.getBindingContext();
		//            if (k instanceof Z) {
		//                return false;
		//            }
		//            if (b && b.getPath() !== a) {
		//                return false;
		//            }
		//            return true;
		//        });
		//        return j[0] || null;
		//    },
		//    setListsVisibility: function (b) {
		//        this.emptyList().setVisible(b);
		//        this.getList().setVisible(!b);
		//    },
		//    getAppImp: function () {
		//        return cross.fnd.fiori.inbox.util.tools.Application.getImpl();
		//    },
		//    _applyClientSideSearch: function () {
		//        var a = this._oControlStore.oMasterSearchField.getValue();
		//        var i = this.applySearchPattern(a);
		//        this.getAppImp().oMHFHelper.setMasterTitle(this, i);
		//        this.evaluateClientSearchResult(i, this.getList(), this.emptyList());
		//    },
		//    evaluateClientSearchResult: function (i, a, b, h) {
		//        var j = h;
		//        var k;
		//        if (i === 0) {
		//            if (j === null || j === undefined) {
		//                j = a.getNoDataText();
		//            }
		//            b.setNoDataText(j);
		//            k = true;
		//            this.setListsVisibility(k);
		//        } else {
		//            k = false;
		//            this.setListsVisibility(k);
		//        }
		//    },
		//    registerMasterListBind: function () {
		//        var a = this.getList();
		//        var b = a.getBinding("items");
		//        var h = this.getAppImp().getConnectionManager();
		//        var i = h.iRequestCount;
		//        this.getAppImp().setMasterListBinding(this, b);
		//        if (i === h.iRequestCount) {
		//            this.getAppImp().oMHFHelper.defineMasterHeaderFooter(this);
		//        }
		//    },
		//    getDetailRouteName: function () {
		//        return "detail";
		//    },
		//    _onMasterListLoaded: function (a) {
		//        this.onDataLoaded();
		//        this.getAppImp().onMasterRefreshed(this);
		//        a.getSource().detachChange(this._onMasterListLoaded, this);
		//        this._bListLoaded = true;
		//        this.fireEvent("_onMasterListLoaded");
		//    },
		//    _onMasterListChanged: function (a) {
		//        this.getAppImp().onMasterChanged(this);
		//        this.selectItemMatchingTheLastNavigation();
		//        var b = this.getList();
		//        if (b && b.getMode() === "MultiSelect" && this.getAppImp().bManualMasterRefresh === true) {
		//            b.removeSelections(true);
		//        }
		//        if (b.getBinding("items").getLength() > 0) {
		//            var h = false;
		//            this.setListsVisibility(h);
		//        }
		//    },
		//    selectItemMatchingTheLastNavigation: function () {
		//        var a = this.getList();
		//        if (a.getMode() === "MultiSelect") {
		//            return;
		//        }
		//        if (this._sDetailContextPath === undefined) {
		//            return;
		//        }
		//        var i = a.getSelectedItem();
		//        var b = i && i.getBindingContext();
		//        if (b && b.getPath() === this._sDetailContextPath) {
		//            return;
		//        }
		//        i = this.findItemByContextPath(this._sDetailContextPath);
		//        this._clearSelection();
		//        if (i) {
		//            i.setSelected(true);
		//        }
		//    },
		//    getSplitContainer: function () {
		//        return this.getView().getParent().getParent();
		//    }
	});
});