/*
    Start of code change : The dependency on CDataManager has been removed and the standard DataManager is being used in all calls
*/
sap.ui.define([
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/m/UploadCollectionParameter",
	"sap/m/VBox",
	"sap/m/ObjectAttribute",
	"sap/m/ObjectStatus",
	"sap/m/Text",
	"sap/m/Label",
	"sap/base/Log",
	"sap/base/security/encodeURL",
	"sap/suite/ui/commons/TimelineItem",
	"sap/ui/thirdparty/jquery",
	"sap/ui/Device",
	"sap/ui/core/Fragment",
	"sap/ui/core/mvc/XMLView",
	"sap/ui/layout/form/FormElement",
	"sap/ui/layout/ResponsiveFlowLayoutData",
	"sap/ui/model/Context",
	"sap/ui/model/json/JSONModel",
	"cross/fnd/fiori/inbox/attachment/util/AttachmentFormatters",
	"cross/fnd/fiori/inbox/controller/BaseController",
	"cross/fnd/fiori/inbox/util/tools/Application",
	"cross/fnd/fiori/inbox/util/tools/CommonHeaderFooterHelper",
	"cross/fnd/fiori/inbox/util/ActionHelper",
	"cross/fnd/fiori/inbox/util/Forward",
	"cross/fnd/fiori/inbox/util/ForwardSimple",
	"cross/fnd/fiori/inbox/util/SupportInfo",
	"cross/fnd/fiori/inbox/util/Conversions",
	"cross/fnd/fiori/inbox/util/DataManager",
	"cross/fnd/fiori/inbox/util/Resubmit",
	"cross/fnd/fiori/inbox/util/Parser",
	"cross/fnd/fiori/inbox/util/ConfirmationDialogManager",
	"cross/fnd/fiori/inbox/util/EmployeeCard",
	"cross/fnd/fiori/inbox/util/ComponentCache",
	"cross/fnd/fiori/inbox/util/CommonFunctions",
	"cross/fnd/fiori/inbox/util/Utils",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/Component",
	"sap/ui/core/routing/History",
	/*    Start of code change
    Formatter.js being fetched on loading of the controller
    */
	"cross/fnd/fiori/inbox/ZHR_MOBALLAP_S1/util/Formatter"
	/*    End of code change
    Formatter.js being fetched on loading of the controller
    */
], function(M, a, U, V, O, b, T, L, c, d, f, q, D, F, X, g, R, C, J, A, B, h, k, l, m, n, S, p, r, s, P, t, E, u, v, w, x, y, z,
	formatter) {
	"use strict";
	return sap.ui.controller("cross.fnd.fiori.inbox.ZHR_MOBALLAP_S1.view.S3Custom", {
		/*    Start of code change
         Removal of share button
        */
		extHookChangeFooterButtons: function(j) {
			var sButtonArray = j.aButtonList;
			var checkDesktop;
			if (sap.ui.Device.browser.name === 'sf' && sap.ui.Device.system.combi) {
				checkDesktop = false;
			} else {
				checkDesktop = sap.ui.Device.system.desktop;
			}
			if (!checkDesktop) {
				for (var i = 0; i < sButtonArray.length; i++) {
					if (sButtonArray[i].sI18nBtnTxt !== undefined && sButtonArray[i].sI18nBtnTxt === "XBUT_OPEN") {
						sButtonArray.splice(i, 1);
					}
				}
			}
			j.oJamOptions = null;
			j.oEmailSettings = null;
			return j;
		},
		/*    End of code change
         Removal of share button
        */
		/*    Start of code change
        Formatter being instantiated
        */
		formatter: formatter,
		/*    End of code change
		Formatter being instantiated
		*/
		lastSuccessItem: null,
		lastSuccessDecision: null,
		checkIsmultiSubmission: function(e) {
			if (this.lastSuccessItem === e.InstanceID) {
				sap.m.MessageBox.information("The request allready processed. Please wait or refresh the screen.");
				return false;
			} else {
				return true;
			}
		},
		_updateHeaderTitle: function(e) {
			if (e) {
				this.oHeaderFooterOptions = jQuery.extend(this.oHeaderFooterOptions, {
					sDetailTitle: "Mobile Allowance Approval"
				});
				this.refreshHeaderFooterOptions();
			}
		},
		showDecisionDialog: function(e, o, i) {
			if (!this.checkIsmultiSubmission(o)) {
				return;
			}
			var j = o && (o.ReasonRequired === "REQUIRED" || o.ReasonRequired === "OPTIONAL") ? this.oConfirmationDialogManager.loadReasonOptions(
				o, this.oDataManager) : null;
			var G = {
				question: this.i18nBundle.getText("XMSG_DECISION_QUESTION", o.DecisionText),
				textAreaLabel: this.i18nBundle.getText("XFLD_TextArea_Decision"),
				showNote: true,
				title: this.i18nBundle.getText("XTIT_SUBMIT_DECISION"),
				confirmButtonLabel: this.i18nBundle.getText("XBUT_SUBMIT"),
				noteMandatory: o.CommentMandatory,
				confirmActionHandler: function(o, N, H) {
					this.sendAction(e, o, N, H);
				}.bind(this, o)
			};
			if (j === null) {
				this.oConfirmationDialogManager.showDecisionDialog(G);
			} else {
				j.then(function(H) {
					G["reasonOptionsSettings"] = H;
					this.oConfirmationDialogManager.showDecisionDialog(G);
				}.bind(this)).catch(function(H) {
					this.oConfirmationDialogManager.showDecisionDialog(G);
					c.error("Could not load the reason options properly");
				}.bind(this));
			}
		},
		sendAction: function(e, o, N, i) {
			var j = this;
			var G;
			switch (e) {
				case "Release":
					G = "dialog.success.release";
					break;
				case "Claim":
					G = "dialog.success.reserve";
					break;
				case "AddComment":
					G = "dialog.success.addComment";
					break;
				case "Confirm":
					G = "dialog.success.completed";
					break;
				case "CancelResubmission":
					G = "dialog.success.cancelResubmission";
					break;
				default:
					G = "dialog.success.complete";
			}
			switch (e) {
				case "AddComment":
					{
						var I = this.oModel2.getData();
						var H = this._getIconTabControl("Comments");
						this._setBusyIncdicatorOnDetailControls(H, true);
						this.oDataManager.addComment(I.SAP__Origin, I.InstanceID, N, function(K, Q) {
							if (I.Comments && I.Comments.results) {
								I.Comments.results.unshift(K);
							} else {
								I.Comments = {
									results: [K]
								};
							}
							I.CommentsCount = I.Comments.results.length;
							this._setBusyIncdicatorOnDetailControls(H, false);
							this._updateDetailModel(I);
							setTimeout(function() {
								a.show(j.i18nBundle.getText(G));
							}, 500, this);
						}.bind(this), function(K) {
							this._setBusyIncdicatorOnDetailControls(H, false);
						}.bind(this));
						break;
					}
				case "Decision":
					{
						this.sendDecision(e, o, N, i);
						break;
					}
				default:
					{
						this.oDataManager.sendAction(e, o, N, i, function(e) {
							var t = "Request successfully processed";
							this.lastSuccessItem = e.InstanceID;
							this.lastSuccessDecision = e.DecisionText;
							if (e.DecisionText == "Approve") {
								t = "Request successfully approved";
							} else if (e.DecisionText == "Reject") {
								t = "Request successfully rejected";
							}
							var u = this.getView().getModel();
							var oDM = this.oDataManager;
							sap.m.MessageBox.success(t, {
								onClose: function() {
									u.refresh();
									if (sap.ui.Device.system.phone) {
										history.go(-1);
									} else {
										oDM.processListAfterAction(e.SAP__Origin, e.InstanceID);
									}
								}
							});
							if (this.isMob === true && window.navigator.notification && window.navigator.notification.sendLog) {
								window.navigator.notification.sendLog("MOB_ALL_APR::SUCCESS::" + e.DecisionText + e.InstanceID, null, "", "");
							}
						}.bind(this, o), function(e, o) {
							this.lastSuccessItem = null;
							this.lastSuccessDecision = null;
							var i = "failed \n";
							if (e.DecisionText == "Reject") {
								i = "Request for rejection failed";
							} else if (e.DecisionText == "Approve") {
								i = "Request for approval failed \n";
							}
							jQuery.sap.delayedCall(500, this, function() {
								sap.m.MessageBox.information(i + o.customMessage.details);
							});
							if (this.isMob === true && window.navigator.notification && window.navigator.notification.sendLog) {
								window.navigator.notification.sendLog("MOB_ALL_APR::FAILED::" + e.DecisionText + e.InstanceID + "::" + t, null,
									"", "");
							}
						}.bind(this, o));
					}
			}
		},
		sendDecision: function(e, o, N, i) {
			/* Start of code: To prevent repeated batch calls */
			var oDM = this.oDataManager;
			var requestKey = e + o.SAP__Origin + o.InstanceID;
			if (oDM._sentActionsMap[requestKey]) {
				return;
			}
			oDM._sentActionsMap[requestKey] = true;
			/* End of code: To prevent repeated batch calls */
			var oUrlParams = {
				SAP__Origin: "'" + encodeURIComponent(o.SAP__Origin) + "'", // eslint-disable-line camelcase
				InstanceID: "'" + (o.InstanceID) + "'"
			};

			if (o.DecisionKey) {
				oUrlParams.DecisionKey = "'" + o.DecisionKey + "'";
			}

			if (N && N.length > 0) {
				oUrlParams.Comments = "'" + N + "'";
			}

			if (i) {
				oUrlParams.ReasonCode = "'" + i + "'";
			}

			o.AllowanceApproved = this.byId("cbbAllowance").getSelectedKey();
			o.EndDate = this.byId("DPDurationTo").getValue("value");
			o.StartDate = this.byId("DPDurationFrom").getValue("value");
			if (!o.AllowanceApproved && e.DecisionText != "Approve") {
				o.AllowanceApproved = "0";
			}

			if (o.AllowanceApproved) {
				oUrlParams.AllowanceApproved = "'" + encodeURIComponent(o.AllowanceApproved) + "'";
			}

			if (o.EndDate) {
				oUrlParams.EndDate = "datetime'" + encodeURIComponent(o.EndDate) + "T00:00:00'";
			}

			if (o.StartDate) {
				oUrlParams.StartDate = "datetime'" + encodeURIComponent(o.StartDate) + "T00:00:00'";
			}

			var oDM = this.oDataManager;
			var sErrorMessage = oDM.oi18nResourceBundle.getText(oDM.getErrorMessageKey(e));
			oDM.fnShowReleaseLoader(true);

			var fnSuccess = function(e) {
				var t = "Request successfully processed";
				this.lastSuccessItem = e.InstanceID;
				this.lastSuccessDecision = e.DecisionText;
				if (e.DecisionText == "Approve") {
					t = "Request successfully approved";
				} else if (e.DecisionText == "Reject") {
					t = "Request successfully rejected";
				}
				var u = this.getView().getModel();
				var oDM = this.oDataManager;
				sap.m.MessageBox.success(t, {
					onClose: function() {
						u.refresh();
						if (sap.ui.Device.system.phone) {
							history.go(-1);
						} else {
							oDM.processListAfterAction(e.SAP__Origin, e.InstanceID);
						}
					}
				});
				if (this.isMob === true && window.navigator.notification && window.navigator.notification.sendLog) {
					window.navigator.notification.sendLog("MOB_ALL_APR::SUCCESS::" + e.DecisionText + e.InstanceID, null, "", "");
				}
			}.bind(this, o);

			var fnError = function(e, o) {
				this.lastSuccessItem = null;
				this.lastSuccessDecision = null;
				var i = "failed \n";
				if (e.DecisionText == "Reject") {
					i = "Request for rejection failed \n";
				} else if (e.DecisionText == "Approve") {
					i = "Request for approval failed \n";
				}
				// Start of code change by MH_Aarti 13.06.2023 - Defect 8000000797
				jQuery.sap.delayedCall(500, this, function() {
					sap.m.MessageBox.information(i + o.customMessage.details);
				});
				// End of code change by MH_Aarti 13.06.2023 - Defect 8000000797
				if (this.isMob === true && window.navigator.notification && window.navigator.notification.sendLog) {
					window.navigator.notification.sendLog("MOB_ALL_APR::FAILED::" + e.DecisionText + e.InstanceID + "::" + t, null,
						"", "");
				}
			}.bind(this, o);
			/*    Start of code change
						Standard message box hidden to display custom message box
    					*/
			var oRequestFailed = this.oDataManager.oModel.mEventRegistry.requestFailed;
			this.oDataManager.oModel.mEventRegistry.requestFailed = [];
			this.oDataManager.oDataRequestFailed = function(oError, fnError) {
				fnError(oError);
				var oMessage = "";
				if (e.DecisionText == "Approve") {
					oMessage = "Request for approval failed";
				} else if (e.DecisionText == "Reject") {
					oMessage = "Request for rejection failed";
				}
				var oParameters = {
					message: oMessage,
					responseText: oMessage
				};
				this.oDataManager.oModel.fireRequestFailed(oParameters);
			}.bind(this);
			/*    End of code change
						Standard message box hidden to display custom message box
    					*/
			oDM._performPost("/" + e, o.SAP__Origin, oUrlParams,
				function(o, fnSuccess) {
					/* Start of code: To prevent repeated batch calls */
					delete oDM._sentActionsMap[requestKey];
					/* End of code: To prevent repeated batch calls */
					oDM.fnShowReleaseLoader(false);
					// remove the processed item from the list
					oDM.processListAfterAction(o.SAP__Origin, o.InstanceID);
					oDM.triggerRefresh("SENDACTION", oDM.ACTION_SUCCESS);
					oDM.fireActionPerformed();
					// call the original success function
					if (fnSuccess) {
						fnSuccess();
					}
				}.bind(this, o, fnSuccess),
				function(oError) {
					/* Start of code: To prevent repeated batch calls */
					delete oDM._sentActionsMap[requestKey];
					/* End of code: To prevent repeated batch calls */
					oDM.fnShowReleaseLoader(false);
					// call the original error function
					if (fnError) {
						fnError(oError);
					}
					//refresh the list after error and select a task accordingly
					oDM.processListAfterAction(o.SAP__Origin, o.InstanceID);
					oDM.fireActionPerformed();
					oDM.triggerRefresh("SENDACTION", oDM.ACTION_FAILURE);
				}.bind(this),
				sErrorMessage
			);
		},
		/*    Start of code change
        Usage of onDataLoaded hook method to update SmartOffice view log
        */
		extHookOnDataLoaded: function(d) {
			// add by yusuf *******************************
			/*adding attachments*/ //custom attachments by yusuf
			var t = this;
			this.byId("cbbAllowance").setSelectedKey();
			this.byId("DPDurationFrom").setValue();
			this.byId("DPDurationTo").setValue("9999-12-31");
			var oPath = this.getView().getBindingContext().getPath();
			var commentURL = oPath + "/Comments";
			var onSuccessA = function(evt) {
				var com = t.oModel2.getData();
				com.Comments = evt;
				t.oModel2.setProperty("/Comments", com.Comments);
			};
			var onErrorA = function(evt) {};
			t.getView().getModel().read(commentURL, {
				success: jQuery.proxy(onSuccessA, t),
				error: jQuery.proxy(onErrorA, t)
			});

			var attachURL = oPath + "/Attachments";
			var onSuccessB = function(evt) {
				var Att = t.oModel2.getData();
				Att.Attachments = evt;
				t.oModel2.setProperty("/Attachments", Att.Attachments);
			};
			var onErrorB = function(evt) {};
			t.getView().getModel().read(attachURL, {
				success: jQuery.proxy(onSuccessB, t),
				error: jQuery.proxy(onErrorB, t)
			});
			// **************************************
			/*added: for logging the view of item*/
			this.isMob = /Android|iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream; //for fiori mob log
			if (d !== undefined && d.Description !== undefined) {
				if (this.isMob === true && this.currentinstanceID !== d.Description.InstanceID && window.navigator.notification && window.navigator
					.notification
					.sendLog) {
					this.currentinstanceID = d.Description.InstanceID;
					window.navigator.notification.sendLog("MOB_ALL_APR::VIEW::" + d.Description.InstanceID, null, "", "");
				}
			}
		},
		/*    End of code change
        Usage of onDataLoaded hook method to update SmartOffice View log
        */
		//    extHookOnDataLoaded: null,
		//    extHookGetEntitySetsToExpand: null,
		//    extHookChangeFooterButtons: null,
		//    oModel2: null,
		//    oDetailData2: null,
		//    oGenericComponent: null,
		//    oGenericAttachmentComponent: null,
		//    oConfirmationDialogManager: t,
		//    fnFormatterSupportsProperty: p.formatterSupportsProperty,
		//    oMapCountProperty: {
		//        "Comments": "CommentsCount",
		//        "Attachments": "AttachmentsCount",
		//        "ProcessingLogs": "ProcessingLogsCount"
		//    },
		//    bShowAdditionalAttributes: null,
		//    bTaskTitleInHeader: null,
		//    bStandaloneDetailDeep: null,
		//    sCustomTaskTitleAttribute: "CustomTaskTitle",
		//    sCustomNumberValueAttribute: "CustomNumberValue",
		//    sCustomNumberUnitValueAttribute: "CustomNumberUnitValue",
		//    sCustomObjectAttributeValue: "CustomObjectAttributeValue",
		//    sCustomCreatedByAttribute: "CustomCreatedBy",
		//    oCrossNavigationService: null,
		//    OPEN_MODES: [
		//        "embedIntoDetails",
		//        "replaceDetails",
		//        "external",
		//        "genericEmbedIntoDetails",
		//        "embedIntoDetailsNestedRouter"
		//    ],
		//    sCustomCreatedByValue: null,
		//    _taskSwitchCount: 0,
		//    embedFioriElements: null,
		//    _lastTargetDisplayed: false,
		//    routeName: null,
		//    onExit: function () {
		//        this.oComponentCache.destroyCacheContent();
		//        delete this.oComponentCache;
		//    },
		//    onInit: function () {
		//        var o = this.getView();
		//        this.i18nBundle = this.getResourceBundle();
		//        this.sResubmitUniqueId = this.createId() + "DLG_RESUBMIT";
		//        var e = this.getOwnerComponent().getEventBus();
		//        e.subscribe("cross.fnd.fiori.inbox", "open_supportinfo", this.onSupportInfoOpenEvent, this);
		//        e.subscribe("cross.fnd.fiori.inbox.dataManager", "taskCollectionFailed", this.onTaskCollectionFailed.bind(this));
		//        e.subscribe("cross.fnd.fiori.inbox.dataManager", "showReleaseLoaderOnInfoTab", this.onShowReleaseLoaderOnInfoTab.bind(this));
		//        e.subscribe("cross.fnd.fiori.inbox.dataManager", "showReleaseLoader", this.onShowReleaseLoader.bind(this));
		//        e.subscribe("cross.fnd.fiori.inbox.dataManager", "UIExecutionLinkRequest", this.onShowReleaseLoader.bind(this));
		//        this.aCA = [];
		//        this.aTaskDefinitionData = [];
		//        this.aUIExecutionLinkCatchedData = [];
		//        this.oRouter = this.getOwnerComponent().getRouter();
		//        this.oRouter.attachRoutePatternMatched(this.handleNavToDetail, this);
		//        this.oRouter.attachBeforeRouteMatched(this.handleBeforeRouteMatched, this);
		//        this.oHeaderFooterOptions = {};
		//        this.oTabBar = o.byId("tabBar");
		//        var i = this.getOwnerComponent().getDataManager();
		//        if (i) {
		//            var j = i.getCacheSize();
		//            if (j) {
		//                this.oComponentCache = new u(j);
		//            } else {
		//                this.oComponentCache = new u();
		//            }
		//        } else {
		//            this.oComponentCache = new u();
		//        }
		//        this._setExtensionState(false);
		//        this.getView().byId("InvisibleTabStop").addEventDelegate({
		//            onsapspace: function (G) {
		//                var H;
		//                if (this.bShowLogs) {
		//                    H = this.byId("LogButtonID");
		//                    if (H) {
		//                        this.onLogBtnPress();
		//                    }
		//                } else if (this.bShowDetails) {
		//                    H = this.byId("DetailsButtonID");
		//                    if (H) {
		//                        this.onDetailsBtnPress();
		//                    }
		//                }
		//                setTimeout(function () {
		//                    H.focus();
		//                }, 300);
		//            }
		//        }, this);
		//        if (!i.oServiceMetaModel) {
		//            i.oModel.getMetaModel().loaded().then(function () {
		//                i.oServiceMetaModel = i.oModel.getMetaModel();
		//            }.bind(this));
		//        }
		//        this.oAppImp = cross.fnd.fiori.inbox.util.tools.Application.getImpl();
		//    },
		//    onTaskCollectionFailed: function () {
		//        this.getView().setBusy(false);
		//    },
		//    onShowReleaseLoaderOnInfoTab: function (e, i, o) {
		//        var I = this.getView().byId("infoTabContent");
		//        if (I) {
		//            I.setBusyIndicatorDelay(0).setBusy(o.bValue);
		//        }
		//    },
		//    onShowReleaseLoader: function (e, i, o) {
		//        this.getView().setBusyIndicatorDelay(1000);
		//        this.getView().setBusy(o.bValue);
		//    },
		//    createGenericCommentsComponent: function (o) {
		//        var e = this._getEmbedIntoDetailsNestedRouter() ? o.byId("commentsContainerInDetails") : o.byId("commentsContainer");
		//        if (!q.isEmptyObject(this.oGenericCommentsComponent)) {
		//            this.oGenericCommentsComponent.destroy();
		//            delete this.oGenericCommentsComponent;
		//        }
		//        this.oGenericCommentsComponent = sap.ui.getCore().createComponent({
		//            name: "cross.fnd.fiori.inbox.comments",
		//            componentData: { oModel: this.oModel2 }
		//        });
		//        this.oGenericCommentsComponent.setContainer(e);
		//        e.setComponent(this.oGenericCommentsComponent);
		//        this.oGenericCommentsComponent.getEventBus().subscribe(null, "commentAdded", this.onCommentPost.bind(this));
		//        this.oGenericCommentsComponent.getEventBus().subscribe(null, "businessCardRequested", this.onEmployeeLaunchCommentSender.bind(this));
		//    },
		//    resetDetailView: function () {
		//        if (!this.oModel2)
		//            return;
		//        this.oModel2.setProperty("/showDefaultView", false);
		//        this.oModel2.setProperty("/embedFioriElements", false);
		//        this.oModel2.setProperty("/showGenericComponent", false);
		//    },
		//    handleBeforeRouteMatched: function () {
		//        this._suspendTarget(this._lastTargetDisplayed);
		//    },
		//    handleNavToDetail: function (e) {
		//        this.oRoutingParameters = e.getParameters().arguments;
		//        this.routeName = e.getParameter("name");
		//        if (this.routeName === "detail" || this.routeName === "detail_deep") {
		//            this.bIsTableViewActive = this.routeName === "detail_deep" && !this.bNavToFullScreenFromLog;
		//            var i = e.getParameter("arguments").InstanceID;
		//            var j = e.getParameters().arguments.contextPath;
		//            var o = e.getParameter("arguments").SAP__Origin;
		//            if (i && i.lastIndexOf(":") === i.length - 1) {
		//                return;
		//            }
		//            this._taskSwitchCount++;
		//            this.resetDetailView();
		//            var G = "/TaskCollection(SAP__Origin='" + o + "',InstanceID='" + i + "')";
		//            if (q.isEmptyObject(this.getView().getModel().getProperty(G))) {
		//                var H = this.getOwnerComponent().getDataManager();
		//                H.oModel.getMetaModel().loaded().then(function (I) {
		//                    if (I !== this._taskSwitchCount) {
		//                        c.warning("getMetaModel: task switched while waiting!");
		//                        return;
		//                    }
		//                    var K = this;
		//                    var N = [];
		//                    if (H.getShowAdditionalAttributes() && H.checkPropertyExistsInMetadata("CustomAttributeData")) {
		//                        N.push("$expand=CustomAttributeData");
		//                    }
		//                    H.setCallFromDeepLinkURL(true);
		//                    H.oDataRead(G, N, function (I, Q) {
		//                        if (I !== this._taskSwitchCount) {
		//                            c.warning("oDataRead: task switched while waiting!");
		//                            return;
		//                        }
		//                        H = K.getOwnerComponent().getDataManager();
		//                        if (Q === undefined || q.isEmptyObject(Q)) {
		//                            H.setDetailPageLoadedViaDeepLinking(false);
		//                        } else {
		//                            var W = q.extend(true, {}, Q);
		//                            if (K.fnIsTaskInstanceAllowed(W, H)) {
		//                                H.setDetailPageLoadedViaDeepLinking(true);
		//                                K.fnPerpareToRefreshData(j, i, o);
		//                            } else {
		//                                H.setDetailPageLoadedViaDeepLinking(false);
		//                                if (H.getStandaloneDetailDeep() && !H.getTableView() && !(typeof K.getView().getParent().getParent().isMasterShown === "function" && K.getView().getParent().getParent().isMasterShown())) {
		//                                    K.oRouter.navTo("detail_deep_empty", null, false);
		//                                }
		//                            }
		//                        }
		//                    }.bind(this, this._taskSwitchCount), function (I, Q) {
		//                        if (I !== this._taskSwitchCount) {
		//                            c.warning("oDataRead(fail): task switched while waiting!");
		//                            return;
		//                        }
		//                        K.getOwnerComponent().getDataManager().setDetailPageLoadedViaDeepLinking(false);
		//                        var H = K.getOwnerComponent().getDataManager();
		//                        if (H.getStandaloneDetailDeep() && !H.getTableView() && !(typeof K.getView().getParent().getParent().isMasterShown === "function" && K.getView().getParent().getParent().isMasterShown())) {
		//                            var W = K.i18nBundle.getText("detailDeepEmptyView.closingTabMessage");
		//                            var Y = null;
		//                            if (Q.hasOwnProperty("responseText") && v.isJson(Q.responseText)) {
		//                                Y = JSON.parse(Q.responseText);
		//                            }
		//                            if (Y && Y.error && Y.error.message && Y.error.message.value) {
		//                                W = Y.error.message.value + ". " + W;
		//                            } else if (Q.hasOwnProperty("message")) {
		//                                W = Q.message + ". " + W;
		//                            }
		//                            K.getView().getModel().sDetailDeepEmptyMessage = W;
		//                            K.oRouter.navTo("detail_deep_empty", null, false);
		//                        } else {
		//                            K.showEmptyView(null, "detailDeepEmptyView.noLongerAvailableTaskMessage");
		//                        }
		//                    }.bind(this, this._taskSwitchCount));
		//                }.bind(this, this._taskSwitchCount));
		//            } else {
		//                this.fnPerpareToRefreshData(j, i, o);
		//            }
		//        }
		//    },
		//    fnPerpareToRefreshData: function (e, i, j) {
		//        if (!this.stayOnDetailScreen || D.system.phone) {
		//            var o = this.oTabBar.getItems()[0];
		//            this.oTabBar.setSelectedItem(o);
		//        } else {
		//            this.stayOnDetailScreen = false;
		//        }
		//        var G = {
		//            sCtxPath: "/" + e,
		//            sInstanceID: i,
		//            sSAP__Origin: j,
		//            bCommentCreated: false
		//        };
		//        this.refreshData(G);
		//        if (!D.system.phone) {
		//            var H = this.getOwnerComponent().getDataManager();
		//            if (H && H.bOutbox) {
		//                p.setShellTitleToOutbox(this.getOwnerComponent(), "cross.fnd.fiori.inbox.view.S3");
		//            }
		//        }
		//    },
		//    fnIsTaskInstanceAllowed: function (i, o) {
		//        if (o.bOutbox && (i.Status === "COMPLETED" || i.Status === "FOR_RESUBMISSION")) {
		//            return true;
		//        } else if (!o.bOutbox && (i.Status === "READY" || i.Status === "RESERVED" || i.Status === "IN_PROGRESS" || i.Status === "EXECUTED")) {
		//            return true;
		//        } else {
		//            return false;
		//        }
		//    },
		//    fnGetUploadUrl: function (e) {
		//        return this.oContext.getModel().sServiceUrl + e + "/Attachments";
		//    },
		//    fnCreateAttachmentHandle: function (e) {
		//        var o = {
		//            fnOnAttachmentChange: this.onAttachmentChange.bind(this),
		//            fnOnAttachmentUploadComplete: this.onAttachmentUploadComplete.bind(this),
		//            fnOnAttachmentDeleted: this.onAttachmentDeleted.bind(this),
		//            detailModel: this.oModel2,
		//            uploadUrl: this.fnGetUploadUrl(this.sCtxPath)
		//        };
		//        return o;
		//    },
		//    fnRenderComponent: function (o) {
		//        if (this.oDataManager.bDebug) {
		//            var e = this.oGenericComponent && this.oGenericComponent.getId && this.oGenericComponent.getId();
		//            this.oComponentCache.destroyCacheContent(e);
		//        }
		//        var i = this.oModel2.getData();
		//        var j = i ? i["TaskDefinitionID"] : "";
		//        var G = i ? i["SAP__Origin"] : "";
		//        var K = j.concat(G);
		//        var H = undefined;
		//        if (o.ComponentName === "cross.fnd.fiori.inbox.annotationBasedTaskUI") {
		//            K = this.generateEscapedComponentKey(K);
		//            H = K;
		//        }
		//        var I = p.formatterPriority.call(this.getView(), G, i ? i["Priority"] : "");
		//        var N = i ? i["StatusText"] : "";
		//        if (!N) {
		//            N = p.formatterStatus.call(this.getView(), G, i ? i["Status"] : "");
		//        }
		//        this.oModel2.setProperty("/PriorityText", I);
		//        this.oModel2.setProperty("/StatusText", N);
		//        var Q = this.oComponentCache.getComponentByKey(K);
		//        var W = {
		//            sServiceUrl: o.ServiceURL,
		//            sAnnoFileURI: o.AnnotationURL,
		//            sErrorMessageNoData: this.i18nBundle.getText("annotationcomponent.load.error"),
		//            sApplicationPath: o.ApplicationPath,
		//            oTaskModel: this.fnCloneTaskModel(i),
		//            oQueryParameters: o.QueryParameters
		//        };
		//        var Y = {
		//            startupParameters: {
		//                oParameters: W,
		//                taskModel: this.fnCloneTaskModel(i),
		//                inboxAPI: this.getInboxAPI(),
		//                inboxInternal: { updateTaskList: this.updateTaskList.bind(this) }
		//            },
		//            inboxHandle: {
		//                attachmentHandle: this.fnCreateAttachmentHandle(this.sCtxPath),
		//                tabSelectHandle: { fnOnTabSelect: this.onTabSelect.bind(this) },
		//                inboxDetailView: this
		//            }
		//        };
		//        var Z = this.getView();
		//        if (!q.isEmptyObject(this.oGenericComponent)) {
		//            if (!this.oComponentCache.getComponentById(this.oGenericComponent.getId())) {
		//                this.oGenericComponent.destroy();
		//            }
		//        }
		//        if (q.isEmptyObject(Q)) {
		//            if (o.ApplicationPath && o.ApplicationPath !== "") {
		//                var $ = o.ApplicationPath[0] === "/" ? o.ApplicationPath : "/" + o.ApplicationPath;
		//                var _ = o.ComponentName.replace(/\./g, "/");
		//                var a1 = {};
		//                a1[_] = $;
		//                sap.ui.loader.config({ paths: a1 });
		//            }
		//            try {
		//                var b1 = function () {
		//                    return sap.ui.getCore().createComponent({
		//                        name: o.ComponentName,
		//                        componentData: Y,
		//                        id: H
		//                    });
		//                };
		//                var c1 = y.getOwnerComponentFor(this.getView());
		//                if (c1 && c1.runAsOwner) {
		//                    Q = c1.runAsOwner(b1);
		//                } else {
		//                    Q = b1();
		//                }
		//                if (Q && Q.getIsCacheable && Q.getIsCacheable() === true) {
		//                    try {
		//                        this.oComponentCache.cacheComponent(K, Q);
		//                    } catch (d1) {
		//                        c.error(d1);
		//                    }
		//                }
		//            } catch (e1) {
		//                c.error("Cannot create component" + o.ComponentName + "for smart template rendering. Showing standard task in the detail screen as a fallback: " + e1.message);
		//                return false;
		//            }
		//        } else if (Q && Q.updateBinding) {
		//            Q.updateBinding(Y);
		//        }
		//        Z.byId("genericComponentContainer").setComponent(Q);
		//        this.oGenericComponent = Q;
		//        return true;
		//    },
		//    _suspendTarget: function (e) {
		//        if (!e) {
		//            return;
		//        }
		//        var i = this.oRouter.getTargets();
		//        var j = i.getTarget(e);
		//        if (j === undefined) {
		//            return;
		//        }
		//        j.suspend();
		//    },
		//    getComponentViaRoutingTarget: function (e, i, j, o, I, G, H) {
		//        var K = this.oRouter.getTargets();
		//        var N = false;
		//        if (K.getTarget(e) === undefined) {
		//            K.addTarget(e, {
		//                name: i,
		//                options: j,
		//                type: "Component",
		//                controlAggregation: "flexContent",
		//                id: e,
		//                controlId: "fioriElementsContainer",
		//                parent: this.routeName === "detail" ? "myInboxDetail" : "myInboxDetailDeep"
		//            });
		//            N = true;
		//        }
		//        K.display({
		//            name: e,
		//            prefix: e,
		//            routeRelevant: true,
		//            ignoreInitialHash: true
		//        }).then(function (Q, W, Y, Z) {
		//            if (Y !== this._taskSwitchCount) {
		//                c.warning("target.display: task switched while waiting!");
		//                return;
		//            }
		//            if (Q) {
		//                return;
		//            }
		//            var $ = Z[0].view.getComponentInstance();
		//            $.navigateBasedOnStartupParameter(W);
		//        }.bind(this, N, JSON.parse(JSON.stringify(o)), this._taskSwitchCount)).catch(function (Q, W) {
		//            if (Q !== this._taskSwitchCount) {
		//                c.warning("target.display(fail): task switched while waiting!");
		//                return;
		//            }
		//            c.error(W);
		//            this.fnViewTaskInDefaultView(I, G, H);
		//        }.bind(this, this._taskSwitchCount));
		//        this._lastTargetDisplayed = e;
		//    },
		//    generateEscapedComponentKey: function (e) {
		//        return "inb_" + btoa(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/[=]/g, "");
		//    },
		//    fnParseComponentParameters: function (e) {
		//        var o = P.fnParseComponentParameters(e);
		//        this.isGenericComponentRendered = !q.isEmptyObject(o) ? this.fnRenderComponent(o) : false;
		//        this.oModel2.setProperty("/showGenericComponent", this.isGenericComponentRendered);
		//        if (this.isGenericComponentRendered) {
		//            this.oModel2.setProperty("/embedFioriElements", false);
		//            this.oModel2.setProperty("/showDefaultView", false);
		//            this.embedFioriElements = false;
		//            this.showHideSideContent();
		//        }
		//        this.fnShowHideDetailScrollBar(!this.isGenericComponentRendered);
		//    },
		//    fnCloneTaskModel: function (o) {
		//        var e = [
		//            "SAP__Origin",
		//            "InstanceID",
		//            "TaskDefinitionID",
		//            "TaskDefinitionName",
		//            "TaskTitle",
		//            "Priority",
		//            "PriorityText",
		//            "Status",
		//            "StatusText",
		//            "CreatedOn",
		//            "CreatedBy",
		//            "CreatedByName",
		//            "Processor",
		//            "ProcessorName",
		//            "SubstitutedUser",
		//            "SubstitutedUserName",
		//            "StartDeadLine",
		//            "CompletionDeadLine",
		//            "ExpiryDate",
		//            "IsEscalated",
		//            "PriorityNumber",
		//            "ConfidenceLevel"
		//        ];
		//        var j = {};
		//        for (var i = 0; i < e.length; i++) {
		//            if (o.hasOwnProperty(e[i])) {
		//                j[e[i]] = o[e[i]];
		//            }
		//        }
		//        var G = this.getView();
		//        var H = G.getModel("detailClone");
		//        if (!H) {
		//            H = new J();
		//            G.setModel(H, "detailClone");
		//        }
		//        H.setData(j, false);
		//        return H;
		//    },
		//    fnShowHideDetailScrollBar: function (e) {
		//        if (e) {
		//            this.byId("mainPage").setEnableScrolling(true);
		//        } else {
		//            this.byId("mainPage").setEnableScrolling(false);
		//        }
		//    },
		//    switchToOutbox: function () {
		//        return this.oDataManager.bOutbox ? true : false;
		//    },
		//    _updateDetailModel: function (i, e) {
		//        if (this.oModel2) {
		//            this.oModel2.setData(i, e);
		//            this.fnCloneTaskModel(this.oModel2.getData());
		//        } else {
		//            c.error("Detail Model is null.");
		//        }
		//    },
		//    _getCustomAttributesValue: function (I) {
		//        var e = I.CustomAttributeData;
		//        var j = [];
		//        for (var i = 0; i < e.length; i++) {
		//            j[i] = this.getView().getModel().getProperty("/" + e[i]);
		//        }
		//        return j;
		//    },
		//    refreshData: function (o, e) {
		//        if (e !== undefined) {
		//            this.aTaskDefinitionData = e;
		//        } else {
		//            var i = this.getView().getModel("taskDefinitionsModel");
		//            this.aTaskDefinitionData = i ? i.getData() : [];
		//        }
		//        if (!this.bIsControllerInited) {
		//            var j = this.getOwnerComponent();
		//            this.oDataManager = j.getDataManager();
		//            if (!this.oDataManager) {
		//                var G = this.getView().getModel();
		//                this.oDataManager = new r(this);
		//                this.oDataManager.setModel(G);
		//                j.setDataManager(this.oDataManager);
		//            }
		//            this.oDataManager.attachItemRemoved(this._handleItemRemoved.bind(this));
		//            this.oDataManager.attachRefreshDetails(this._handleDetailRefresh.bind(this));
		//            this.bIsControllerInited = true;
		//        }
		//        if (this.bIsTableViewActive === true) {
		//            this.aTaskDefinitionData = this.oDataManager.getTaskDefinitionModel();
		//        }
		//        this.clearCustomAttributes();
		//        var H = this.getView();
		//        this.oContext = new C(H.getModel(), o.sCtxPath);
		//        H.setBindingContext(this.oContext);
		//        this.sCtxPath = o.sCtxPath;
		//        var I = q.extend(true, {}, H.getModel().getData(this.oContext.getPath(), this.oContext));
		//        if (q.isEmptyObject(I)) {
		//            I = q.extend(true, {}, H.getModel().getData(encodeURI(this.oContext.getPath()), this.oContext));
		//        }
		//        if (q.isEmptyObject(I) && this._getStandaloneDetailDeep() && !this.oDataManager.getTableView() && !(typeof this.getView().getParent().getParent().isMasterShown === "function" && this.getView().getParent().getParent().isMasterShown())) {
		//            this.oRouter.navTo("detail_deep_empty", null, false);
		//            return;
		//        }
		//        if (q.isEmptyObject(I)) {
		//            this.showEmptyView(null, "detailDeepEmptyView.noLongerAvailableTaskMessage");
		//            return;
		//        }
		//        var K = this._getActionHelper();
		//        this.getOwnerComponent().getEventBus().publish("cross.fnd.fiori.inbox", "storeNextItemsToSelect", {
		//            "sOrigin": I.SAP__Origin,
		//            "sInstanceID": I.InstanceID
		//        });
		//        if (this._getShowAdditionalAttributes() === true) {
		//            I = this._processCustomAttributesData(I);
		//        }
		//        if (I.TaskSupports && !I.TaskSupports.WorkflowLog) {
		//            I.TaskSupports.WorkflowLog = false;
		//        }
		//        if (!this.oModel2) {
		//            this.oModel2 = new J();
		//            H.setModel(this.oModel2, "detail");
		//        }
		//        this._updateDetailModel(I, true);
		//        this.oModel2.setProperty("/CustomAttributeData", I.CustomAttributeData ? I.CustomAttributeData : []);
		//        this.oModel2.setProperty("/sServiceUrl", H.getModel().sServiceUrl);
		//        this.oModel2.setProperty("/SapUiTheme", K._getThemeandLanguageLocaleParams()["sap-ui-theme"]);
		//        var N = this;
		//        this._updateHeaderTitle(I);
		//        var Q = H.byId("genericComponentContainer");
		//        var W = Q && Q.getComponent() ? Q.getComponent() : null;
		//        if (W) {
		//            var Y = this.oComponentCache.getComponentById(W) || null;
		//            if (!Y) {
		//                var Z = sap.ui.getCore().getComponent(W);
		//                if (Z) {
		//                    Z.destroy();
		//                }
		//            }
		//        }
		//        var $ = function (e, b1) {
		//            if (N.extHookOnDataLoaded) {
		//                if (!e.CustomAttributeData) {
		//                    e.CustomAttributeData = {};
		//                    e.CustomAttributeData.results = this._getCustomAttributesValue(I);
		//                }
		//                N.extHookOnDataLoaded(e);
		//            }
		//            if (N.aCA.length > 0) {
		//                N.clearCustomAttributes();
		//            }
		//            if (this._getShowAdditionalAttributes() === true) {
		//                if (e.CustomAttributeData && e.CustomAttributeData.hasOwnProperty("__deferred")) {
		//                    delete e.CustomAttributeData;
		//                }
		//            }
		//            if ((!this.aTaskDefinitionData || q.isEmptyObject(this.aTaskDefinitionData)) && b1 && b1[0] && b1[0].TaskDefinitionID) {
		//                var c1 = b1[0].TaskDefinitionID;
		//                var d1 = {};
		//                d1.results = b1;
		//                this.aTaskDefinitionData = [];
		//                this.aTaskDefinitionData[0] = new Object();
		//                this.aTaskDefinitionData[0].CustomAttributeDefinitionData = d1;
		//                this.aTaskDefinitionData[0].TaskDefinitionID = c1;
		//            }
		//            N._updateDetailModel(e, true);
		//            N.oDetailData2 = e;
		//            var e1 = N.byId("tabBar").getSelectedKey();
		//            if (e1 === "NOTES") {
		//                N.fnSetIconForCommentsFeedInput();
		//                this.fnFetchDataOnTabSelect("Comments");
		//            } else if (e1 === "ATTACHMENTS") {
		//                this.fnFetchDataOnTabSelect("Attachments");
		//            } else if (e1 === "OBJECTLINKS") {
		//                N.fnFetchObjectLinks();
		//            } else if (e1 === "DESCRIPTION") {
		//                N.byId("DescriptionContent").rerender();
		//            }
		//            if (!this._getShowAdditionalAttributes()) {
		//                if (e.CustomAttributeData.results && e.CustomAttributeData.results.length > 0) {
		//                    N.oModel2.setProperty("/CustomAttributeData", e.CustomAttributeData.results);
		//                }
		//            } else if (this._getShowAdditionalAttributes() === true) {
		//                if (N.oModel2.getData().CustomAttributeDefinitionData == null && b1) {
		//                    N.oModel2.setProperty("/CustomAttributeDefinitionData", b1);
		//                }
		//            }
		//            var f1 = N._createCustomAttributesOnDataLoaded.bind(N);
		//            f1(b1);
		//        };
		//        var _ = null;
		//        if (this.bIsTableViewActive) {
		//            _ = this.fnNavBackToTableVw.bind(this);
		//        } else if (D.system.phone && !this.bNavToFullScreenFromLog) {
		//            _ = this.fnOnNavBackInMobile.bind(this);
		//        } else if (this.bNavToFullScreenFromLog) {
		//            _ = this.fnOnNavBackFromLogDescription.bind(this);
		//        }
		//        if (this.getOwnerComponent().oShellUIService && _) {
		//            this.getOwnerComponent().oShellUIService.setBackNavigation(_);
		//        }
		//        if (this.oHeaderFooterOptions) {
		//            this.oHeaderFooterOptions = q.extend(this.oHeaderFooterOptions, {
		//                oPositiveAction: null,
		//                oNegativeAction: null,
		//                buttonList: [],
		//                oJamOptions: null,
		//                oEmailSettings: null,
		//                oUpDownOptions: null,
		//                onBack: this.getOwnerComponent().oShellUIService ? null : _
		//            });
		//            this.refreshHeaderFooterOptions();
		//        }
		//        if (this.oModel2 != null) {
		//            this.fnClearCachedData();
		//        }
		//        var a1 = function (b1, c1) {
		//            if (b1 !== this._taskSwitchCount) {
		//                c.warning("fetchUIExecutionLinkCallback: task switched while waiting!");
		//                return;
		//            }
		//            I.UIExecutionLink = c1;
		//            N.oModel2.setProperty("/UIExecutionLink", c1);
		//            this.fnHandleIntentValidationAndNavigation(I, o, $);
		//        }.bind(this, this._taskSwitchCount);
		//        this.oDataManager.fetchUIExecutionLink(I, a1.bind(this), a1.bind(this));
		//    },
		//    loadDecisionOptions: function (i, o, G) {
		//        var I = i.TaskSupports && i.TaskSupports.UIExecutionLink;
		//        if (!this.oDataManager.bOutbox && i.Status !== "COMPLETED" && i.Status !== "FOR_RESUBMISSION") {
		//            this.oDataManager.readDecisionOptions(i.SAP__Origin, i.InstanceID, i.TaskDefinitionID, function (e, j) {
		//                if (e !== this._taskSwitchCount) {
		//                    c.warning("readDecisionOptions: task switched while waiting!");
		//                    return;
		//                }
		//                this.fnValidateDecisionOptionsAndCreatButtons(I, j, i.UIExecutionLink, o.sSAP__Origin);
		//            }.bind(this, this._taskSwitchCount), function (e, j) {
		//                c.error("Error while loading decision options");
		//                if (e !== this._taskSwitchCount) {
		//                    c.warning("readDecisionOptions(fail): task switched while waiting!");
		//                    return;
		//                }
		//                this.fnValidateDecisionOptionsAndCreatButtons(I, [], i.UIExecutionLink, o.sSAP__Origin);
		//            }.bind(this, this._taskSwitchCount), false, G);
		//        } else {
		//            this.fnValidateDecisionOptionsAndCreatButtons(I, [], i.UIExecutionLink, o.sSAP__Origin);
		//        }
		//    },
		//    fnHandleIntentValidationAndNavigation: function (i, o, e) {
		//        var j = this;
		//        var G = i.UIExecutionLink.GUI_Link;
		//        var H = this._getParsedParamsForIntent(G);
		//        var I = this._getCrossNavigationService();
		//        if (H && I) {
		//            var K = this._getIntentParam(H);
		//            I.isNavigationSupported(K, cross.fnd.fiori.inbox.util.tools.Application.getImpl().getComponent()).done(function (N, Q) {
		//                if (N !== this._taskSwitchCount) {
		//                    c.warning("isNavigationSupported: task switched while waiting!");
		//                    return;
		//                }
		//                var W = j._getSupportedOpenMode(Q);
		//                if (W) {
		//                    j.fnHandleIntentNavigation(H, W, i, o, e);
		//                } else {
		//                    j.fnViewTaskInDefaultView(i, o, e);
		//                }
		//            }.bind(this, this._taskSwitchCount)).fail(function (N) {
		//                if (N !== this._taskSwitchCount) {
		//                    c.warning("isNavigationSupported(fail): task switched while waiting!");
		//                    return;
		//                }
		//                j.fnViewTaskInDefaultView(i, o, e);
		//            }.bind(this, this._taskSwitchCount));
		//        } else {
		//            this.fnViewTaskInDefaultView(i, o, e);
		//        }
		//    },
		//    fnHandleIntentNavigation: function (o, e, i, j, G) {
		//        o.params.openMode = e;
		//        switch (e) {
		//        case "embedIntoDetails":
		//        case "genericEmbedIntoDetails":
		//        case "embedIntoDetailsNestedRouter":
		//            this.fnRenderIntentBasedApp(o, e, i, j, G);
		//            break;
		//        case "replaceDetails":
		//        case "external":
		//            this.oEmbedModeIntentParams = {};
		//            this.oEmbedModeIntentParams[j.sSAP__Origin + "_" + j.sInstanceID] = q.extend({ "OpenInEmbedMode": e === "replaceDetails" }, o);
		//            this.fnViewTaskInDefaultView(i, j, G);
		//            break;
		//        default:
		//        }
		//    },
		//    fnRenderIntentBasedApp: function (o, e, i, j, G) {
		//        var N = o.semanticObject + "-" + o.action;
		//        var H = "#" + N;
		//        this.embedFioriElements = o.params.openMode === "embedIntoDetailsNestedRouter" ? true : false;
		//        this.showHideSideContent();
		//        var I = this.byId("genericComponentContainer");
		//        var K = I && I.getComponent() ? I.getComponent() : null;
		//        if (K) {
		//            var Q = this.oComponentCache.getComponentById(K) || null;
		//            if (!Q) {
		//                var W = sap.ui.getCore().getComponent(K);
		//                if (W) {
		//                    W.destroy();
		//                }
		//            }
		//        }
		//        var Y = this._getCrossNavigationService();
		//        var Z = {
		//            startupParameters: {
		//                taskModel: this.fnGetTaskModelClone(j),
		//                queryParameters: o.params,
		//                inboxAPI: this.getInboxAPI(),
		//                inboxInternal: { updateTaskList: this.updateTaskList.bind(this) }
		//            },
		//            inboxAPI: this.getInboxAPI(),
		//            onTaskUpdate: this.fnDelegateTaskRefresh.bind(this)
		//        };
		//        var $ = N + "-" + this.routeName;
		//        var _ = this.oRouter.getTargets();
		//        var a1 = _.getTarget($);
		//        if (this.embedFioriElements && a1) {
		//            this.oModel2.setProperty("/embedFioriElements", true);
		//            this.oModel2.setProperty("/showGenericComponent", false);
		//            this.oModel2.setProperty("/showDefaultView", false);
		//            this.getComponentViaRoutingTarget($, null, { componentData: Z }, o.params, i, j, G);
		//            this.fnGetTabCountersForSelectedTask(i, j, G);
		//        } else if (this.embedFioriElements) {
		//            var b1 = "?" + this.fnCreateURLParameters(o.params);
		//            Y.createComponentData(H + b1).then(function (c1, d1, e1) {
		//                if (this.embedFioriElements && $ === c1) {
		//                    this.oModel2.setProperty("/embedFioriElements", true);
		//                    this.oModel2.setProperty("/showGenericComponent", false);
		//                    this.oModel2.setProperty("/showDefaultView", false);
		//                    var f1 = Object.assign(Z, e1.componentData);
		//                    var g1 = Object.assign({ componentData: f1 }, e1.appPropertiesSafe.applicationDependencies);
		//                    this.getComponentViaRoutingTarget(c1, e1.componentProperties.name, g1, d1, i, j, G);
		//                    this.fnGetTabCountersForSelectedTask(i, j, G);
		//                }
		//            }.bind(this, $, JSON.parse(JSON.stringify(o.params)))).catch(function (c1, d1) {
		//                if (c1 !== this._taskSwitchCount) {
		//                    c.warning("createComponentData(fail): task switched while waiting!");
		//                    return;
		//                }
		//                c.error(d1);
		//                this.fnViewTaskInDefaultView(i, j, G);
		//            }.bind(this, this._taskSwitchCount));
		//        } else if (!this.embedFioriElements) {
		//            var b1 = "?" + this.fnCreateURLParameters(o.params);
		//            Y.createComponentInstance(H + b1, { componentData: Z }, this.getOwnerComponent()).done(function (c1, d1) {
		//                if (c1 !== this._taskSwitchCount) {
		//                    c.warning("createComponentInstance: task switched while waiting!");
		//                    return;
		//                }
		//                this.oModel2.setProperty("/embedFioriElements", false);
		//                this.oModel2.setProperty("/showGenericComponent", true);
		//                this.oModel2.setProperty("/showDefaultView", false);
		//                this.embedFioriElements = false;
		//                this.showHideSideContent();
		//                this.byId("genericComponentContainer").setComponent(d1);
		//                if (e === "genericEmbedIntoDetails") {
		//                    this.setShowFooter(false);
		//                } else if (e === "embedIntoDetails") {
		//                    this.loadDecisionOptions(i, j, "decisionOptions");
		//                }
		//            }.bind(this, this._taskSwitchCount)).fail(function (c1, d1) {
		//                if (c1 !== this._taskSwitchCount) {
		//                    c.warning("createComponentInstance(fail): task switched while waiting!");
		//                    return;
		//                }
		//                if (e === "genericEmbedIntoDetails") {
		//                    this.setShowFooter(false);
		//                }
		//                c.error(d1);
		//                this.fnViewTaskInDefaultView(i, j, G);
		//            }.bind(this, this._taskSwitchCount));
		//        }
		//    },
		//    updateTask: function (e, i) {
		//        var o = new q.Deferred();
		//        var j = this;
		//        if (!e || !i) {
		//            o.reject("Input parameters SAP__Origin and TaskInstanceId are mandatory");
		//            return o.promise();
		//        }
		//        var G = function (I) {
		//            o.resolve();
		//            var K = j.i18nBundle.getText("dialog.success.complete");
		//            if (j._getStandaloneDetailDeep() && !j.oDataManager.getTableView() && !(typeof j.getView().getParent().getParent().isMasterShown === "function" && j.getView().getParent().getParent().isMasterShown())) {
		//                j.getView().getModel().sDetailDeepEmptyMessage = K + ". " + j.i18nBundle.getText("detailDeepEmptyView.closingTabMessage");
		//                a.show(K, {
		//                    duration: 1000,
		//                    onClose: j.oRouter.navTo.bind(j.oRouter, "detail_deep_empty", null, false)
		//                });
		//                return;
		//            } else {
		//                a.show(K);
		//            }
		//            if (j.bIsTableViewActive) {
		//                j.fnNavBackToTableVw();
		//            }
		//            if (D.system.phone) {
		//                j.fnOnNavBackInMobile();
		//            }
		//        };
		//        var H = function (I) {
		//            o.reject(I.message);
		//        };
		//        this.oDataManager.fnUpdateSingleTask(e, i, G, H);
		//        return o.promise();
		//    },
		//    updateTaskList: function () {
		//        this.getOwnerComponent().getEventBus().publish("cross.fnd.fiori.inbox", "refreshListInternal");
		//    },
		//    getDescription: function (e, i) {
		//        var o = new q.Deferred();
		//        if (!e || !i) {
		//            o.reject("Input parameters SAP__Origin and TaskInstanceId are mandatory");
		//            return o.promise();
		//        }
		//        var j = function (H) {
		//            o.resolve(H);
		//        };
		//        var G = function (H) {
		//            o.reject(H.message);
		//        };
		//        this.oDataManager.readDescription(e, i, j, G);
		//        return o.promise();
		//    },
		//    _setExtensionState: function (e) {
		//        if (e) {
		//            this._isExtended = true;
		//        } else {
		//            this._isExtended = false;
		//        }
		//    },
		//    _getExtensionState: function () {
		//        if (this._isExtended) {
		//            return true;
		//        } else {
		//            return false;
		//        }
		//    },
		//    isMainScreen: function () {
		//        if (this._getExtensionState()) {
		//            return false;
		//        } else {
		//            if (this._oControlStore.oBackButton) {
		//                return false;
		//            }
		//            return "X";
		//        }
		//    },
		//    setShowFooterAPI: function (e, i) {
		//        if (e !== this._taskSwitchCount) {
		//            c.warning("s3.controller.setShowFooterAPI: task switched while waiting!");
		//        } else {
		//            this.setShowFooter(i);
		//        }
		//    },
		//    setShowFooter: function (e) {
		//        if (e) {
		//            this.oHeaderFooterOptions = q.extend(this.oHeaderFooterOptions, this._oPreviousHeaderFooterOptions);
		//            this.refreshHeaderFooterOptions();
		//            this._setExtensionState(false);
		//        } else {
		//            this._setExtensionState(true);
		//            this._oPreviousHeaderFooterOptions = q.extend({}, this.oHeaderFooterOptions);
		//            this.oHeaderFooterOptions = q.extend(this.oHeaderFooterOptions, {
		//                oPositiveAction: null,
		//                oNegativeAction: null,
		//                buttonList: null,
		//                oJamOptions: null,
		//                oEmailSettings: null,
		//                bSuppressBookmarkButton: true
		//            });
		//            this.refreshHeaderFooterOptions();
		//            if (this.getView().getContent()[0].getShowFooter()) {
		//                c.error("Hiding footer failed");
		//            }
		//        }
		//    },
		//    setShowNavButtonAPI: function (e, i, j) {
		//        if (e !== this._taskSwitchCount) {
		//            c.warning("s3.controller.setShowNavButtonAPI: task switched while waiting!");
		//        } else {
		//            this.setShowNavButton(i, j);
		//        }
		//    },
		//    setShowNavButton: function (e, i) {
		//        if (e) {
		//            if (i) {
		//                this._backButtonHandler = i;
		//            } else {
		//                this._backButtonHandler = this.onNavButtonPress.bind(this);
		//            }
		//        } else {
		//            this._backButtonHandler = null;
		//        }
		//        this.oHeaderFooterOptions = q.extend(this.oHeaderFooterOptions, { onBack: this._backButtonHandler });
		//        this.refreshHeaderFooterOptions();
		//    },
		//    onNavButtonPress: function (e) {
		//        if (window.history.length > 0) {
		//            window.history.back();
		//        } else {
		//            c.error("Navigation history does not exist. Ensure that navigation history is maintained or provide custom event handler for back navigation button through setShowNavButton API");
		//        }
		//    },
		//    fnGetTaskModelClone: function (o) {
		//        var e = this.getView();
		//        var i = new C(e.getModel(), o.sCtxPath);
		//        var I = q.extend(true, {}, e.getModel().getData(i.getPath(), i));
		//        return this.fnCloneTaskModel(I);
		//    },
		//    fnCreateURLParameters: function (e) {
		//        return Object.keys(e).map(function (i) {
		//            return [
		//                i,
		//                e[i]
		//            ].map(encodeURIComponent).join("=");
		//        }).join("&");
		//    },
		//    fnValidateDecisionOptionsAndCreatButtons: function (i, e, j, o) {
		//        e = e ? e : [];
		//        if (i) {
		//            this.createDecisionButtons(e, j, o);
		//        } else {
		//            this.createDecisionButtons(e, {}, o);
		//        }
		//    },
		//    fnDelegateTaskRefresh: function () {
		//        var N = this.oRoutingParameters;
		//        var e = N.SAP__Origin;
		//        var i = N.InstanceID;
		//        if (N && e && i) {
		//            this.oDataManager.fnUpdateSingleTask(e, i);
		//        }
		//    },
		//    fnNavigateToApp: function (o, e) {
		//        if (!e) {
		//            this._getCrossNavigationService().toExternal({
		//                target: {
		//                    semanticObject: o.semanticObject,
		//                    action: o.action
		//                },
		//                params: o.params,
		//                appSpecificRoute: o.appSpecificRoute
		//            });
		//        } else {
		//            var i = o.params.openMode;
		//            this.fnEmbedApplicationInDetailView(o, i);
		//        }
		//    },
		//    fnViewTaskInDefaultView: function (i, o, e) {
		//        this.oModel2.setProperty("/showGenericComponent", false);
		//        this.oModel2.setProperty("/embedFioriElements", false);
		//        this.oModel2.setProperty("/showDefaultView", true);
		//        this.embedFioriElements = false;
		//        this.showHideSideContent();
		//        this.fnGetDetailsForSelectedTask(i, o, e);
		//    },
		//    fnGetTabCountersForSelectedTask: function (i, o, e) {
		//        var j = [];
		//        var I = this.oModel2.getData();
		//        var G = [];
		//        var H = I.UIExecutionLink;
		//        if (!H.GUI_Link) {
		//            H.GUI_Link = "";
		//        }
		//        if (this.fnFormatterSupportsProperty(I.TaskSupports.Comments, I.SupportsComments)) {
		//            G.push("Comments");
		//        }
		//        if (this.fnFormatterSupportsProperty(I.TaskSupports.Attachments, I.SupportsAttachments)) {
		//            G.push("Attachments");
		//        }
		//        if (I.TaskSupports.TaskObject && this.oDataManager.bShowTaskObjects) {
		//            G.push("TaskObjects");
		//        }
		//        this.oDataManager.readDataOnTaskSelection(o.sCtxPath, j, G, o.sSAP__Origin, o.sInstanceID, I.TaskDefinitionID, i, function (K, N, Q, W, Y) {
		//            if (K !== this._taskSwitchCount) {
		//                return;
		//            }
		//            if (W.sCommentsCount != null && W.sCommentsCount !== "") {
		//                this.oModel2.setProperty("/CommentsCount", W.sCommentsCount);
		//            }
		//            if (W.sAttachmentsCount != null && W.sAttachmentsCount !== "") {
		//                this.oModel2.setProperty("/AttachmentsCount", W.sAttachmentsCount);
		//            }
		//            if (W.sTaskObjectsCount != null && W.sTaskObjectsCount !== "") {
		//                this.oModel2.setProperty("/ObjectLinksCount", W.sTaskObjectsCount);
		//                this.fnHandleNoTextCreation("ObjectLinks");
		//            }
		//            N.UIExecutionLink = H;
		//            this.fnValidateDecisionOptionsAndCreatButtons(i.TaskSupports.UIExecutionLink, Y, i.UIExecutionLink, o.sSAP__Origin);
		//            e.call(this, N, Q);
		//        }.bind(this, this._taskSwitchCount));
		//    },
		//    fnGetDetailsForSelectedTask: function (i, o, e) {
		//        var j = this;
		//        var G = j.oModel2.getData().TaskSupports;
		//        var I = G && G.UIExecutionLink ? G.UIExecutionLink : false;
		//        j.fnParseComponentParameters(I ? i.UIExecutionLink.GUI_Link : "");
		//        var H = [];
		//        if (G && G.Description) {
		//            H.push("Description");
		//        }
		//        if (!this._getShowAdditionalAttributes() && G && G.CustomAttributeData) {
		//            H.push("CustomAttributeData");
		//        }
		//        if (this.extHookGetEntitySetsToExpand) {
		//            var K = this.extHookGetEntitySetsToExpand();
		//            H.push.apply(H, K);
		//        }
		//        if (!i.UIExecutionLink.GUI_Link) {
		//            i.UIExecutionLink.GUI_Link = "";
		//        }
		//        var N = j.oModel2.getData();
		//        if (!j.isGenericComponentRendered) {
		//            var Q = [];
		//            if (this.fnFormatterSupportsProperty(N.TaskSupports.Comments, N.SupportsComments)) {
		//                Q.push("Comments");
		//            }
		//            if (this.fnFormatterSupportsProperty(N.TaskSupports.Attachments, N.SupportsAttachments)) {
		//                Q.push("Attachments");
		//            }
		//            if (N.TaskSupports.TaskObject && this.oDataManager.bShowTaskObjects) {
		//                Q.push("TaskObjects");
		//            }
		//            j.oDataManager.readDataOnTaskSelection(o.sCtxPath, H, Q, o.sSAP__Origin, o.sInstanceID, N.TaskDefinitionID, i, function (Y, Z, $, _, a1) {
		//                if (Y !== this._taskSwitchCount) {
		//                    c.warning("readDataOnTaskSelection: task switched while waiting!");
		//                    return;
		//                }
		//                if (_.sCommentsCount !== null && _.sCommentsCount !== "") {
		//                    j.oModel2.setProperty("/CommentsCount", _.sCommentsCount);
		//                }
		//                if (_.sAttachmentsCount !== null && _.sAttachmentsCount !== "") {
		//                    j.oModel2.setProperty("/AttachmentsCount", _.sAttachmentsCount);
		//                }
		//                if (_.sTaskObjectsCount !== null && _.sTaskObjectsCount !== "") {
		//                    j.oModel2.setProperty("/ObjectLinksCount", _.sTaskObjectsCount);
		//                    j.fnHandleNoTextCreation("ObjectLinks");
		//                }
		//                j.fnValidateDecisionOptionsAndCreatButtons(i.TaskSupports.UIExecutionLink, a1, i.UIExecutionLink, o.sSAP__Origin);
		//                Z.UIExecutionLink = i.UIExecutionLink;
		//                e.call(j, Z, $);
		//            }.bind(this, this._taskSwitchCount));
		//        } else {
		//            var W = "GenericComponentRendered";
		//            j.oDataManager.setDetailPageLoaded(true);
		//            if (j.byId("attachmentComponent") || j.byId("attachmentComponentInDetails")) {
		//                j.fnCountUpdater("Attachments", j.oModel2.getData().SAP__Origin, j.oModel2.getData().InstanceID, W);
		//            }
		//            if (j.byId("commentsContainer") || j.byId("commentsContainerInDetails")) {
		//                j.fnCountUpdater("Comments", j.oModel2.getData().SAP__Origin, j.oModel2.getData().InstanceID, W);
		//            }
		//            if (j._getObjectLinksList()) {
		//                j.fnCountUpdater("ObjectLinks", j.oModel2.getData().SAP__Origin, j.oModel2.getData().InstanceID, W);
		//            }
		//            this.loadDecisionOptions(i, o, W);
		//        }
		//    },
		//    clearCustomAttributes: function () {
		//        if (this.aCA.length > 0) {
		//            for (var i = 0; i < this.aCA.length; i++) {
		//                this.aCA[i].destroy();
		//            }
		//            this.aCA = [];
		//        }
		//    },
		//    onAttachmentChange: function (e) {
		//        var o = e.getSource();
		//        var i = e.getParameters().getParameters().files[0].name;
		//        if (o.getHeaderParameters()) {
		//            o.destroyHeaderParameters();
		//        }
		//        var j = i.lastIndexOf(".");
		//        var G = "";
		//        if (j != -1) {
		//            G = i.substr(j + 1);
		//            i = i.substr(0, j);
		//        }
		//        o.addHeaderParameter(new U({
		//            name: "x-csrf-token",
		//            value: this.getXsrfToken()
		//        }));
		//        o.addHeaderParameter(new U({
		//            name: "slug",
		//            value: encodeURIComponent(i)
		//        }));
		//        o.addParameter(new U({
		//            name: "x-csrf-token",
		//            value: this.getXsrfToken()
		//        }));
		//        o.addParameter(new U({
		//            name: "slug",
		//            value: i
		//        }));
		//        o.addHeaderParameter(new U({
		//            name: "Accept",
		//            value: "application/json"
		//        }));
		//        o.addParameter(new U({
		//            name: "Accept",
		//            value: "application/json"
		//        }));
		//        if (G !== "") {
		//            o.addHeaderParameter(new U({
		//                name: "extension",
		//                value: G
		//            }));
		//            o.addParameter(new U({
		//                name: "extension",
		//                value: G
		//            }));
		//        }
		//    },
		//    onAttachmentUploadComplete: function (e) {
		//        var i = this.oModel2.getData();
		//        var j = this;
		//        j.oEventSource = e.getSource();
		//        var o = function () {
		//            this.oEventSource.updateAggregation("items");
		//            this.oEventSource.rerender();
		//        };
		//        if (e.getParameters().getParameters().status == 201) {
		//            var G = JSON.parse(e.getParameters().files[0].responseRaw).d;
		//            if (i.Attachments && i.Attachments.results) {
		//                i.Attachments.results.unshift(G);
		//            } else {
		//                i.Attachments = { results: [G] };
		//            }
		//            i.AttachmentsCount = i.Attachments.results.length;
		//            this._updateDetailModel(i);
		//            j.fnHandleAttachmentsCountText("Attachments");
		//            a.show(this.i18nBundle.getText("dialog.success.attachmentUpload"));
		//        } else {
		//            var H = this.i18nBundle.getText("dialog.error.attachmentUpload");
		//            M.error(H, { onClose: o.bind(j) });
		//        }
		//    },
		//    onAttachmentDeleted: function (e) {
		//        var j = this;
		//        var o = e.getParameters().documentId;
		//        var I = this.oModel2.getData();
		//        var G = this._getUploadCollectionControl();
		//        this._setBusyIncdicatorOnDetailControls(G, true);
		//        this.oDataManager.deleteAttachment(I.SAP__Origin, I.InstanceID, o, function () {
		//            var H = I.Attachments.results;
		//            q.each(H, function (i, K) {
		//                if (K.ID === o) {
		//                    H.splice(i, 1);
		//                    return false;
		//                }
		//            });
		//            I.Attachments.results = H;
		//            I.AttachmentsCount = H.length;
		//            if (I.AttachmentsCount === 0) {
		//                G.setNoDataText(this.i18nBundle.getText("view.Attachments.noAttachments"));
		//            }
		//            this._setBusyIncdicatorOnDetailControls(G, false);
		//            this._updateDetailModel(I);
		//            j.fnHandleAttachmentsCountText("Attachments");
		//            a.show(this.i18nBundle.getText("dialog.success.attachmentDeleted"));
		//        }.bind(this), function (i) {
		//            this._setBusyIncdicatorOnDetailControls(G, false);
		//            var H = this.i18nBundle.getText("dialog.error.attachmentDelete");
		//            M.error(H);
		//        }.bind(this));
		//    },
		//    getXsrfToken: function () {
		//        var i = this.getView().getModel().getHeaders()["x-csrf-token"];
		//        if (!i) {
		//            this.getView().getModel().refreshSecurityToken(function (e, o) {
		//                i = o.headers["x-csrf-token"];
		//            }, function () {
		//                M.error("Could not get XSRF token");
		//            }, false);
		//        }
		//        return i;
		//    },
		//    onFileUploadFailed: function (e) {
		//        var i = this.i18nBundle.getText("dialog.error.attachmentUpload");
		//        M.error(i, { details: v.fnRemoveHtmlTags(e.getParameters().exception) });
		//    },
		//    addShareOnJamAndEmail: function (o) {
		//        var j = { fGetShareSettings: this.getJamSettings.bind(this) };
		//        var e = {
		//            sSubject: this.getMailSubject(),
		//            fGetMailBody: this.getMailBody.bind(this)
		//        };
		//        o.oJamOptions = j;
		//        o.oEmailSettings = e;
		//        this.oHeaderFooterOptions = q.extend(this.oHeaderFooterOptions, {
		//            oJamOptions: o.oJamOptions,
		//            oEmailSettings: o.oEmailSettings
		//        });
		//    },
		//    _getDescriptionForShare: function (e) {
		//        var o = this.oModel2.getData();
		//        var i = "\n\n" + this.i18nBundle.getText("share.email.body.detailsOfTheItem") + "\n\n";
		//        var j = x.getDateInstance();
		//        if (o.TaskTitle && o.TaskTitle.trim() !== "") {
		//            i += this.i18nBundle.getText("item.taskTitle", o.TaskTitle.trim()) + "\n";
		//        }
		//        if (o.Priority && o.Priority !== "") {
		//            i += this.i18nBundle.getText("item.priority", p.formatterPriority.call(this.getView(), o.SAP__Origin, o.Priority)) + "\n";
		//        }
		//        if (o.CompletionDeadLine) {
		//            i += this.i18nBundle.getText("item.dueDate", j.format(o.CompletionDeadLine, true)) + "\n";
		//        }
		//        if (e && e.trim() !== "") {
		//            i += this.i18nBundle.getText("item.description", e) + "\n";
		//        } else if (o.Description && o.Description.Description && o.Description.Description.trim() !== "") {
		//            i += this.i18nBundle.getText("item.description", this._getTrimmedString(o.Description.Description)) + "\n";
		//        }
		//        var G = o.CreatedByName;
		//        if (!G || G.trim() === "") {
		//            G = o.CreatedBy;
		//        }
		//        if (G && G.trim() !== "") {
		//            i += this.i18nBundle.getText("item.createdBy", G) + "\n";
		//        }
		//        if (o.CreatedOn) {
		//            i += this.i18nBundle.getText("item.createdOn", j.format(o.CreatedOn, true)) + "\n";
		//        }
		//        if (o.CompletedOn) {
		//            i += this.i18nBundle.getText("item.completedOn", j.format(o.CompletedOn, true)) + "\n";
		//        }
		//        return i;
		//    },
		//    _getDescriptionForShareInMail: function (e) {
		//        var i = this._getDescriptionForShare(e);
		//        i += this.i18nBundle.getText("share.email.body.link", window.location.href.split("(").join("%28").split(")").join("%29").split(",").join("%2C")) + "\n";
		//        return i;
		//    },
		//    getJamSettings: function () {
		//        return {
		//            object: {
		//                id: window.location.href,
		//                share: this.getJamDescription()
		//            }
		//        };
		//    },
		//    getJamDescription: function () {
		//        var e = this._getDescriptionForShare();
		//        return e;
		//    },
		//    getMailSubject: function () {
		//        var o = this.oModel2.getData();
		//        var e = p.formatterPriority.call(this.getView(), o.SAP__Origin, o.Priority);
		//        var i = o.CreatedByName;
		//        var j = o.TaskTitle;
		//        return p.formatterMailSubject.call(this, e, i, j);
		//    },
		//    getMailBody: function () {
		//        if (D.browser.msie) {
		//            return window.location.href.split("(").join("%28").split(")").join("%29").split(",").join("%2C");
		//        }
		//        var e = this._getDescriptionForShareInMail();
		//        var i = this.getMailSubject();
		//        var j = sap.m.URLHelper.normalizeEmail(null, i, e);
		//        if (j.length > 2000) {
		//            var o = this.oModel2.getData();
		//            var G = this._getDescriptionForShareInMail("...");
		//            var H = sap.m.URLHelper.normalizeEmail(null, i, G);
		//            var I = 2000 - H.length;
		//            var K = "";
		//            if (o.Description && o.Description.Description) {
		//                K = window.encodeURIComponent(this._getTrimmedString(o.Description.Description));
		//            }
		//            K = K.substring(0, I);
		//            var N = false;
		//            while (!N || K.length == 0) {
		//                N = true;
		//                try {
		//                    K = window.decodeURIComponent(K);
		//                } catch (Q) {
		//                    K = K.substring(0, K.length - 1);
		//                    N = false;
		//                }
		//            }
		//            K = K.substring(0, K.length - 3) + "...";
		//            var W = this._getDescriptionForShareInMail(K);
		//            return W;
		//        }
		//        return e;
		//    },
		//    _getIntentParam: function (o) {
		//        var e = [];
		//        for (var i = 0; i < this.OPEN_MODES.length; i++) {
		//            e.push({
		//                target: {
		//                    semanticObject: o.semanticObject,
		//                    action: o.action
		//                },
		//                params: q.extend({}, o.params, { "openMode": this.OPEN_MODES[i] })
		//            });
		//        }
		//        return e;
		//    },
		//    _getIntentWithOutParam: function (o) {
		//        var e = [{
		//                target: {
		//                    semanticObject: o.semanticObject,
		//                    action: o.action
		//                },
		//                params: o.params
		//            }];
		//        return e;
		//    },
		//    _getTrimmedString: function (e) {
		//        return e.replace(/\s+/g, " ").trim();
		//    },
		//    _handleItemRemoved: function (e) {
		//        if (D.system.phone && !this.getView().getParent().getParent().isMasterShown()) {
		//            if (!this.stayOnDetailScreen) {
		//                this.oRouter.navTo("master", {}, D.system.phone);
		//                window.history.back();
		//            } else {
		//                var o = {
		//                    sCtxPath: this.getView().getBindingContext().getPath(),
		//                    sInstanceID: this.oModel2.getData().InstanceID,
		//                    sSAP__Origin: this.oModel2.getData().SAP__Origin,
		//                    bCommentCreated: true
		//                };
		//                this.refreshData(o);
		//                this.stayOnDetailScreen = false;
		//            }
		//        }
		//    },
		//    _handleDetailRefresh: function (e) {
		//        var o;
		//        var i = e.getParameter("bIsTableViewActive");
		//        var j = this.getView();
		//        if (i || D.system.phone || this._getStandaloneDetailDeep() && !this.oDataManager.getTableView() && !(typeof this.getView().getParent().getParent().isMasterShown === "function" && this.getView().getParent().getParent().isMasterShown())) {
		//            var I = q.extend(true, {}, j.getModel().getData(this.oContext.getPath(), this.oContext));
		//            if (q.isEmptyObject(I)) {
		//                I = q.extend(true, {}, j.getModel().getData(encodeURI(this.oContext.getPath()), this.oContext));
		//            }
		//            var G = e.getParameter("sAction");
		//            var H = e.getParameter("sStatus");
		//            if (I.Status === "COMPLETED" || I.Status === "FOR_RESUBMISSION" || G && G === "FORWARD" && (H && H === "Success")) {
		//                if (this._getStandaloneDetailDeep() && !this.oDataManager.getTableView() && !(typeof this.getView().getParent().getParent().isMasterShown === "function" && this.getView().getParent().getParent().isMasterShown())) {
		//                    j.getModel().bCheckPassed = true;
		//                    return;
		//                }
		//                if (i) {
		//                    this.fnNavBackToTableVw();
		//                } else {
		//                    this.fnOnNavBackInMobile();
		//                }
		//            } else if (this.isGenericComponentRendered) {
		//                o = {
		//                    sCtxPath: this.getView().getBindingContext().getPath(),
		//                    sInstanceID: this.oModel2.getData().InstanceID,
		//                    sSAP__Origin: this.oModel2.getData().SAP__Origin,
		//                    bCommentCreated: true
		//                };
		//                this.refreshData(o);
		//            } else {
		//                if (I.TaskSupports && I.TaskSupports.CustomAttributeData) {
		//                    I = this._processCustomAttributesData(I);
		//                }
		//                this._updateDetailModel(I, true);
		//                var K = this.oDataManager.getDataFromCache("DecisionOptions", I);
		//                K = K ? K : [];
		//                var N = this.oDataManager.getDataFromCache("UIExecutionLink", I);
		//                N = N ? N : {};
		//                var Q = I.TaskSupports.UIExecutionLink;
		//                N = Q ? N : {};
		//                this.oHeaderFooterOptions.buttonList = [];
		//                this.createDecisionButtons(K, N, this.oModel2.getData().SAP__Origin);
		//            }
		//        } else {
		//            o = {
		//                sCtxPath: this.getView().getBindingContext().getPath(),
		//                sInstanceID: this.oModel2.getData().InstanceID,
		//                sSAP__Origin: this.oModel2.getData().SAP__Origin,
		//                bCommentCreated: true
		//            };
		//            this.refreshData(o);
		//        }
		//    },
		//    _updateHeaderTitle: function (o) {
		//        if (o) {
		//            var e;
		//            if (this._getTaskTitleInHeader()) {
		//                e = this._getShowAdditionalAttributes() ? p.formatterTaskTitle.call(this.getView(), o.TaskTitle, o.CustomAttributeData) : o.TaskTitle;
		//            } else {
		//                e = o.TaskDefinitionName;
		//            }
		//            if (!e) {
		//                e = this.i18nBundle.getText("ITEM_DETAIL_DISPLAY_NAME");
		//            }
		//            this.oHeaderFooterOptions = q.extend(this.oHeaderFooterOptions, { sDetailTitle: e });
		//            this.refreshHeaderFooterOptions();
		//        }
		//    },
		//    _isTaskConfirmable: function (i) {
		//        if (i.Status === "EXECUTED") {
		//            return true;
		//        } else {
		//            return false;
		//        }
		//    },
		createDecisionButtons: function(e, o, j) {
			var G = null;
			var N = null;
			var H = [];
			if (this.oHeaderFooterOptions) {
				G = this.oHeaderFooterOptions.oPositiveAction;
				N = this.oHeaderFooterOptions.oNegativeAction;
			}
			var I = 1;
			var K = 0;
			var Q = this;
			var W = this.oModel2.getData(),
				Y = Q._getActionHelper();
			var Z = false;
			var $ = false;
			var _ = this._getParsedParamsForIntent(o.GUI_Link);
			var a1 = this._getCrossNavigationService();
			if (_ && a1) {
				var b1 = this._getIntentParam(_);
			}
			if (!this.switchToOutbox() && W.Status !== "COMPLETED" && W.Status !== "FOR_RESUBMISSION") {
				if (!this._isTaskConfirmable(W)) {
					for (var i = 0; i < e.length; i++) {
						var c1 = e[i];
						c1.InstanceID = W.InstanceID;
						c1.SAP__Origin = j;
						if (!c1.Nature) {
							K = 400 + I;
							I++;
						} else if (c1.Nature.toUpperCase() === "POSITIVE") {
							K = I;
							I++;
						} else if (c1.Nature.toUpperCase() === "NEGATIVE") {
							K = 200 + I;
							I++;
						} else {
							K = 400 + I;
							I++;
						}
						H.push({
							iDisplayOrderPriority: K,
							nature: c1.Nature,
							sBtnTxt: c1.DecisionText,
							onBtnPressed: function(g1) {
								return function() {
									Q.showDecisionDialog(Q.oDataManager.FUNCTION_IMPORT_DECISION, g1, true);
								};
							}(c1)
						});
					}
				} else {
					K = I;
					I++;
					G = {
						iDisplayOrderPriority: K,
						sI18nBtnTxt: "XBUT_CONFIRM",
						onBtnPressed: function(g1) {
							return function() {
								Q.showConfirmationDialog(Q.oDataManager.FUNCTION_IMPORT_CONFIRM, W);
							};
						}(W)
					};
				}
				if ((W.TaskSupports.ProcessingLogs || W.TaskSupports.WorkflowLog) && Q.oDataManager.getShowLogEnabled()) {
					K = 1200 + I;
					I++;
					H.push({
						sId: "LogButtonID",
						iDisplayOrderPriority: K,
						sI18nBtnTxt: Q.bShowLogs ? "XBUT_HIDELOG" : "XBUT_SHOWLOG",
						onBtnPressed: this.onLogBtnPress.bind(this)
					});
				}
				if (Q.fnFormatterSupportsProperty(W.TaskSupports.Claim, W.SupportsClaim)) {
					K = 1500 + I;
					I++;
					H.push({
						iDisplayOrderPriority: K,
						sI18nBtnTxt: "XBUT_CLAIM",
						onBtnPressed: function(g1) {
							if (D.system.phone) {
								Q.stayOnDetailScreen = true;
							}
							Q.sendAction("Claim", W, null);
						}
					});
				}
				if (Q.fnFormatterSupportsProperty(W.TaskSupports.Release, W.SupportsRelease)) {
					K = 1500 + I;
					I++;
					H.push({
						iDisplayOrderPriority: K,
						sI18nBtnTxt: "XBUT_RELEASE",
						onBtnPressed: function(g1) {
							if (D.system.phone) {
								Q.stayOnDetailScreen = true;
							}
							Q.sendAction("Release", W, null);
						}
					});
				}
				if (Q.fnFormatterSupportsProperty(W.TaskSupports.Forward, W.SupportsForward)) {
					K = 1500 + I;
					I++;
					H.push({
						iDisplayOrderPriority: K,
						sI18nBtnTxt: "XBUT_FORWARD",
						onBtnPressed: this.onForwardPopUp.bind(this)
					});
				}
				if (W.TaskSupports) {
					if (W.TaskSupports.Resubmit) {
						K = 1500 + I;
						I++;
						H.push({
							iDisplayOrderPriority: K,
							sI18nBtnTxt: "XBUT_RESUBMIT",
							onBtnPressed: this.showResubmitPopUp.bind(this)
						});
					}
				}
				if (_ && a1) {
					Z = true;
					a1.isNavigationSupported(b1).done(function(g1) {
						var h1 = Q._getSupportedOpenMode(g1);
						if (Y.isOpenTaskEnabled(W, h1 === "embedIntoDetails" || h1 === "genericEmbedIntoDetails")) {
							K = 1500 + I;
							I++;
							H.push({
								iDisplayOrderPriority: K,
								sI18nBtnTxt: "XBUT_OPEN",
								onBtnPressed: function(i1) {
									Q.checkStatusAndOpenTaskUI();
								}
							});
						}
						if (h1 === "embedIntoDetailsNestedRouter" && Q.taskSupportsCommAttRelObj(W)) {
							K = 1300 + I;
							I++;
							H.push({
								sId: "DetailsButtonID",
								iDisplayOrderPriority: K,
								sI18nBtnTxt: Q.bShowDetails ? "XBUT_HIDEDETAILS" : "XBUT_SHOWDETAILS",
								onBtnPressed: function(i1) {
									Q.onDetailsBtnPress();
								}
							});
						}
						Q.showHideSideContent();
						Q.addEmailAndCallExtentionHookForButtonOptions(H, G, N, W);
					}).fail(function() {
						Q.addEmailAndCallExtentionHookForButtonOptions(H, G, N, W);
						c.error("Error while creating open task buttons");
					});
				} else if (!Q.oDataManager.isUIExecnLinkNavProp() && W.GUI_Link && Y.isOpenTaskEnabled(W, false)) {
					K = 1500 + I;
					I++;
					H.push({
						iDisplayOrderPriority: K,
						sI18nBtnTxt: "XBUT_OPEN",
						onBtnPressed: function(g1) {
							Q.checkStatusAndOpenTaskUI();
						}
					});
				} else if (W.TaskSupports.UIExecutionLink && W.UIExecutionLink && W.UIExecutionLink.GUI_Link && Y.isOpenTaskEnabled(W, false)) {
					K = 1500 + I;
					I++;
					H.push({
						iDisplayOrderPriority: K,
						sI18nBtnTxt: "XBUT_OPEN",
						onBtnPressed: function(g1) {
							Q.checkStatusAndOpenTaskUI();
						}
					});
				}
				// Start of code change by MH_Aarti 10.08.2023 - Defect 8000001901
				// if (window.plugins && window.plugins.calendar) {
				// 	var d1 = this.oModel2.getData();
				// 	var e1 = d1.CompletionDeadLine;
				// 	if (e1) {
				// 		var f1 = function(g1) {
				// 			if (g1 < new Date()) {
				// 				this.oConfirmationDialogManager.showDecisionDialog({
				// 					question: this.i18nBundle.getText("dialog.warning.mq.CalendarEventInThePast"),
				// 					title: this.i18nBundle.getText("dialog.warning.mq.CalendarEventInThePast.title"),
				// 					confirmButtonLabel: this.i18nBundle.getText("XBUT_OK"),
				// 					noteMandatory: false,
				// 					confirmActionHandler: this.createCalendarEvent.bind(this)
				// 				});
				// 			} else {
				// 				this.createCalendarEvent();
				// 			}
				// 		};
				// 		K = 1500 + I;
				// 		I++;
				// 		H.push({
				// 			iDisplayOrderPriority: K,
				// 			sI18nBtnTxt: "XBUT_CALENDAR",
				// 			onBtnPressed: f1.bind(this, e1)
				// 		});
				// 	}
				// }
				// End of code change by MH_Aarti 10.08.2023 - Defect 8000001901
			} else {
				$ = true;
				if ((W.TaskSupports.ProcessingLogs || W.TaskSupports.WorkflowLog) && Q.oDataManager.getShowLogEnabled()) {
					K = 1200 + I;
					I++;
					H.push({
						sId: "LogButtonID",
						iDisplayOrderPriority: K,
						sI18nBtnTxt: Q.bShowLogs ? "XBUT_HIDELOG" : "XBUT_SHOWLOG",
						onBtnPressed: this.onLogBtnPress.bind(this)
					});
				}
				if (W.TaskSupports.CancelResubmission) {
					K = 1500 + I;
					I++;
					H.push({
						iDisplayOrderPriority: K,
						sI18nBtnTxt: "XBUT_RESUME",
						onBtnPressed: function(g1) {
							Q.sendAction("CancelResubmission", W, null);
						}
					});
				}
				if (_ && a1) {
					a1.isNavigationSupported(b1).done(function(g1) {
						var h1 = Q._getSupportedOpenMode(g1);
						if (h1 === "embedIntoDetailsNestedRouter" && Q.taskSupportsCommAttRelObj(W)) {
							K = 1300 + I;
							I++;
							H.push({
								sId: "DetailsButtonID",
								iDisplayOrderPriority: K,
								sI18nBtnTxt: Q.bShowDetails ? "XBUT_HIDEDETAILS" : "XBUT_SHOWDETAILS",
								onBtnPressed: function(i1) {
									Q.onDetailsBtnPress();
								}
							});
							Q.showHideSideContent();
							Q.addEmailAndCallExtentionHookForButtonOptions(H, G, N, W);
						}
					}).fail(function() {
						Q.addEmailAndCallExtentionHookForButtonOptions(H, G, N, W);
						c.error("Error creating details buttons");
					});
				}
			}
			if (!Z || $) {
				if (JSON.stringify(this.oHeaderFooterOptions.buttonList) !== JSON.stringify(H)) {
					H = this.oHeaderFooterOptions.buttonList.concat(H);
				}
				this.addEmailAndCallExtentionHookForButtonOptions(H, G, N, W);
			}
		},
		//    addEmailAndCallExtentionHookForButtonOptions: function (e, o, N, i) {
		//        var j = {};
		//        j.oPositiveAction = o;
		//        j.oNegativeAction = N;
		//        j.aButtonList = e;
		//        if (!this.oDataManager.bOutbox && i.Status !== "COMPLETED" && i.Status !== "FOR_RESUBMISSION") {
		//            this.addShareOnJamAndEmail(j);
		//        }
		//        if (this.extHookChangeFooterButtons) {
		//            this.extHookChangeFooterButtons(j);
		//            o = j.oPositiveAction;
		//            N = j.oNegativeAction;
		//            e = j.aButtonList;
		//        }
		//        this.oHeaderFooterOptions = q.extend(this.oHeaderFooterOptions, {
		//            oPositiveAction: o,
		//            oNegativeAction: N,
		//            buttonList: e,
		//            oJamOptions: j.oJamOptions,
		//            oEmailSettings: j.oEmailSettings,
		//            bSuppressBookmarkButton: true
		//        });
		//        this.refreshHeaderFooterOptions();
		//    },
		//    startForwardFilter: function (o, Q) {
		//        Q = Q.toLowerCase();
		//        var e = o.getBindingContext().getProperty("DisplayName").toLowerCase();
		//        var i = o.getBindingContext().getProperty("Department").toLowerCase();
		//        return e.indexOf(Q) !== -1 || i.indexOf(Q) !== -1;
		//    },
		//    closeForwardPopUp: function (o) {
		//        if (o && o.bConfirmed) {
		//            var i = this.oModel2.getData();
		//            var e = i.SAP__Origin;
		//            var I = i.InstanceID;
		//            this.oDataManager.doForward(e, I, o.oAgentToBeForwarded.UniqueName, o.sNote, function () {
		//                var j = this.i18nBundle.getText("dialog.success.forward", o.oAgentToBeForwarded.DisplayName);
		//                if (this._getStandaloneDetailDeep() && this.getView().getModel().bCheckPassed) {
		//                    this.getView().getModel().sDetailDeepEmptyMessage = j + ". " + this.i18nBundle.getText("detailDeepEmptyView.closingTabMessage");
		//                    a.show(j, {
		//                        duration: 1000,
		//                        onClose: this.oRouter.navTo.bind(this.oRouter, "detail_deep_empty", null, false)
		//                    });
		//                } else {
		//                    a.show(j);
		//                }
		//            }.bind(this));
		//        }
		//    },
		//    onForwardPopUp: function () {
		//        var i = this.oModel2.getData();
		//        var o = i.SAP__Origin;
		//        var I = i.InstanceID;
		//        if (this.oDataManager.userSearch) {
		//            m.open(this.startForwardFilter.bind(this), this.closeForwardPopUp.bind(this));
		//            var H = p.formatterTaskSupportsValue(i.TaskSupports.PotentialOwners, i.HasPotentialOwners);
		//            if (H) {
		//                this.oDataManager.readPotentialOwners(o, I, this._PotentialOwnersSuccess.bind(this));
		//            } else {
		//                this._PotentialOwnersSuccess({ results: [] });
		//            }
		//        } else {
		//            n.open(this.closeForwardPopUp.bind(this));
		//        }
		//    },
		//    _getSupportedOpenMode: function (e) {
		//        var j = [];
		//        for (var i = 0; i < e.length; i++) {
		//            if (e[i].supported) {
		//                j.push(this.OPEN_MODES[i]);
		//            }
		//        }
		//        return j.length === 1 ? j[0] : null;
		//    },
		//    _getParsedParamsForIntent: function (e) {
		//        var o = null;
		//        this.oURLParsingService = this.oURLParsingService || sap.ushell && sap.ushell.Container && sap.ushell.Container.getService && sap.ushell.Container.getService("URLParsing");
		//        if (this.oURLParsingService && this.oURLParsingService.isIntentUrl(e)) {
		//            o = this.oURLParsingService.parseShellHash(e);
		//        }
		//        return o;
		//    },
		//    _getCrossNavigationService: function () {
		//        if (!this.oCrossNavigationService) {
		//            if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
		//                this.oCrossNavigationService = sap.ushell.Container.getService("CrossApplicationNavigation");
		//            }
		//        }
		//        return this.oCrossNavigationService;
		//    },
		//    _PotentialOwnersSuccess: function (o) {
		//        m.setAgents(o.results);
		//        m.setOrigin(this.oModel2.getData().SAP__Origin);
		//    },
		//    showResubmitPopUp: function () {
		//        s.open(this.sResubmitUniqueId, this, this.getView());
		//    },
		//    handleResubmitPopOverOk: function (e) {
		//        var i = this.oModel2.getData();
		//        var o = i.SAP__Origin;
		//        var I = i.InstanceID;
		//        var j = F.byId(this.sResubmitUniqueId, "DATE_RESUBMIT");
		//        var G = j.getSelectedDates();
		//        if (G.length > 0) {
		//            var H = G[0].getStartDate();
		//            var K = x.getDateInstance({ pattern: "yyyy-MM-ddTHH:mm:ss" });
		//            this.oDataManager.doResubmit(o, I, "datetime'" + K.format(H) + "'", function () {
		//                var N = this.i18nBundle.getText("dialog.success.resubmit");
		//                if (this._getStandaloneDetailDeep() && this.getView().getModel().bCheckPassed) {
		//                    this.getView().getModel().sDetailDeepEmptyMessage = N + ". " + this.i18nBundle.getText("detailDeepEmptyView.closingTabMessage");
		//                    a.show(N, {
		//                        duration: 1000,
		//                        onClose: this.oRouter.navTo.bind(this.oRouter, "detail_deep_empty", null, false)
		//                    });
		//                } else {
		//                    a.show(N);
		//                }
		//            }.bind(this));
		//            s.close();
		//        }
		//    },
		//    showEmployeeCard: function (o, e, i) {
		//        this._setBusyIncdicatorOnDetailControls(this.getView(), true);
		//        this.oDataManager.readUserInfo(o, e, function (j) {
		//            this._setBusyIncdicatorOnDetailControls(this.getView(), false);
		//            E.displayEmployeeCard(i, j);
		//        }.bind(this), function (j) {
		//            this._setBusyIncdicatorOnDetailControls(this.getView(), false);
		//        }.bind(this), true);
		//    },
		//    onEmployeeLaunchTask: function (e) {
		//        var i = this.oModel2.getData();
		//        this.showEmployeeCard(i.SAP__Origin, i.CreatedBy, p.getSelectedControl(e));
		//    },
		//    onEmployeeLaunchCommentSender: function (e, i, o) {
		//        this.showEmployeeCard(this.oModel2.getData().SAP__Origin, o.getSource().getBindingContext("detail").getProperty("CreatedBy"), p.getSelectedControl(o));
		//    },
		//    handleLogNavigation: function (e) {
		//        var o = e.getSource().getBindingContext("detail");
		//        var i = o.getProperty("SAP__Origin");
		//        var j = o.getProperty("ReferenceInstanceID");
		//        var G = "TaskCollection(SAP__Origin='" + i + "',InstanceID='" + j + "')";
		//        this.bNavToFullScreenFromLog = true;
		//        var H = {
		//            SAP__Origin: i,
		//            InstanceID: j,
		//            contextPath: G
		//        };
		//        var I = this.getView();
		//        this.oContext = new C(I.getModel(), G);
		//        I.setBindingContext(this.oContext);
		//        var K = q.extend(true, {}, I.getModel().getData(this.oContext.getPath(), this.oContext));
		//        if (q.isEmptyObject(K)) {
		//            var N = this;
		//            var Q = N.getOwnerComponent().getDataManager();
		//            Q.oDataRead("/TaskCollection(SAP__Origin='" + i + "',InstanceID='" + j + "')", null, function (W) {
		//                if (W !== undefined && !q.isEmptyObject(W)) {
		//                    N.oRouter.navTo("detail_deep", H, false);
		//                }
		//            }, function (W) {
		//                c.error(W);
		//                return;
		//            });
		//        } else {
		//            this.oRouter.navTo("detail_deep", H, false);
		//        }
		//    },
		//    onEmployeeLaunchCommentIcon: function (e) {
		//        var o = e.getSource().getBindingContext().getProperty("SAP__Origin");
		//        var i = e.getSource().getBindingContext("detail").getModel().getProperty(e.getSource().getBindingContext("detail").getPath()).CreatedBy;
		//        if (!o) {
		//            var I = this.oModel2.getData();
		//            o = I.SAP__Origin;
		//        }
		//        this.showEmployeeCard(o, i, p.getSelectedControl(e));
		//    },
		//    onAttachmentShow: function (e) {
		//        var o = e.getSource().getBindingContext("detail");
		//        var i = cross.fnd.fiori.inbox.attachment.getRelativeMediaSrc(o.getProperty().__metadata.media_src);
		//        sap.m.URLHelper.redirect(i, true);
		//    },
		//    fnOnNavBackFromLogDescription: function (e) {
		//        this.bNavToFullScreenFromLog = false;
		//        this.bShowLogs = true;
		//        window.history.back();
		//    },
		//    showConfirmationDialog: function (e, i) {
		//        this.oConfirmationDialogManager.showDecisionDialog({
		//            question: this.i18nBundle.getText("XMSG_CONFIRM_QUESTION"),
		//            showNote: false,
		//            title: this.i18nBundle.getText("XTIT_SUBMIT_CONFIRM"),
		//            confirmButtonLabel: this.i18nBundle.getText("XBUT_CONFIRM"),
		//            confirmActionHandler: function (i, N) {
		//                this.sendAction(e, i, N);
		//            }.bind(this, i)
		//        });
		//    },
		//    onCommentPost: function (e, i, o) {
		//        var j = o.getParameter("value");
		//        if (j && j.length > 0) {
		//            this.sendAction("AddComment", null, j);
		//        }
		//    },
		//    refreshHeaderFooterOptions: function () {
		//        if (this.oHeaderFooterOptions && this.oHeaderFooterOptions.buttonList) {
		//            this.oHeaderFooterOptions.buttonList.sort(v.compareButtons);
		//        }
		//        this._oHeaderFooterOptions = q.extend(this._oHeaderFooterOptions, this.oHeaderFooterOptions);
		//        this.setHeaderFooterOptions(this._oHeaderFooterOptions);
		//    },
		//    setHeaderFooterOptions: function (o) {
		//        this.oAppImp.oDHFHelper.setHeaderFooter(this, o);
		//    },
		//    getPage: function () {
		//        return k.getPageFromController(this);
		//    },
		//    fnNavBackToTableVw: function () {
		//        this.getOwnerComponent().getEventBus().publish("cross.fnd.fiori.inbox", "refreshTask", { "contextPath": this.sCtxPath });
		//        if (window.history.length > 0) {
		//            window.history.back();
		//        }
		//    },
		//    fnOnNavBackInMobile: function () {
		//        var H = z.getInstance();
		//        var e = H.getPreviousHash();
		//        if (e !== undefined) {
		//            window.history.back();
		//        } else {
		//            this.oRouter.navTo("master", {}, true);
		//        }
		//    },
		//    checkStatusAndOpenTaskUI: function () {
		//        var o = this.oModel2.getData();
		//        this.oDataManager.checkStatusAndOpenTask(o.SAP__Origin, o.InstanceID, this.openTaskUI.bind(this));
		//    },
		//    openTaskUI: function () {
		//        var o = this.oModel2.getData();
		//        var e = this._getActionHelper();
		//        var K = o.SAP__Origin + "_" + o.InstanceID;
		//        var i = this.oEmbedModeIntentParams ? this.oEmbedModeIntentParams[K] : null;
		//        if (i) {
		//            this.fnNavigateToApp(i, i.OpenInEmbedMode);
		//        } else {
		//            var j = this.getOwnerComponent().getDataManager();
		//            e.fnValidateOpenTaskURLAndRedirect(this.oModel2.getData().GUI_Link || this.oModel2.getData().UIExecutionLink.GUI_Link, j.isForwardUserSettings());
		//        }
		//    },
		//    fnEmbedApplicationInDetailView: function (o) {
		//        var N = "#" + o.semanticObject + "-" + o.action;
		//        var i = new J({
		//            NavigationIntent: N,
		//            params: o.params
		//        });
		//        this.getOwnerComponent().setModel(i, "intentModel");
		//        var e = {
		//            SAP__Origin: this.oRoutingParameters.SAP__Origin,
		//            InstanceID: this.oRoutingParameters.InstanceID,
		//            contextPath: this.oRoutingParameters.contextPath
		//        };
		//        if (this.bIsTableViewActive) {
		//            this.oRouter.navTo("replace_detail_deep", e, false);
		//        } else {
		//            this.oRouter.navTo("replace_detail", e, true);
		//        }
		//    },
		//    updateToggleButtonState: function (e) {
		//        this.sCurrentBreakpoint = e.getParameter("currentBreakpoint");
		//        this.setShowMainContent();
		//    },
		//    onLogBtnPress: function (e) {
		//        var o = this.byId("LogButtonID");
		//        var i = this.byId("DetailsButtonID");
		//        var j = this.byId("tabBarLogs");
		//        this.bShowLogs = false;
		//        if (o) {
		//            if (o.getText() === this.i18nBundle.getText("XBUT_SHOWLOG")) {
		//                o.setText(this.i18nBundle.getText("XBUT_HIDELOG"));
		//                if (i) {
		//                    i.setText(this.i18nBundle.getText("XBUT_SHOWDETAILS"));
		//                }
		//                this.oModel2.setProperty("/ShowLogPressed", true);
		//                this.bShowLogs = true;
		//                this.bShowDetails = false;
		//                this.createLogs();
		//                if (!this.sCurrentBreakpoint && D.system.phone) {
		//                    this.sCurrentBreakpoint = "S";
		//                }
		//                this.setShowSideContent(true);
		//                this.fnSetFocusOnSideContent();
		//            } else {
		//                o.setText(this.i18nBundle.getText("XBUT_SHOWLOG"));
		//                this.setShowSideContent(false);
		//            }
		//        }
		//        this.setShowMainContent();
		//        this.updateButtonList();
		//    },
		//    onDetailsBtnPress: function (e) {
		//        var o = this.byId("LogButtonID");
		//        var i = this.byId("DetailsButtonID");
		//        this.bShowDetails = false;
		//        if (i) {
		//            if (i.getText() === this.i18nBundle.getText("XBUT_SHOWDETAILS")) {
		//                i.setText(this.i18nBundle.getText("XBUT_HIDEDETAILS"));
		//                if (o) {
		//                    o.setText(this.i18nBundle.getText("XBUT_SHOWLOG"));
		//                }
		//                this.oModel2.setProperty("/ShowLogPressed", false);
		//                this.bShowDetails = true;
		//                this.bShowLogs = false;
		//                var j = this.byId("tabBarDetails").getSelectedKey();
		//                this.fnCreateSelectedTab(j);
		//                if (!this.sCurrentBreakpoint && D.system.phone) {
		//                    this.sCurrentBreakpoint = "S";
		//                }
		//                this.setShowSideContent(true);
		//                this.fnSetFocusOnSideContent(j);
		//            } else {
		//                i.setText(this.i18nBundle.getText("XBUT_SHOWDETAILS"));
		//                this.setShowSideContent(false);
		//            }
		//        }
		//        this.setShowMainContent();
		//        this.updateButtonList();
		//    },
		//    hideDetails: function () {
		//        this.bShowDetails = false;
		//        this.setShowSideContent(false);
		//        this.setShowMainContent();
		//    },
		//    updateButtonList: function () {
		//        var e = this.byId("LogButtonID");
		//        if (e) {
		//            e.sI18nBtnTxt = this.bShowLogs ? "XBUT_HIDELOG" : "XBUT_SHOWLOG";
		//        }
		//        var i = this.byId("DetailsButtonID");
		//        if (i) {
		//            i.sI18nBtnTxt = this.bShowDetails ? "XBUT_HIDEDETAILS" : "XBUT_SHOWDETAILS";
		//        }
		//    },
		//    fnSetFocusOnSideContent: function (e) {
		//        var i = this.oModel2.getData().TaskSupports;
		//        var j = this;
		//        if (j.bShowLogs) {
		//            if (i.WorkflowLog) {
		//                setTimeout(function () {
		//                    j.getView().byId("WorkflowLogIconTabFilter").focus();
		//                }, 100);
		//            } else if (i.ProcessingLogs) {
		//                setTimeout(function () {
		//                    j.getView().byId("TaskLogIconTabFilter").focus();
		//                }, 100);
		//            }
		//        } else if (j.bShowDetails) {
		//            switch (e) {
		//            case "NOTES":
		//                setTimeout(function () {
		//                    j.getView().byId("DetailsNoteIconTabFilter").focus();
		//                }, 100);
		//                break;
		//            case "ATTACHMENTS":
		//                setTimeout(function () {
		//                    j.getView().byId("DetailsAttachmentIconTabFilter").focus();
		//                }, 100);
		//                break;
		//            case "OBJECTLINKS":
		//                setTimeout(function () {
		//                    j.getView().byId("DetailsObjectLinksTabFilter").focus();
		//                }, 100);
		//                break;
		//            default:
		//            }
		//        }
		//    },
		//    setShowMainContent: function () {
		//        var o = this.byId("DynamicSideContent");
		//        if (o) {
		//            if (this.sCurrentBreakpoint === "S" && (this.bShowLogs || this.bShowDetails) && this.oModel2 && this.oModel2.getData()) {
		//                var e = this.oModel2.getData().TaskSupports;
		//                if (this.bShowLogs && e && (e.WorkflowLog || e.ProcessingLogs) || this.bShowDetails && e && this._getEmbedIntoDetailsNestedRouter() && (e.Attachments || e.TaskObject || e.Comments)) {
		//                    o.setShowMainContent(false);
		//                } else {
		//                    o.setShowMainContent(true);
		//                }
		//            } else {
		//                o.setShowMainContent(true);
		//            }
		//        }
		//    },
		//    setShowSideContent: function (e) {
		//        var o = this.byId("DynamicSideContent");
		//        if (o) {
		//            o.setShowSideContent(e);
		//        }
		//    },
		//    getShowSideContent: function () {
		//        var o = this.byId("DynamicSideContent");
		//        if (o) {
		//            return o.getShowSideContent();
		//        }
		//        return false;
		//    },
		//    createLogs: function (K) {
		//        var e = K;
		//        var I = this.byId("tabBarLogs");
		//        var o = this.oModel2.getData();
		//        this.sCustomCreatedByValue = null;
		//        if (o.CustomAttributeData instanceof Array && o.CustomAttributeData.length > 0) {
		//            for (var i = 0; i < o.CustomAttributeData.length; i++) {
		//                var j = this.oDataManager.oModel.getProperty("/" + o.CustomAttributeData[i]);
		//                if (j && j.Name.toLowerCase() === this.sCustomCreatedByAttribute.toLowerCase()) {
		//                    this.sCustomCreatedByValue = j.Value;
		//                    break;
		//                }
		//            }
		//        }
		//        if (!e && o.TaskSupports) {
		//            if (o.TaskSupports.ProcessingLogs && o.TaskSupports.WorkflowLog && I) {
		//                e = I.getSelectedKey();
		//            } else if (o.TaskSupports.WorkflowLog) {
		//                e = "WORKFLOWLOG";
		//            } else if (o.TaskSupports.ProcessingLogs) {
		//                e = "TASKLOG";
		//            }
		//        }
		//        switch (e) {
		//        case "TASKLOG":
		//            this.createTimeLine();
		//            this.fnHandleNoTextCreation("ProcessingLogs");
		//            this.fnFetchDataOnLogTabSelect("ProcessingLogs");
		//            break;
		//        case "WORKFLOWLOG":
		//            this.createWorkflowLogTimeLine();
		//            this.fnHandleNoTextCreation("WorkflowLogs");
		//            this.fnFetchDataOnLogTabSelect("WorkflowLogs");
		//            break;
		//        default:
		//        }
		//    },
		//    createWorkflowLogTimeLine: function () {
		//        var e = this;
		//        var o = e._getIconTabControl("WorkflowLogs");
		//        if (o) {
		//            var i = new f({
		//                icon: {
		//                    parts: [
		//                        { path: "detail>Status" },
		//                        { path: "detail>ResultType" }
		//                    ],
		//                    formatter: p.formatterWorkflowLogStatusIcon
		//                },
		//                userName: {
		//                    parts: [
		//                        { path: "detail>PerformedByName" },
		//                        { path: "detail>Status" },
		//                        { path: "detail>CustomCreatedBy" }
		//                    ],
		//                    formatter: p.formatterWorkflowLogStatusUsername
		//                },
		//                userNameClickable: {
		//                    parts: [
		//                        { path: "detail>Status" },
		//                        { path: "detail>CustomCreatedBy" }
		//                    ],
		//                    formatter: p.formatterWorkflowLogUsernameClickable
		//                },
		//                userPicture: {
		//                    parts: [
		//                        { path: "detail>SAP__Origin" },
		//                        { path: "detail>PerformedByName" },
		//                        { path: "detail>Status" },
		//                        { path: "detail>CustomCreatedBy" }
		//                    ],
		//                    formatter: p.formatterWorkflowLogUserPicture
		//                },
		//                title: {
		//                    parts: [
		//                        { path: "detail>Status" },
		//                        { path: "detail>PerformedByName" },
		//                        { path: "detail>CustomCreatedBy" }
		//                    ],
		//                    formatter: p.formatterWorkflowLogStatusText
		//                },
		//                dateTime: "{detail>Timestamp}",
		//                embeddedControl: new V({
		//                    items: [
		//                        new O({
		//                            text: "{detail>Description}",
		//                            active: "{detail>SupportsNavigation}",
		//                            press: this.handleLogNavigation.bind(this)
		//                        }),
		//                        new b({
		//                            text: "{detail>Result}",
		//                            state: {
		//                                path: "detail>ResultType",
		//                                formatter: p.formatterWorkflowLogResultState
		//                            }
		//                        })
		//                    ]
		//                })
		//            });
		//            i.attachUserNameClicked(function (j) {
		//                var G = j.getSource().getBindingContext("detail");
		//                e.showEmployeeCard(G.getProperty("SAP__Origin"), G.getProperty("PerformedBy"), p.getSelectedControl(j));
		//            });
		//            o.bindAggregation("content", {
		//                path: "detail>/WorkflowLogs/results",
		//                template: i
		//            });
		//        }
		//    },
		//    onLogTabSelect: function (o) {
		//        var e = o.getParameters().selectedKey;
		//        this.createLogs(e);
		//    },
		//    fnFetchDataOnLogTabSelect: function (N) {
		//        var o = null;
		//        if (N === "ProcessingLogs") {
		//            o = { $orderby: "OrderID desc" };
		//        }
		//        var e = this.sCtxPath + "/" + N;
		//        var j = this._getIconTabControl(N);
		//        this._setBusyIncdicatorOnDetailControls(j, true);
		//        var G = function (I) {
		//            var K = this.oModel2.getData();
		//            var Q = K[N] && K[N].results ? true : false;
		//            if (this.sCustomCreatedByValue) {
		//                var W = I.results;
		//                if (W && Array.isArray(W)) {
		//                    for (var i = 0; i < W.length; i++) {
		//                        W[i].CustomCreatedBy = this.sCustomCreatedByValue;
		//                    }
		//                }
		//                I.results = W;
		//            }
		//            this.fnUpdateDataAfterFetchComplete(K, Q, N, I);
		//            this._setBusyIncdicatorOnDetailControls(j, false);
		//            if (I.results.length === 0) {
		//                var Y = this._getIconTabControl(N);
		//                var Z;
		//                if (N === "ProcessingLogs") {
		//                    Z = "view.ProcessLogs.noData";
		//                } else if (N === "WorkflowLogs") {
		//                    Z = "view.WorkflowLogs.noData";
		//                }
		//                Y.setNoDataText(this.i18nBundle.getText(Z));
		//            }
		//        };
		//        var H = function (i) {
		//            this._setBusyIncdicatorOnDetailControls(j, false);
		//            this.oDataManager.oDataRequestFailed(i);
		//        };
		//        this.oDataManager.oDataRead(e, o, G.bind(this), H.bind(this));
		//    },
		//    onTabSelect: function (o) {
		//        var e = o.getParameters().selectedKey;
		//        this.fnCreateSelectedTab(e);
		//    },
		//    fnCreateSelectedTab: function (e) {
		//        var i;
		//        if (this.oModel2 && this.oModel2.getData()) {
		//            i = this.oModel2.getData().TaskSupports;
		//        }
		//        if (i) {
		//            switch (e) {
		//            case "NOTES":
		//                if (!i.Comments) {
		//                    if (i.Attachments) {
		//                        this.fnCreateSelectedTab("ATTACHMENTS");
		//                        break;
		//                    } else if (i.TaskObject) {
		//                        this.fnCreateSelectedTab("OBJECTLINKS");
		//                        break;
		//                    } else {
		//                        this.hideDetails();
		//                        break;
		//                    }
		//                }
		//                this.fnDelegateCommentsCreation();
		//                this.fnFetchDataOnTabSelect("Comments");
		//                this.fnSetIconForCommentsFeedInput();
		//                this.fnHandleNoTextCreation("Comments");
		//                break;
		//            case "ATTACHMENTS":
		//                if (!i.Attachments) {
		//                    if (i.Comments) {
		//                        this.fnCreateSelectedTab("NOTES");
		//                        break;
		//                    } else if (i.TaskObject) {
		//                        this.fnCreateSelectedTab("OBJECTLINKS");
		//                        break;
		//                    } else {
		//                        this.hideDetails();
		//                        break;
		//                    }
		//                }
		//                this.fnDelegateAttachmentsCreation();
		//                this.fnFetchDataOnTabSelect("Attachments");
		//                if (!this._getEmbedIntoDetailsNestedRouter()) {
		//                    this.fnHandleAttachmentsCountText("Attachments");
		//                }
		//                this.fnHandleNoTextCreation("Attachments");
		//                break;
		//            case "OBJECTLINKS":
		//                if (i.TaskObject) {
		//                    this.fnFetchObjectLinks();
		//                } else {
		//                    if (i.Comments) {
		//                        this.fnCreateSelectedTab("NOTES");
		//                        break;
		//                    } else if (i.Attachments) {
		//                        this.fnCreateSelectedTab("ATTACHMENTS");
		//                        break;
		//                    } else {
		//                        this.hideDetails();
		//                        break;
		//                    }
		//                }
		//                break;
		//            default:
		//            }
		//        } else {
		//            this.hideDetails();
		//        }
		//    },
		//    fnDelegateCommentsCreation: function () {
		//        if (!this._getEmbedIntoDetailsNestedRouter() && this.isGenericComponentRendered) {
		//            return;
		//        }
		//        var i = this.oModel2.getData();
		//        var e = this._getEmbedIntoDetailsNestedRouter() ? "commentsContainerInDetails" : "commentsContainer";
		//        if (this.getView().byId(e) && this.fnFormatterSupportsProperty(i.TaskSupports.Comments, i.SupportsComments)) {
		//            this.createGenericCommentsComponent(this.getView());
		//        }
		//    },
		//    fnDelegateAttachmentsCreation: function () {
		//        var i = this.oModel2.getData();
		//        var o = this._getEmbedIntoDetailsNestedRouter() ? this.byId("attachmentComponentInDetails") : this.byId("attachmentComponent");
		//        if (o && this.fnFormatterSupportsProperty(i.TaskSupports.Attachments, i.SupportsAttachments)) {
		//            if (!q.isEmptyObject(this.oGenericAttachmentComponent)) {
		//                this.oGenericAttachmentComponent.destroy();
		//                delete this.oGenericAttachmentComponent;
		//            }
		//            this.oGenericAttachmentComponent = sap.ui.getCore().createComponent({
		//                name: "cross.fnd.fiori.inbox.attachment",
		//                settings: { attachmentHandle: this.fnCreateAttachmentHandle(this.sCtxPath) }
		//            });
		//            this.oGenericAttachmentComponent.uploadURL(this.fnGetUploadUrl(this.sCtxPath));
		//            o.setPropagateModel(true);
		//            o.setComponent(this.oGenericAttachmentComponent);
		//        }
		//    },
		//    createTimeLine: function () {
		//        var o = this.byId("timeline");
		//        if (o) {
		//            o.setSort(false);
		//            var e = new f({
		//                icon: {
		//                    path: "detail>ActionName",
		//                    formatter: p.formatterActionIcon
		//                },
		//                userName: {
		//                    parts: [
		//                        { path: "detail>PerformedByName" },
		//                        { path: "detail>ActionName" },
		//                        { path: "detail>CustomCreatedBy" }
		//                    ],
		//                    formatter: p.formatterActionUsername
		//                },
		//                title: {
		//                    path: "detail>ActionName",
		//                    formatter: p.formatterActionText
		//                },
		//                dateTime: "{detail>Timestamp}"
		//            });
		//            o.bindAggregation("content", {
		//                path: "detail>/ProcessingLogs/results",
		//                template: e
		//            });
		//        }
		//    },
		//    fnSetIconForCommentsFeedInput: function () {
		//        if (this.oGenericCommentsComponent && this.oGenericCommentsComponent.fnIsFeedInputPresent() && !this.oGenericCommentsComponent.fnGetFeedInputIcon()) {
		//            if (sap.ushell.Container != undefined) {
		//                var e = this.oModel2.getData().SAP__Origin;
		//                var i = sap.ushell.Container.getUser().getId();
		//                this.oDataManager.getCurrentUserImage(e, i, this.oGenericCommentsComponent.fnSetFeedInputIcon.bind(this.oGenericCommentsComponent));
		//            }
		//        }
		//    },
		//    fnCountUpdater: function (K, e, i, G) {
		//        var j = this;
		//        var I = this.oModel2.getData();
		//        switch (K) {
		//        case "Attachments":
		//            if (j.fnFormatterSupportsProperty(I.TaskSupports.Attachments, I.SupportsAttachments)) {
		//                this.oDataManager.fnGetCount(e, i, function (N) {
		//                    j.oModel2.setProperty("/AttachmentsCount", N);
		//                }, "Attachments", G);
		//            }
		//            break;
		//        case "Comments":
		//            if (j.fnFormatterSupportsProperty(I.TaskSupports.Comments, I.SupportsComments)) {
		//                this.oDataManager.fnGetCount(e, i, function (N) {
		//                    j.oModel2.setProperty("/CommentsCount", N);
		//                }, "Comments", G);
		//            }
		//            break;
		//        case "ObjectLinks":
		//            if (I.TaskSupports.TaskObject && j.oDataManager.bShowTaskObjects) {
		//                this.oDataManager.fnGetCount(e, i, function (N) {
		//                    j.oModel2.setProperty("/ObjectLinksCount", N);
		//                    j.fnHandleNoTextCreation("ObjectLinks");
		//                }, "TaskObjects", G);
		//            }
		//            break;
		//        default:
		//            break;
		//        }
		//    },
		//    fnHandleAttachmentsCountText: function (e) {
		//        var o = this.oModel2.getData();
		//        var G = this._getUploadCollectionControl();
		//        if (G && o.hasOwnProperty("AttachmentsCount")) {
		//            var i = o.AttachmentsCount;
		//            var j = this.oModel2.iSizeLimit;
		//            var H = i >= j ? this.i18nBundle.getText("attachmentsCount.message", [
		//                j,
		//                i
		//            ]) : this.i18nBundle.getText("attachments.tooltip");
		//            G.setNumberOfAttachmentsText(H);
		//        }
		//    },
		//    fnHandleNoTextCreation: function (e) {
		//        var o = this.oModel2.getData();
		//        switch (e) {
		//        case "Comments":
		//            if (this.oGenericCommentsComponent) {
		//                if (o.hasOwnProperty("CommentsCount") && o.CommentsCount > 0) {
		//                    this.oGenericCommentsComponent.setNoDataText(this.i18nBundle.getText("XMSG_LOADING"));
		//                } else if (o.hasOwnProperty("CommentsCount") && o.CommentsCount == 0) {
		//                    this.oGenericCommentsComponent.setNoDataText(this.i18nBundle.getText("view.CreateComment.noComments"));
		//                }
		//            }
		//            break;
		//        case "Attachments":
		//            var G = this._getUploadCollectionControl();
		//            if (G) {
		//                if (o.hasOwnProperty("AttachmentsCount") && o.AttachmentsCount > 0) {
		//                    G.setNoDataText(this.i18nBundle.getText("XMSG_LOADING"));
		//                } else if (o.hasOwnProperty("AttachmentsCount") && o.AttachmentsCount == 0) {
		//                    G.setNoDataText(this.i18nBundle.getText("view.Attachments.noAttachments"));
		//                }
		//            }
		//            break;
		//        case "ProcessingLogs":
		//            var i = this._getIconTabControl("ProcessingLogs");
		//            if (i) {
		//                i.setNoDataText(this.i18nBundle.getText("XMSG_LOADING"));
		//            }
		//            break;
		//        case "WorkflowLogs":
		//            var W = this._getIconTabControl("WorkflowLogs");
		//            if (W) {
		//                W.setNoDataText(this.i18nBundle.getText("XMSG_LOADING"));
		//            }
		//            break;
		//        case "ObjectLinks":
		//            var j = this._getObjectLinksList();
		//            if (j) {
		//                if (o.ObjectLinksCount && o.ObjectLinksCount > 0) {
		//                    j.setNoDataText(this.i18nBundle.getText("XMSG_LOADING"));
		//                } else if (o.ObjectLinksCount && o.ObjectLinksCount == 0) {
		//                    j.setNoDataText(this.i18nBundle.getText("view.ObjectLinks.noObjectLink"));
		//                }
		//            }
		//            break;
		//        default:
		//            break;
		//        }
		//    },
		//    fnClearCachedData: function () {
		//        var e = this._getEmbedIntoDetailsNestedRouter() ? "-" : "";
		//        this.oModel2.setProperty("/AttachmentsCount", e);
		//        this.oModel2.setProperty("/CommentsCount", e);
		//        this.oModel2.setProperty("/ObjectLinksCount", e);
		//        this.oModel2.setProperty("/ProcessingLogs", "");
		//        this.oModel2.setProperty("/Attachments", "");
		//        this.oModel2.setProperty("/Comments", "");
		//        this.oModel2.setProperty("/ObjectLinks", "");
		//        this.oModel2.setProperty("/StatusText", "");
		//        this.oModel2.setProperty("/WorkflowLogs", "");
		//        this.oModel2.setProperty("/Description", "");
		//    },
		//    fnFetchDataOnTabSelect: function (N) {
		//        var e = this.sCtxPath + "/" + N;
		//        var o = null;
		//        if (N === "Attachments" || N === "Comments") {
		//            o = { $orderby: "CreatedAt desc" };
		//        }
		//        var i = this.oModel2.getData();
		//        var j = i[N] && i[N].results ? true : false;
		//        var G = this._getIconTabControl(N);
		//        var H = function (K) {
		//            this.fnUpdateDataAfterFetchComplete(i, j, N, K);
		//            this._setBusyIncdicatorOnDetailControls(G, false);
		//        };
		//        var I = function (K) {
		//            this._setBusyIncdicatorOnDetailControls(G, false);
		//            this.oDataManager.oDataRequestFailed(K);
		//        };
		//        if (!j && i[this.oMapCountProperty[N]] > 0) {
		//            this._setBusyIncdicatorOnDetailControls(G, true);
		//        }
		//        this.oDataManager.oDataRead(e, o, H.bind(this), I.bind(this));
		//    },
		//    fnUpdateDataAfterFetchComplete: function (o, e, N, i) {
		//        var j = false;
		//        if (e && i.results.length > 0) {
		//            q.extend(true, o[N], i);
		//        } else {
		//            j = o[N].results != null && o[N].results.length > 0 && i.results != null && i.results.length === 0;
		//            o[N] = i;
		//        }
		//        o[this.oMapCountProperty[N]] = i.results.length;
		//        if (j) {
		//            this.fnHandleNoTextCreation(N);
		//        }
		//        this._updateDetailModel(o);
		//        if (this._getEmbedIntoDetailsNestedRouter()) {
		//            this.fnHandleAttachmentsCountText("Attachments");
		//        }
		//    },
		//    _getIconTabControl: function (N) {
		//        switch (N) {
		//        case "Comments":
		//            if (this.oGenericCommentsComponent) {
		//                return this.oGenericCommentsComponent.getAggregation("rootControl").byId("MIBCommentList");
		//            }
		//            return null;
		//        case "Attachments":
		//            return this._getUploadCollectionControl();
		//        case "ProcessingLogs":
		//            return this.getView().byId("timeline");
		//        case "WorkflowLogs":
		//            return this.getView().byId("timelineWorkflowLog");
		//        case "TaskObjects":
		//            return this._getObjectLinksList();
		//        default:
		//        }
		//    },
		//    fnFetchObjectLinks: function () {
		//        var o = 0;
		//        var e = this._getIconTabControl("TaskObjects");
		//        this._setBusyIncdicatorOnDetailControls(e, true);
		//        var j = function (H) {
		//            for (var i = 0; i < H.results.length; i++) {
		//                if (!H.results[i].Label) {
		//                    o = o + 1;
		//                    H.results[i].Label = this.i18nBundle.getText("object.link.label") + " " + o;
		//                }
		//            }
		//            this._setBusyIncdicatorOnDetailControls(e, false);
		//            this.oModel2.setProperty("/ObjectLinks", H);
		//            this.oModel2.setProperty("/ObjectLinksCount", H.results.length);
		//        };
		//        var G = function (i) {
		//            this._setBusyIncdicatorOnDetailControls(e, false);
		//        };
		//        this.oDataManager.oDataRead(this.sCtxPath + "/" + "TaskObjects", null, j.bind(this), G.bind(this));
		//    },
		//    onSupportInfoOpenEvent: function (e, j, o) {
		//        if (o.source === "MAIN") {
		//            var G = null;
		//            var I = q.extend(true, [], this.oModel2.getData());
		//            if (this.aTaskDefinitionData) {
		//                for (var i = 0; i < this.aTaskDefinitionData.length; i++) {
		//                    if (I && I.TaskDefinitionID === this.aTaskDefinitionData[i].TaskDefinitionID) {
		//                        if (this.aTaskDefinitionData[i].CustomAttributeDefinitionData.results) {
		//                            G = this.aTaskDefinitionData[i].CustomAttributeDefinitionData.results;
		//                        }
		//                    }
		//                }
		//            }
		//            S.setTask(I, G, this.getView().getModel());
		//        }
		//    },
		//    addActionAPI: function (e, o, i, j) {
		//        var G = false;
		//        if (e !== this._taskSwitchCount) {
		//            c.warning("s3.controller.addActionAPI: task switched while waiting!");
		//        } else {
		//            G = this.addAction(o, i, j);
		//        }
		//        return G;
		//    },
		//    addAction: function (o, e, i) {
		//        if (!o) {
		//            throw new Error("Provide Action object with action name, label and optionally type (Accept/Reject)");
		//        }
		//        if (!e) {
		//            throw new Error("Provide listener function for the Action");
		//        }
		//        if (typeof e !== "function") {
		//            throw new Error("Second argument is not a listener function");
		//        }
		//        if (i) {
		//            if (typeof i !== "object") {
		//                i = null;
		//            }
		//        }
		//        var j = false;
		//        if (this.oHeaderFooterOptions) {
		//            var G = 50;
		//            var H = 0;
		//            var I = o.action;
		//            var K = o.label;
		//            var N = {
		//                actionId: I,
		//                sBtnTxt: K,
		//                onBtnPressed: i ? e.bind(i) : e
		//            };
		//            if (o.type && (o.type.toUpperCase() === "ACCEPT" || o.type.toUpperCase() === "POSITIVE")) {
		//                N.nature = "POSITIVE";
		//                H = G;
		//                G++;
		//                if (o.iDisplayOrderPriority) {
		//                    H = o.iDisplayOrderPriority;
		//                }
		//                N.iDisplayOrderPriority = H;
		//            } else if (o.type && (o.type.toUpperCase() === "REJECT" || o.type.toUpperCase() === "NEGATIVE")) {
		//                N.nature = "NEGATIVE";
		//                H = 200 + G;
		//                G++;
		//                if (o.iDisplayOrderPriority) {
		//                    H = o.iDisplayOrderPriority;
		//                }
		//                N.iDisplayOrderPriority = H;
		//            } else {
		//                H = 500 + G;
		//                G++;
		//                if (o.iDisplayOrderPriority) {
		//                    H = o.iDisplayOrderPriority;
		//                }
		//                N.iDisplayOrderPriority = H;
		//            }
		//            this.oHeaderFooterOptions.buttonList.push(N);
		//            this.refreshHeaderFooterOptions();
		//            j = true;
		//        }
		//        return j;
		//    },
		//    removeAction: function (e) {
		//        var j = false;
		//        var o = [];
		//        var G;
		//        if (!e) {
		//            throw new Error("Provide Action string to be removed");
		//        }
		//        if (this.oHeaderFooterOptions) {
		//            if (this.oHeaderFooterOptions.oPositiveAction && this.oHeaderFooterOptions.oPositiveAction.actionId === e) {
		//                this.oHeaderFooterOptions.oPositiveAction = null;
		//                this.refreshHeaderFooterOptions();
		//                j = true;
		//            } else if (this.oHeaderFooterOptions.oNegativeAction && this.oHeaderFooterOptions.oNegativeAction.actionId === e) {
		//                this.oHeaderFooterOptions.oNegativeAction = null;
		//                this.refreshHeaderFooterOptions();
		//                j = true;
		//            } else {
		//                o = this.oHeaderFooterOptions.buttonList;
		//                G = o.length;
		//                for (var i = 0; i < G; i++) {
		//                    if (e === o[i].actionId) {
		//                        o.splice(i, 1);
		//                        this.oHeaderFooterOptions.buttonList = o;
		//                        this.refreshHeaderFooterOptions();
		//                        j = true;
		//                        break;
		//                    }
		//                }
		//            }
		//        }
		//        return j;
		//    },
		//    disableActionAPI: function (e, i) {
		//        var j = false;
		//        if (e !== this._taskSwitchCount) {
		//            c.warning("s3.controller.disableActionAPI: task switched while waiting!");
		//        } else {
		//            j = this.disableAction(i);
		//        }
		//        return j;
		//    },
		//    disableAction: function (e) {
		//        var j = false;
		//        var o = [];
		//        if (this.oHeaderFooterOptions) {
		//            if (this.oHeaderFooterOptions.oPositiveAction && this.oHeaderFooterOptions.oPositiveAction.actionId === e) {
		//                this.oHeaderFooterOptions.oPositiveAction.bDisabled = true;
		//                this.refreshHeaderFooterOptions();
		//                j = true;
		//            } else if (this.oHeaderFooterOptions.oNegativeAction && this.oHeaderFooterOptions.oNegativeAction.actionId === e) {
		//                this.oHeaderFooterOptions.oNegativeAction.bDisabled = true;
		//                this.refreshHeaderFooterOptions();
		//                j = true;
		//            } else {
		//                o = this.oHeaderFooterOptions.buttonList;
		//                for (var i = 0; i < o.length; i++) {
		//                    if (e && e === o[i].actionId) {
		//                        o[i].bDisabled = true;
		//                        this.oHeaderFooterOptions.buttonList = o;
		//                        this.refreshHeaderFooterOptions();
		//                        j = true;
		//                        break;
		//                    }
		//                }
		//            }
		//        }
		//        return j;
		//    },
		//    disableAllActionsAPI: function (e) {
		//        var i = false;
		//        if (e !== this._taskSwitchCount) {
		//            c.warning("s3.controller.disableAllActionsAPI: task switched while waiting!");
		//        } else {
		//            i = this.disableAllActions();
		//        }
		//        return i;
		//    },
		//    disableAllActions: function () {
		//        var e = false;
		//        var j = [];
		//        if (this.oHeaderFooterOptions) {
		//            e = true;
		//            if (this.oHeaderFooterOptions.oPositiveAction && this.oHeaderFooterOptions.oPositiveAction.actionId) {
		//                this.oHeaderFooterOptions.oPositiveAction.bDisabled = true;
		//            }
		//            if (this.oHeaderFooterOptions.oNegativeAction && this.oHeaderFooterOptions.oNegativeAction.actionId) {
		//                this.oHeaderFooterOptions.oNegativeAction.bDisabled = true;
		//            }
		//            j = this.oHeaderFooterOptions.buttonList;
		//            if (j) {
		//                for (var i = 0; i < j.length; i++) {
		//                    if (j[i].actionId) {
		//                        j[i].bDisabled = true;
		//                    }
		//                }
		//                this.oHeaderFooterOptions.buttonList = j;
		//            }
		//            this.refreshHeaderFooterOptions();
		//        }
		//        return e;
		//    },
		//    enableAction: function (e) {
		//        var j = false;
		//        var o = [];
		//        if (this.oHeaderFooterOptions) {
		//            if (this.oHeaderFooterOptions.oPositiveAction && this.oHeaderFooterOptions.oPositiveAction.actionId === e) {
		//                this.oHeaderFooterOptions.oPositiveAction.bDisabled = false;
		//                this.refreshHeaderFooterOptions();
		//                j = true;
		//            } else if (this.oHeaderFooterOptions.oNegativeAction && this.oHeaderFooterOptions.oNegativeAction.actionId === e) {
		//                this.oHeaderFooterOptions.oNegativeAction.bDisabled = false;
		//                this.refreshHeaderFooterOptions();
		//                j = true;
		//            } else {
		//                o = this.oHeaderFooterOptions.buttonList;
		//                for (var i = 0; i < o.length; i++) {
		//                    if (e && e === o[i].actionId) {
		//                        o[i].bDisabled = false;
		//                        this.oHeaderFooterOptions.buttonList = o;
		//                        this.refreshHeaderFooterOptions();
		//                        j = true;
		//                        break;
		//                    }
		//                }
		//            }
		//        }
		//        return j;
		//    },
		//    enableAllActions: function () {
		//        var e = false;
		//        var j = [];
		//        if (this.oHeaderFooterOptions) {
		//            e = true;
		//            if (this.oHeaderFooterOptions.oPositiveAction && this.oHeaderFooterOptions.oPositiveAction.actionId) {
		//                this.oHeaderFooterOptions.oPositiveAction.bDisabled = false;
		//            }
		//            if (this.oHeaderFooterOptions.oNegativeAction && this.oHeaderFooterOptions.oNegativeAction.actionId) {
		//                this.oHeaderFooterOptions.oNegativeAction.bDisabled = false;
		//            }
		//            j = this.oHeaderFooterOptions.buttonList;
		//            if (j) {
		//                for (var i = 0; i < j.length; i++) {
		//                    if (j[i].actionId) {
		//                        j[i].bDisabled = false;
		//                    }
		//                }
		//                this.oHeaderFooterOptions.buttonList = j;
		//            }
		//            this.refreshHeaderFooterOptions();
		//        }
		//        return e;
		//    },
		//    _createCustomAttributesElements: function (o, e) {
		//        var G = this.getView().byId("customAttributesContainer");
		//        var H = this.aCA;
		//        for (var i = 0; i < e.length; i++) {
		//            var I = e[i].Name;
		//            var K = e[i].Type;
		//            var N = e[i].Label;
		//            var Q;
		//            var W = true;
		//            if (I.toLowerCase() === this.sCustomTaskTitleAttribute.toLowerCase() || I.toLowerCase() === this.sCustomNumberValueAttribute.toLowerCase() || I.toLowerCase() === this.sCustomNumberUnitValueAttribute.toLowerCase() || I.toLowerCase() === this.sCustomObjectAttributeValue.toLowerCase() || I.toLowerCase() === this.sCustomCreatedByAttribute.toLowerCase()) {
		//                W = false;
		//            }
		//            if (W) {
		//                if (I && K && N) {
		//                    for (var j = 0; j < o.CustomAttributeData.length; j++) {
		//                        if (this._getShowAdditionalAttributes() === true) {
		//                            Q = this.getView().getModel().getProperty("/" + o.CustomAttributeData[j]);
		//                        } else {
		//                            Q = o.CustomAttributeData[j];
		//                        }
		//                        if (Q.Name === I) {
		//                            var Y = new g("", {});
		//                            Y.setLayoutData(new R("", {
		//                                linebreak: true,
		//                                margin: false
		//                            }));
		//                            var Z = new L("", { text: N });
		//                            Z.setLayoutData(new R("", {
		//                                weight: 3,
		//                                minWidth: 192
		//                            }));
		//                            Y.setLabel(Z);
		//                            var $ = p.fnCustomAttributeTypeFormatter(Q.Value, K);
		//                            var _ = new T("", { text: $ });
		//                            _.setLayoutData(new R("", { weight: 5 }));
		//                            Y.addField(_);
		//                            G.addFormElement(Y);
		//                            H.push(Y);
		//                            break;
		//                        }
		//                    }
		//                }
		//            }
		//        }
		//        this.byId("DescriptionContent").rerender();
		//    },
		//    _createCustomAttributesOnDataLoaded: function (o) {
		//        if (this.aCA.length === 0 && this.oModel2.getData().CustomAttributeData && this.oModel2.getData().CustomAttributeData.length > 0 && o && o.length > 0) {
		//            var e = this._createCustomAttributesElements.bind(this);
		//            e(this.oModel2.getData(), o);
		//        }
		//    },
		//    _getUploadCollectionControl: function () {
		//        var o;
		//        if (this.isGenericComponentRendered && this.oAttachmentComponentView) {
		//            o = this.oAttachmentComponentView.byId("uploadCollection");
		//        } else if (this.oGenericAttachmentComponent && !this.isGenericComponentRendered) {
		//            o = this.oGenericAttachmentComponent.view.byId("uploadCollection");
		//        }
		//        return o;
		//    },
		//    _setBusyIncdicatorOnDetailControls: function (o, e) {
		//        if (o) {
		//            if (e) {
		//                o.setBusyIndicatorDelay(1000);
		//            }
		//            o.setBusy(e);
		//        }
		//    },
		//    _processCustomAttributesData: function (i) {
		//        if (i.CustomAttributeData && i.CustomAttributeData.__list) {
		//            i.CustomAttributeData = i.CustomAttributeData.__list;
		//        }
		//        var o = this.oDataManager.getCustomAttributeDefinitions()[i.TaskDefinitionID];
		//        if (o && o instanceof Array) {
		//            i.CustomAttributeDefinitionData = o;
		//        }
		//        return i;
		//    },
		//    _getShowAdditionalAttributes: function () {
		//        if (this.bShowAdditionalAttributes == null) {
		//            this.bShowAdditionalAttributes = this.oDataManager.getShowAdditionalAttributes();
		//        }
		//        return this.bShowAdditionalAttributes;
		//    },
		//    _getTaskTitleInHeader: function () {
		//        if (this.bTaskTitleInHeader == null) {
		//            this.bTaskTitleInHeader = this.oDataManager.getTaskTitleInHeader();
		//        }
		//        return this.bTaskTitleInHeader;
		//    },
		//    _getStandaloneDetailDeep: function () {
		//        if (this.bStandaloneDetailDeep == null) {
		//            this.bStandaloneDetailDeep = this.oDataManager.getStandaloneDetailDeep();
		//        }
		//        return this.bStandaloneDetailDeep;
		//    },
		//    createCalendarEvent: function () {
		//        var e = this;
		//        var o = this.oModel2.getData();
		//        var i = o.CompletionDeadLine;
		//        if (i) {
		//            i.setDate(i.getDate() - 1);
		//            var j = i.getFullYear();
		//            var G = i.getMonth();
		//            var H = i.getDate();
		//            var I = i.getHours();
		//            var K = i.getMinutes();
		//            var N = i.getSeconds();
		//            var Q = new Date(j, G, H, I, K, N);
		//            var W = new Date(j, G, H, I, K + 60, N);
		//            var Y = o.TaskTitle;
		//            var Z = this.getMailBody();
		//            var $ = function (c1) {
		//                a.show(e.i18nBundle.getText("dialog.success.mq.calendarEventCreated"));
		//            };
		//            var _ = function (c1) {
		//                var d1 = e.i18nBundle.getText("dialog.error.mq.calendarPluginError");
		//                M.error(d1, { details: v.fnRemoveHtmlTags(c1) });
		//            };
		//            var a1 = function (c1) {
		//                if (typeof c1 === "string" || c1.length === 0) {
		//                    window.plugins.calendar.createEvent(Y, null, Z, Q, W, $, _);
		//                } else {
		//                    a.show(e.i18nBundle.getText("dialog.error.mq.calendarThereIsAnEventAlready"));
		//                }
		//            };
		//            var b1 = function (c1) {
		//                window.plugins.calendar.createEvent(Y, null, Z, Q, W, $, _);
		//            };
		//            window.plugins.calendar.findEvent(Y, null, null, Q, W, a1, b1);
		//            i.setDate(i.getDate() + 1);
		//        }
		//    },
		//    _getActionHelper: function () {
		//        if (!this._oActionHelper) {
		//            this._oActionHelper = new l(this, this.getView());
		//        }
		//        return this._oActionHelper;
		//    },
		//    showEmptyView: function (e, i, I) {
		//        this.getOwnerComponent().oDataManager.oEventBus.publish("cross.fnd.fiori.inbox", "clearSelection");
		//        X.create({ viewName: "cross.fnd.fiori.inbox.view.Empty" }).then(function (o) {
		//            var j = cross.fnd.fiori.inbox.util.tools.Application.getImpl();
		//            if (!e) {
		//                e = j.oConfiguration.getDetailTitleKey();
		//            }
		//            if (!I && !i) {
		//                i = j.oConfiguration.getDefaultEmptyMessageKey();
		//            }
		//            o.getController().setTitleAndMessage(e, i, I);
		//            var G = this.oDataManager;
		//            if (!G)
		//                G = this.getOwnerComponent().getDataManager();
		//            if (G.tableView) {
		//                var H = this.getView().getParent().getParent().byId("fioriContent");
		//                H.addPage(o);
		//                H.to(o.getId(), "show");
		//            } else {
		//                var K = this.getView().getParent().getParent();
		//                K.addDetailPage(o);
		//                K.to(o.getId(), "show");
		//            }
		//        }.bind(this)).catch(function () {
		//            c.error("Empty view was not created successfully");
		//        });
		//    },
		//    _getEmbedIntoDetailsNestedRouter: function () {
		//        return this.embedFioriElements;
		//    },
		//    showHideSideContent: function () {
		//        var i = this.oModel2.getData();
		//        if (this.bNavToFullScreenFromLog) {
		//            this.setShowSideContent(false);
		//            this.bShowLogs = false;
		//            this.bShowDetails = false;
		//        } else if ((i.TaskSupports.ProcessingLogs || i.TaskSupports.WorkflowLog) && this.oDataManager.getShowLogEnabled() && this.bShowLogs) {
		//            this.createLogs();
		//            this.setShowSideContent(true);
		//        } else if ((i.TaskSupports.Attachments || i.TaskSupports.TaskObject || i.TaskSupports.Comments) && this.bShowDetails && this._getEmbedIntoDetailsNestedRouter()) {
		//            this.fnCreateSelectedTab(this.byId("tabBarDetails").getSelectedKey());
		//            this.setShowSideContent(true);
		//        } else {
		//            this.setShowSideContent(false);
		//        }
		//        this.setShowMainContent();
		//    },
		//    _getObjectLinksList: function () {
		//        var o = this.byId("MIBObjectLinksTabFilter");
		//        if (o && o.getVisible() && o.getContent() && Array.isArray(o.getContent()) && o.getContent().length > 0) {
		//            var e = o.getContent()[0];
		//            if (e && e.getMetadata() && e.getMetadata().getName() === "sap.m.List") {
		//                return e;
		//            }
		//        }
		//        return undefined;
		//    },
		//    taskSupportsCommAttRelObj: function (i) {
		//        var e;
		//        if (i) {
		//            e = i.TaskSupports;
		//        } else if (this.oModel2 && this.oModel2.getData()) {
		//            e = this.oModel2.getData().TaskSupports;
		//        } else {
		//            return false;
		//        }
		//        return e.Comments || e.Attachments || e.TaskObject;
		//    },
		//    getInboxAPI: function () {
		//        return {
		//            addAction: this.addActionAPI.bind(this, this._taskSwitchCount),
		//            removeAction: this.removeAction.bind(this),
		//            updateTask: this.updateTask.bind(this),
		//            getDescription: this.getDescription.bind(this),
		//            setShowFooter: this.setShowFooterAPI.bind(this, this._taskSwitchCount),
		//            setShowNavButton: this.setShowNavButtonAPI.bind(this, this._taskSwitchCount),
		//            disableAction: this.disableActionAPI.bind(this, this._taskSwitchCount),
		//            disableAllActions: this.disableAllActionsAPI.bind(this, this._taskSwitchCount),
		//            enableAction: this.enableAction.bind(this),
		//            enableAllActions: this.enableAllActions.bind(this)
		//        };
		//    }
	});
});